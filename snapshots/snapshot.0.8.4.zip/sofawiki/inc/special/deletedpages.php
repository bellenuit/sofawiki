<?php

if (!defined("SOFAWIKI")) die("invalid acces");

$swParsedName = "Special:Deleted Pages";

$swParsedContent = "";

$filter = "SELECT revision, name WHERE status == deleted";
$result = swFilter($filter,'','data','deleted');
		
foreach($result as $row)
{
	if (isset($row['name']))
	{
		$name = $row['name'];
		if (is_array($name))
			$name = array_pop($name);
		$url = swNameURL($name);
		$swParsedContent .= '<a class="invalid" href="index.php?action=history&name='.$url.'">'.$name.'</a> ' ;
	}
}


$swParseSpecial = false;


?>