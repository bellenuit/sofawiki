<?php

if (!defined("SOFAWIKI")) die("invalid acces");

$swParsedName = "Special:Categories";

$swParsedContent = "";

if (true)
{
	$firsts = array('-','0','1','2','3','4','5','6','7','8','9',
	'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z');
	
	foreach($firsts as $v)
	{
		$swParsedContent .= '<a href="index.php?name=special:categories&first='.$v.'">'.$v.'</a> ' ;
	}
	
	$swParsedContent .= '<br><br>';
	
	if (!isset($_REQUEST['first'])) $_REQUEST['first'] = 'a';
}

$first =  $_REQUEST['first'];

$revisions = swFilter('SELECT name WHERE name =* Category:'.$first,'*','data');



foreach ($revisions as $row)
{
	//print_r($row); 
	
	if (isset($row['name']))
	{
		$name = $row['name'];
		if (is_array($name))
			$name = array_pop($name);
		$url = swNameURL($name);
		
		$name = substr($name,strlen('Category:'));
	
		$swParsedContent .= '<a href="index.php?name='.$url.'">'.$name.'</a> ';
	}
}

$oldfirst = "";

$swParseSpecial = false;



?>