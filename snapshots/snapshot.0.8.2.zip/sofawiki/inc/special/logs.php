<?php

if (!defined("SOFAWIKI")) die("invalid acces");

$swParsedName = "Special:Logs";

$root = "$swRoot/site/logs/";

$files = glob($root."*.txt");
arsort($files);

$swParsedContent .= "\n<form method='get' action='index.php'><p>";
// $swParsedContent .= "\n<select name='file'>";

$query = swGetArrayValue($_REQUEST,'query');
$query = str_replace("\\\\","\\",$query);
$regex = swGetArrayValue($_REQUEST,'regex');
$regex =  str_replace("\\\\","\\",$regex);
if ($regex)
	$checked = "checked='checked'";
else
	$checked = "";
$file = swGetArrayValue($_REQUEST,'file');

$minfile = null;
$maxfile = null;
foreach ($files as $f)
{
	$f = str_replace($root,"",$f);
	$f = str_replace(".txt","",$f);
	if ($f ==$file)
		$selected = "selected='selected'";
	else	
		$selected = "";
	if (!$minfile) $minfile = $f; else $minfile = min($minfile,$f);
	if (!$maxfile) $maxfile = $f; else $maxfile = max($maxfile,$f);
	// $swParsedContent .= " \n<option value='$f' $selected>$f</option>";
}
$datestart = swGetArrayValue($_REQUEST,'datestart');
$dateend = swGetArrayValue($_REQUEST,'dateend');
if (!$datestart) $datestart = $minfile;
if (!$dateend) $dateend = $maxfile;


// $swParsedContent .= "\n</select>";
$swParsedContent .= "\n<input type='hidden' name='name' value='special:logs'><p>";
$swParsedContent .= "\nstart <input type='text' name='datestart' value='$datestart' /> ";
$swParsedContent .= "\nend<input type='text' name='dateend' value='$dateend' />";
$swParsedContent .= "\nfilter <input type='text' name='query' value='$query' />";
$swParsedContent .= "\n<input type='checkbox' name='regex' value='1' $checked /> Regex";
$swParsedContent .= "\n<input type='submit' name='submit' value='Query' />";
$swParsedContent .= "\n</p><form>";

$rawlines = array();
$hits = 0;
$totaltime = 0;
$uniquevisitors = array();
if (swGetArrayValue($_REQUEST,'submit',false))
{
	
	foreach($files as $file)
	{
		$file = str_replace($root,"",$file);
		$file = str_replace(".txt","",$file);

		if ($file>=$datestart && $file<=$dateend)
		{
			//$t = file_get_contents($root.$file.".txt");
			//$lines = explode("\n",$t);
			
			$lines = file($root.$file.".txt",FILE_IGNORE_NEW_LINES || FILE_SKIP_EMPTY_LINES);
			
			
			
			foreach($lines as $line)
			{
				$found=false;
				if ($regex)
				{
					if (preg_match($query,$line))
					{	$rawlines[] = $line; $found = true; }
				}
				else
				{
					if ($query == "" || stristr($line,$query))
					{	$rawlines[]=  $line; $found = true; }
				}
			
				if ($found)
				{
					$hits++;
					if (preg_match("/\[\[user::([^\]]*)/",$line,$matches))
					{	$u = $matches[1] ; $uniquevisitors[$u] = 1;} 
					if (preg_match("/\[\[time::([^\]]*)/",$line,$matches))
					{	$t = $matches[1] ; 
						if ($t>0)
						$totaltime += $t; 
					} 
				}
			}
		}
	}
	arsort($rawlines);
	$averagetime = sprintf("%0d",$totaltime/$hits);
}
if ($hits>0)
$swParsedContent .= "<p>$hits hits ".count($uniquevisitors)." unique visitors $averagetime msec average time ";

$swParsedContent .= "\n\n<pre>".join("\n",$rawlines)."\n</pre>\n";


$swParseSpecial = false;

// print_r($_ENV);

?>