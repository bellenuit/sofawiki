<?php

if (!defined("SOFAWIKI")) die("invalid acces");

$swParsedName = "Special:Recent Changes";
$db->init(true);
$last = $db->lastrevision;


$swParsedContent = "";
$i = 0;

$item = new swWiki;
$now = date("Y-m-d H:i:s",time()-60*60*24*30);
$lastrevisiontime = date("Y-m-d H:i:s",time());

for ($r = $last; $r > $last - 100 && $r>0; $r--)
{
	if ($i>50 && $lastrevisiontime<$now) continue;
	
	$item->revision = $r;
	$item->lookup(true);
	
	$lastrevisiontime = $item->timestamp;
	$i++;
	
	if ($item->wikinamespace()=="Image" || $item->wikinamespace()=="Category")
	{
		$swParsedContent .= "$item->timestamp <nowiki><a href='index.php?action=edit&revision=$r'>$r</a></nowiki> [[:$item->name]] $item->status $item->user <i><nowiki>$item->comment</nowiki></i>\n";
	}
	else
	{
		$swParsedContent .= "$item->timestamp <nowiki><a href='index.php?action=edit&revision=$r'>$r</a></nowiki> [[$item->name]] $item->status $item->user <i><nowiki>$item->comment</nowiki></i>\n";
	}
	
	

}
unset($now);

$swParseSpecial = true;


?>