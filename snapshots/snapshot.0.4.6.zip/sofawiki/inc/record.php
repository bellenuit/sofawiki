<?php


if (!defined("SOFAWIKI")) die("invalid acces");


class swRecord
{
	var $revision;
	var $name;
	var $user;
	var $lang;
	var $timestamp;
	var $status;
	var $content;
	var $comment;
	var $error;
	
	
	function insert()
	{
		$this->status = "ok";
		$this->writefile();
	}
	
	function propose()
	{
		$this->status = "proposed";
		$this->writefile();
	}
	
	function delete()
	{
		$this->status = "deleted";
		$this->content = "";
		$this->writefile();
	}
	
	function protect()
	{
		if (!$this->status=="ok") {swException('Protection of not ok record'); $this->error = 'Protection of not ok record'; return;}
		$this->status = "protected";
		$this->writefile();
	}

	function unprotect()
	{
		$this->status = "ok";
		$this->writefile();
	}
	
	
	function lookup($readonlyheader = false)
	{
		$this->lookupintern($readonlyheader);
	}
	
	
	function lookupintern($readonlyheader = false)
	{
		
		
		
		if ($this->revision)
		{
			$file = swGetPath($this->revision);
		}
		else
		{
			if ($this->name)
			{
				// find in current
				$file = $this->currentPath();
				if (file_exists($file))
				{
					// ok
				}
				else
				{
					// find in revisions
					$this->revision = swGetCurrentRevisionFromName($this->name);
					if (!$this->revision) { swException("No record with this name"); $this->error ='No record with this name'; return ;}
					$file = swGetPath($this->revision);
				}
			}
		}
		
		
		if (!file_exists($file)) {swException('Lookup error missing file '.$file); $this->error ='Lookup error missing file '.$file;  return;}
		if ($readonlyheader && phpversion()>"5.0.0")
			$s = file_get_contents($file, NULL, NULL, 0, 1000);  // enough for header	
		else
			$s = file_get_contents($file);

		$this->revision = swGetValue($s,"_revision");
		$this->name = swGetValue($s,"_name");
		$this->user = swGetValue($s,"_user");
		$this->timestamp = swGetValue($s,"_timestamp");
		$this->status = swGetValue($s,"_status");
		if ($this->status == "delete") $this->status = "deleted"; // compatibility with earlier obsolete "delete" status
		$this->comment = swGetValue($s,"_comment");
		
		$pos = strpos($s,"[[_ ]]");
		$this->content = substr($s,$pos+strlen("[[_ ]]"));
		
	}

	function writefile()
	{
		
		$this->revision = swGetLastRevision()+1;
		
		$this->timestamp = date("Y-m-d H:i:s",time());
		$t = "[[_revision::$this->revision]]"
		. "\n[[_name::$this->name]]"
		. "\n[[_user::$this->user]]"
		. "\n[[_timestamp::$this->timestamp]]"
		. "\n[[_status::$this->status]]"
		. "\n[[_comment::$this->comment]]"
		. "\n[[_ ]]$this->content";
		
		$file = swGetPath($this->revision);
		if ($handle = fopen($file, 'w')) { fwrite($handle, $t); fclose($handle); }
		else { swException('Write error revision $this->revision'); $this->error = 'Write error revision $this->revision';  return; }
		
		
		switch ($this->status)
		{
			case "ok":
			case "protected":
			case "deleted":
				$file = $this->currentPath();
				if ($handle = fopen($file, 'w')) { fwrite($handle, $t); fclose($handle); }
				else { swException('Write error current $this->name '.$file); $this->error = 'Write error current $this->name '.$file; return;}
				break;
			default : // do nothing
				
		}

		global $db;
		$db->UpdateIndexes($this);

	}
	
	function history()
	{
		$list = swGetAllRevisionsFromName($this->name);
		$records = array();
		foreach ($list as $item)
		{
			$record = new swRecord;
			$record->revision = $item;
			$records[] = $record;
		}
		return $records;
	}
	
	function currentPath()
	{
		global $swRoot;
		$file = "$swRoot/site/current/".md5(swNameURL($this->name)).".txt";
		
		return $file;
	}
	
	function wikinamespace()
	{
		$i=strpos($this->name,":");
		if ($i>-1)
		{	
			return substr($this->name,0,$i);
		}
		else
			return "";
	}

	function nameshort()
	{	
		$i=strpos($this->name,":");
		if ($i>-1)
		{	
			$n= substr($this->name,$i+1);
		}
		else
			$n= $this->name;
		
		// clean
		if (stristr($n,"_") && $this->status == "")
		{
			return str_replace("_", " ", $n);
		}
		return $n;
		
	}
	
	function simplenamespace()
	{
		if (substr($this->wikinamespace(),-4,4)=="Talk") return substr($this->wikinamespace(),0,-4);
		return $this->wikinamespace();
	}

	
	function talknamespace()
	{
		if (substr($this->wikinamespace(),-4,4)=="Talk") return $this->wikinamespace();
		return $this->wikinamespace()."Talk";
		
	}

	function istalk()
	{
		if (substr($this->wikinamespace(),-4,4)=="Talk") return true;
	}
	
	function simplename()
	{
		if (!$this->simplenamespace()) return $this->nameshort(); // Main name space
		return $this->simplenamespace().":".$this->nameshort();
	}
	
	function talkname()
	{
		return $this->talknamespace().":".$this->nameshort();
	}
	
	function talkcount()
	{
		$w = new swWiki;
		$w->name = $this->talkname();
		$w->lookup();
		if ( $w->content == "") return 0;
		$s = split("----",$w->content);
		return count($s);
	}
	

} 







?>