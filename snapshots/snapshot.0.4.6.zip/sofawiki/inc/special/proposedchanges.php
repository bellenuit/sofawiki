<?php

if (!defined("SOFAWIKI")) die("invalid acces");

$swParsedName = "Special:Proposed Changes";


$revisions = $db->GetAllProposals();
uksort($revisions, 'strnatcasecmp'); 



$revisions = array_reverse($revisions,true);
$swParsedContent = "";
$i = 0;

$item = new swWiki;

foreach ($revisions as $r=>$v)
{

	
	$item->revision = $r;
	$item->lookup(true);
	
	$current = swGetCurrentRevisionFromName($item->name);
	if ($current < $r)
		$swParsedContent .= 
	
		"<li>$item->timestamp <a href='index.php?revision=$item->revision&action=diff'>$item->revision</a> $item->status $item->user $item->name <i>$item->comment</i></li>";
}

$swParseSpecial = false;


?>