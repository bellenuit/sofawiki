<?php

if (!defined("SOFAWIKI")) die("invalid acces");


class swUser extends swRecord
{
	var $username;
	var $pass;
	var $ppass;
	var $rights;
	var $session;
		
	function exists()
	{
        if (!$this->name) $this->name = "User:".$this->username;
        $this->lookup();
        return $this->visible();
	}
	
	function hasright($action,$name)
	{
		
		global $swAllUserRights;
		
		if ($name =="?") 
		if (stristr($this->content, "[[_".$action."::")) return true;
		
		// power users
		if (stristr($this->content, "[[_".$action."::*]]")) return true;
		
		// main namespace
		if (!stristr($name,":") && stristr($this->content, "[[_".$action."::Main]]")) return true;
		if (!stristr($name,":") && stristr($swAllUserRights, "[[_".$action."::Main]]")) return true;
		
				
		$i=0;
		for ($i=1;$i<=strlen($name);$i++)
		{
			$n = substr($name,0,$i);  // all substrings
			
			if (stristr($swAllUserRights, "[[_$action::$n]]")) {  return true;}
			// normal users
			if (stristr($this->content, "[[_$action::$n]]")) {  return true;}
			
			
		
		}
		
		
		return false;
	}
	
	function proposableNamespaces()
	{
		$list = split("\[\[_propose::",$this->content);
		$result = array();
		array_shift($list);
		foreach ($list as $item)
		{
			$list2 = split("]]",$item);
			$result [] = $list2[0];
 		}
		
		return $result;
	}
	
	
	function nameshort()
	{	
        if (!$this->name) $this->name = "User:".$this->username;
		return str_replace("User:","",$this->name);
	}
	
	function validpassword()
	{
		if ($this->ppass != "" && $this->ppass == $this->pass) return true;
		$key = $this->encryptpassword(); 
//		echo " content".$this->content." key ".$key; 
		if (stristr($this->content, "[[_pass::$key]]")) return true;
	}
	
	function encryptpassword()
	{
		global $db;
		return md5($this->nameshort().$this->pass.$db->salt);
	}
	
	

}



?>