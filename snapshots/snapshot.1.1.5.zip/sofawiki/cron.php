<?php

/*
	SofaWiki
	Matthias Buercher 2010 
	matti@belle-nuit.com
	
	index.php 
	main entry point
*/


error_reporting(E_ALL);
ini_set("display_errors", 1); 


// to keep session longer than some minutes use in .htaccess php_value session.cookie_lifetime 0 
session_start();

define('SOFAWIKIINDEX',true);
define('SOFAWIKICRON',true); 

include 'api.php';

if (!isset($_REQUEST['token']) || !isset($swCronToken) || $_REQUEST['token'] != $swCronToken)
{
	die("invalid acces");
}

$db->init(true);

if (!$swIndexError)
{
	swIndexTrigram();  
	
	// check if there is a recent search that has overtime set
	
	$files = glob($swRoot.'/site/queries/*.txt');
	if (count($files)>0)
	{
		$files = array_combine($files, array_map("filemtime", $files));
		arsort($files);
		
		$i=0;
		foreach($files as $k=>$m)
		{
			
			$s = file_get_contents($k);
			$results = unserialize($s);
			if ($results['overtime'])
			{
				swFilter($results['filter'],$results['namespace'],$results['mode']);
				$i+=9;
			}
			$i++;
			if ($i>200) break;
		}
	}
}

if (function_exists('swInternalCronHook'))
	swInternalCronHook();

echo '<!DOCTYPE html><html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head><body>';
echo $swDebug;
echo '</body><html>';

?>