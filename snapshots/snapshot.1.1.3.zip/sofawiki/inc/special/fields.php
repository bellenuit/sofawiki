<?php

if (!defined("SOFAWIKI")) die("invalid acces");



$wiki->lookup(); 
$swParsedName = swSystemMessage("Fields",$lang)." ".$wiki->name; 


if (isset($_POST['fieldsubmitmodify']) && $_POST['fieldsubmitmodify'])
{
	$fields0 = $_POST;
	unset($fields0['fieldsubmitmodify']);
	unset($fields0['revision']);
	if (@$fields0['_newkey'] != '')
	{
		$newkey = @$fields0['_newkey'];
	}
	unset($fields0['_newkey']);
	$fields = array();
	foreach($fields0 as $key=>$value)
	{
		$keylist = explode(':',$key);
		if ($value != '')
		{
			if ($keylist[0] == '_newvalue')
			{
				if (@$newkey != '')
					$fields[$newkey][] = $value;
			}
			else
				$fields[$keylist[0]][] = $value;
		}
	}
	$s = $wiki->content;
	$s = swReplaceFields($s,$fields,'');
	$wiki->content = $s;
	$wiki->insert();
	
	// $swParsedContent .= '<pre>'.$s.'</pre>';
	
	$swParsedName = swSystemMessage("Fields saved:",$lang)." ".$wiki->name; 

	
}





if ($wiki->error)
{
	$swError = swSystemMessage($wiki->error,$lang);
}
else
$swError = '';
if ($wiki->status == "deleted" || $wiki->status == "delete")
{
	header('HTTP/1.0 404 Not Found');
	$swError = swSystemMessage("ThisPageHasBeenDeletedError",$lang);
}
else
{
	$wiki->parsers = $swParsers;
	$wiki->internalfields = swGetAllFields($wiki->content);
	
	$swParsedContent .= PHP_EOL.'<form method="post" action="index.php?action=fields">';
	$swParsedContent .= PHP_EOL.'<input type="hidden" name="revision" value="'.$wiki->revision.'">';
	$swParsedContent .= PHP_EOL.'<input type="submit" name="fieldsubmitmodify" value="'.swSystemMessage("Modify",$lang).'">';
	$swParsedContent .= PHP_EOL.'<p><table class="fieldseditor">';
		
	//count columns
	$maxcols = 0;
	
	$swParsedContent .= PHP_EOL.' <tr>';
	foreach($wiki->internalfields as $key=>$valuelist)
	{
		$swParsedContent .= PHP_EOL.'  <th>'.$key.'</th>';
		$maxcols = max($maxcols,count($valuelist));
	}
	$swParsedContent .= PHP_EOL.'   <th><input type="text" name="_newkey" value=""></th>';
	$swParsedContent .= PHP_EOL.' </tr>';
	
	for($i=0;$i<=$maxcols;$i++)
	{
		$swParsedContent .= PHP_EOL.' <tr>';
		foreach($wiki->internalfields as $key=>$valuelist)
		{
			$value = @$valuelist[$i];
			if (!stristr($value,"\n") && !stristr($value,"\r"))
				$t = '<input type="text" name="'.$key.':'.$i.'" value="'.htmlspecialchars($value).'">';
			else
				$t = '<textarea name='.$key.':'.$i.'">'.htmlspecialchars($value).'</textarea>';
			$swParsedContent .= PHP_EOL.'  <td class="value">'.$t.'</td>';
		}
		$swParsedContent .= PHP_EOL.'   <td><input type="text" name="_newvalue:'.$i.'" value=""></td>';

		$swParsedContent .= PHP_EOL.' </tr>';
		
	}
	$swParsedContent .= PHP_EOL.'</table>';
	$swParsedContent .= PHP_EOL.'</form>';
	$swParsedContent .= PHP_EOL.'<p><i>Limits: All fields are added at the end of the page. Empty fields are removed.</i>';
	$swParsedContent .= "\n<p><div class='preview'>".$wiki->parse()."\n</div>";

}				

?>