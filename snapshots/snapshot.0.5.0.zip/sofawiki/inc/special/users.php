<?php

if (!defined("SOFAWIKI")) die("invalid acces");

$swParsedName = "Special:Users";

$swParsedContent = "Add new user: [[Special:Passwords]]\n\n";

$names = $db->GetAllNames();
uksort($names, 'strnatcasecmp'); 
$swParsedContent .= "";
$oldfirst = "";

foreach ($names as $n=>$s)
{
	if (substr($n,0,5)=="User:" )
	{
		$u = substr($n,5);
		$first = strtolower(substr($u,0,1));
		if ($oldfirst && $oldfirst != $first) $swParsedContent .= "\n\n";
		$swParsedContent .= "[[$n|$u]] ";
		$oldfirst = $first;
 	}
}

$swParseSpecial = true;



?>