<?php


if (!defined("SOFAWIKI")) die("invalid acces");


function swQuerySplit($s)
{
	// split on space, but preserve [[field::value space]]
	
	return split(" ",$s);
}

function swStrReplace($pattern, $replace, $s)
{
	// use lowercase, uppercase and titlecase
	$patterns = array();
	$patterns[] = $pattern;
	$patterns[] = strtoupper($pattern);
	$patterns[] = strtolower($pattern);
	$patterns[] = strtoupper(substr($pattern,0,1)).substr($pattern,1);

	foreach ($patterns as $p)
	{
		$r = str_replace($pattern,$p,$replace);
		$s = str_replace($p,$r,$s);
	}
	return $s;	
}

function swGetValue($s, $key, $getArray = false)
{
	$pattern = "[[$key::";
	$results = array();
	$result = "";
	$pos = true;
	while ($pos !== FALSE)
	{
		$pos = strpos($s, $pattern);
		if ($pos !== FALSE)
		{
			$pos0 = $pos + strlen($pattern);
			$pos2 = strpos($s,"]]",$pos0);
			if ($pos2 !== FALSE)
			{
				$result = substr($s,$pos0, $pos2-$pos0);
				
				// remove pipe character
				$pos3 = strpos($result,"|");
				if ($pos3 !== FALSE )
					$result = substr($result,0,$pos3);
				
				
				if (!$getArray)
					return $result;
				$results[] = $result;
			}
		}
		$s = substr($s,$pos+1); 
		
	}
	if (!$getArray)
		return $result;
	return $results;
	
}

function swValidate($v,$invalidcharacters)
{
	$l = strlen($invalidcharacters);
	$i=0;
	for ($i==0;$i<$l;$i++)
	{
		if (strstr($v,substr($invalidcharacters,$i,1))) return false;
	}
	return true;
}


function swNameURL($name)
{
	$s = $name;
	// replace spaces by underscores 
	$s = str_replace(" ","_",$s);
	// replace special characters
	$s = str_replace("�"," ",$s);
	$s = str_replace("'"," ",$s);
	// replace german umlauts
	$s = str_replace("�","ae",$s);
	$s = str_replace("�","oe",$s);
	$s = str_replace("�","ue",$s);
	$s = str_replace("�","Ae",$s);
	$s = str_replace("�","Oe",$s);
	$s = str_replace("�","Ue",$s);
	
	$s = strtr($s,'���������������������������������������������������',
'aaaaaceeeeiiiinooooouuuuyyAAAAACEEEEIIIINOOOOOUUUUY');

	// now replace anything else left with underscore
	
	$s = preg_replace("@[^-a-zA-Z0-9/:.-_]@","_",$s);
	
    // Capitalize First letter
	$s = strtoupper(substr($s,0,1)).substr($s,1);
	// Capitalize First letter if there is a Name Space
	if (stristr($s,":"))
	{
		$p = strpos($s,":");
		$s = substr($s,0,$p+1).strtoupper(substr($s,$p+1,1)).substr($s,$p+2);
	}

	
		
	return $s;
	
}



?>