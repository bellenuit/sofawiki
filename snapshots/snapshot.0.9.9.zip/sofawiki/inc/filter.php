<?php


if (!defined('SOFAWIKI')) die('invalid acces');


function swFilterCompare($operator,$values,$term)
{	
	if (!is_array($values))  // single value
		$values = array($values);
	
	$valuelist = array();
	
	if ($operator == '*')
	{
		if (count($values)>0) return true;
		return false;
	}
	
	if (substr($operator,0,1)=='!')
	{
		$op = substr($operator,1);
		$result = swFilterCompare($op,$values,$term);
		return !$result;
	}	
	
	foreach($values as $v)
	{
		$valuelist[] = swUnescape($v);
	}
	
	
	$term = swUnescape($term);
		
	switch ($operator)
	{
		
		case '=': foreach($valuelist as $v)
				   {	if (floatval($v)==floatval($term)) return true; } break;
		case '<>': foreach($valuelist as $v)
				   {	if (floatval($v)==floatval($term)) return true; } break;
		case '<': foreach($valuelist as $v)
				   {	if (floatval($v)<floatval($term)) return true; } break;
		case '>': foreach($valuelist as $v)
				   {	if (floatval($v)>floatval($term)) return true; } break;
		case '<=': foreach($valuelist as $v)
				   {	if (floatval($v)<=floatval($term)) return true; } break;
		case '>=': foreach($valuelist as $v)
				   {	if (floatval($v)>=floatval($term)) return true; } break;
		case '==': foreach($valuelist as $v)
				   {	if ($v==$term) return true; } break;
		case '=*': foreach($valuelist as $v)
				   {	if (substr($v,0,strlen($term))==$term) return true; } break;
		case '*=': foreach($valuelist as $v)
				   {	if (substr($v,-strlen($term))==$term) return true; } break;
		case '*=*': foreach($valuelist as $v)
				   {	 if (stripos($v,$term) !== FALSE) return true; } break;
		case '<<': foreach($valuelist as $v)
				   {	if ($v<$term) return true; } break;
		case '>>': foreach($valuelist as $v)
				   {	if ($v>$term) { return true; } } break;
		case '<<=': foreach($valuelist as $v)
				   {	if ($v<=$term) return true; } break;
		case '>>=': foreach($valuelist as $v)
				   {	if ($v>=$term) return true; } break;
		case '~~': foreach($valuelist as $v)
				   {	$v = swNameURL($v);
						if ($v==$term) return true; } break;
		case '~*': foreach($valuelist as $v)
				   {	$v = swNameURL($v);
						if (substr($v,0,strlen($term))==$term) return true; } break;
		case '*~': foreach($valuelist as $v)
				   {	$v = swNameURL($v);
						if (substr($v,-strlen($term))==$term) return true; } break;
		case '*~*': foreach($valuelist as $v)
				   {    $v = swNameURL($v);
						if (stripos($v,$term) !== FALSE) return true; } break;						
		case '0': foreach($valuelist as $v)
				   {	if ($v != 0 || $v != '') return false; } break;
		case 'r=': foreach($valuelist as $v)
					{ if (preg_match($term, $v, $matches)) return true; }
					break;
		default:   return false;
	}
	return false;
}

function swQueryFieldlistCompare($revision, $fieldlist,$fields,$field,$operator,$term,$comparefields)
{
	// compares a tuple against an operation and a term and returns a tuple
	
	$row = array();
	
	// normalize array, to a table, but using only used fields and field
	$maxcount = count($fieldlist[$field]);
	foreach($fields as $v)
	{
		if (isset($fieldlist[$v]))
			$maxcount = max($maxcount,count($fieldlist[$v]));
	}	
	$fieldlist2 = array();
	foreach($fieldlist as $key=>$v)
	{
		for($fi=0;$fi<count($v);$fi++)
		{
			$fieldlist2[$fi][$key] = $v[$fi];
		}
		for ($fi=count($v);$fi<$maxcount;$fi++)
		{
			$fieldlist2[$fi][$key] = $v[count($v)-1];
		}
	}
	
	// compare
	for ($fi=0;$fi<$maxcount;$fi++)
	{
		$onefieldvalue = @$fieldlist2[$fi][$field];
		if ($comparefields)
		{
			$term2 = swQueryTupleExpression($fieldlist2[$fi], $term);
			if (is_array($term2))
			{
				return $term2; //error
			}
			else
				$found = swFilterCompare($operator,array($onefieldvalue),$term2);
		}
		else
			$found = swFilterCompare($operator,array($onefieldvalue),$term);
			
		if ($found)
		{
			
			foreach ($fields as $f)
			{
				// we cannot return an error here, because the data might be an old revision with other data scheme
				if ($f == '_rating')
				{
						$content = $fieldlist[$field];
						$content = array_shift($content);
						$contenturl = swNameURL($content);
						$termurl = swNameURL($term);
						
						//row value will be simple rating algorithm: 
						//counts the number of occurences and the position
						$rating = 0;
						$len0 = strlen($contenturl);
						while ($contenturl = stristr($contenturl,$termurl))
						{
							$rating += strlen($contenturl) * strlen($termurl) / $len0 / $len0 ;
							//echo $termurl."=".$contenturl." ";
							$contenturl = substr($contenturl,1);
						}
						//echo $rating;
						
						$row[$f][$revision.'-'.$fi] = sprintf('%09.3f',$rating);
				}
				else
					$row[$f][$revision.'-'.$fi] = @$fieldlist2[$fi][$f];
			}
		}
	}




	return $row;

}

function swFilter($filter,$namespace,$mode='query',$flags='',&$lastrev=0)
{
	
	global $swIndexError;
	global $swMaxSearchTime;
	global $swMaxOverallSearchTime;
	global $swStartTime;
	
	global $swRoot;
	global $db;
	$goodrevisions = array();
	$operator = '';
	$fields = array();
	$field = '';
	$term = '';
	$namefilter = '';
	$namefilter0 = '';
	$rowsort =false;
	
	if ($swIndexError) return $goodrevisions;
	
	if ($mode != 'query')
	{
		echotime('filter mode depreciated '.$mode);
		swNotify('filter','filtermodedepreciated','filter '.$mode,$filter);
	}
	// parse select string SELECT fields WHERE field operator term
	
	if (substr($filter,0,6) == 'SELECT')
	{
		$filter2 = substr($filter,7);
		
		if ($p = strpos($filter2,' FROM '))
		{
			//namefilter from query is not the same that the namespace that depends on 
			//the user rights
			$p+= strlen(' FROM ');
			if (!$p2 = strpos($filter2,' WHERE '))
				$p2 = strlen($filter2);
			$namefilter = $namefilter0 = substr($filter2,$p,$p2-$p);
			$filter2 = str_replace(' FROM '.$namefilter,'',$filter2);
			
			$namefilter = trim($namefilter);
			$namefilter = swNameURL($namefilter);
			
			// the filter has to use now the more specific of the namespace and the namefilter
			
			
			
			// namefilter for main namespace only
			if ($namefilter == 'main:')
			{	
				$namespace = '';
				$namefilter = '';
			}
									
			// if the namespace is all, then the new namespace is the namefilter
			elseif (stristr($namespace,'*'))
				$namespace = $namefilter;

			//VIRTUAL
			if (strpos($namespace, 'virtual-') === 0)
				$namespace = substr($namespace, strlen('virtual-'));

				
			// if the namefilter does not contain : then the new namespace is common namespace and all namespaces starting with namefilter
			elseif(!stristr($namefilter,':'))
			{
				$spaces = explode('|',$namespace);
				$newspaces = array();
				$newspaces[$namefilter] = $namefilter;
				foreach($spaces as $sp)
				{
					$sp = swNameURL($sp);
					$test = substr($sp,0,strlen($namefilter));
					if ($test == $namefilter)
						$newspaces[$sp] = $sp;
				}
				//echotime(print_r($newspaces,true));
				$namespace = join('|',$newspaces);
			}
			// if the namefilter contains : and is valid in the namespace then the new namespace is the namefilter
			else
			{
				$spaces = explode('|',$namespace);
				$newspaces = array();
				$ns = substr($namefilter,0,strpos($namefilter.':',':')); 
				$found = FALSE;
				foreach($spaces as $sp)
				{
					$sp = swNameURL($sp);
					if (stristr($ns,$sp) || stristr($namefilter,$sp)) $found = TRUE;
				}
				if ($found)
				{
					$namespace = $namefilter;
				}
				else
				{
					// if the namefilter contains : and is not valid, then an empty result is returned
					return(array('_error'=>'invalid name '.$namefilter));
				}
			}
						
			
		}
		
		
		if (!stristr($filter2,' WHERE '))
			$filter2 .= ' WHERE ';
		
		if ($p = strpos($filter2,' WHERE '))
		{
			$fields = substr($filter2,0,$p);
			$fs = explode(',',$fields);
			$fields = array();
			foreach($fs as $f)	{ $fields[]=trim($f); }
			$fields = array_unique($fields);
			
			
			$query = substr($filter2,$p+strlen(' WHERE '));
			$words = explode(' ',$query);
			$wordlist = array();
			foreach($words as $w) { if ($w != '') $wordlist[] = $w; }
			if (count($wordlist)>0)
			{
				$field = $wordlist[0]; 
				if (count($wordlist)>1)
				{
					$operator = $wordlist[1];
					unset($wordlist[1]);
				}
				else
					$operator = '*';
				unset($wordlist[0]);
				if (count($wordlist)>0)
					$term = trim(join(' ',$wordlist));
				else
					$term = '';
			}
			else
			{
				// find all
				$field = $fields[0];
				$operator = '*';
				$term = '';
			}
		}
	}
	
	echotime('filter ['.$mode.'|'.$namespace.'] '.$filter);
	
	
	$comparefields = false;
	if (substr($operator,0,1) == '$')
	{	
		$operator = substr($operator,1);
		$comparefields = true;
	}
	
	
	if (substr($filter,0,6) == 'FIELDS')
		$fields = array('fields');
	
	if ($operator == '~~'|| $operator == '*~'|| $operator == '~*'|| $operator == '*~*') 
		$term = swNameURL($term);

	// VIRTUAL
	if ($mode=='query' && stristr($namefilter0, 'VIRTUAL '))
	{
		echotime('virtual');
		$urlname = str_replace('VIRTUAL ','',$namefilter0);
		$urlname = trim($urlname);
		$urlname = swNameURL($urlname);
		if (stristr($urlname,':')) // page has namespace
		{
			$spaces = explode('|',$namespace);
			$newspaces = array();
			$ns = substr($urlname,0,strpos($urlname.':',':')); 
			$found = FALSE;
			foreach($spaces as $sp)
			{
				$sp = swNameURL($sp);
				if (stristr($ns,$sp) || stristr($urlname,$sp)) $found = TRUE;
			}
			if (!$found)
			{
				return(array('_error'=>'invalid name '.$urlname.' ('.$namespace.')'));
			}
	    }
		
		$w = new swWiki;
		$w->name = $urlname;
		$w->lookup();
		
		if ($w->revision == 0) return(array('_error'=>'unknown name '.$urlname));
		
		$w->parsedContent = $w->content;
		$fp = new swTidyParser;
		$fp->dowork($w);
		$fp = new swTemplateParser;
		$fp->dowork($w);
		
		$s = $w->parsedContent; //field output has nowiki tags
		$s = str_replace('<nowiki>','',$s);
		$s = str_replace('</nowiki>','',$s);
		
		$list = swGetAllFields($s);
		//echotime('list '.print_r($list,true)); 
		
		$row = swQueryFieldlistCompare($w->revision,$list,$fields,$field,$operator,$term,$comparefields);
		
		// flatten
		$r2 = array();
		foreach($row as $f=>$fs)
		{
			foreach($fs as $k=>$v)
			{
				$r2[$k][$f] = $v;
			}
		}
		return $r2;
	}
	
	
	
	// find already searched revisions
	$lastfoundrevision = 0;
	$mdfilter = $filter;
	$mdfilter .= $namespace;
	$mdfilter .= $mode;
	$mdfilter = urlencode($mdfilter);
	//echotime($mdfilter);
	$cachefile2 = $cachefile = $swRoot.'/site/queries/'.md5($mdfilter).'.txt';
	
	
	
	global $swDebugRefresh;
	if ($swDebugRefresh)
		{ $refresh=1; echotime('refresh');}
	else	
		$refresh=0;
		
	if (stristr($flags,'refresh')) $refresh=1;
	
	if (file_exists($cachefile) && !$refresh) 
	{
		$s = file_get_contents($cachefile);
		$results = unserialize($s);
		//echomem("open",true); 
		$lastfoundrevision = $results['lastfoundrevision'];
		
		
		$goodrevisions  = $results['goodrevisions'];
		if (isset($results['bitmap']))
			$bitmap = $results['bitmap'];
		else
			$bitmap = new swBitmap;
		echotime('cached '.count($goodrevisions).' / '.$lastfoundrevision.' <a href="index.php?name=special:indexes&index=queries&q='.md5($mdfilter).'" target="_blank">'.md5($mdfilter).'.txt</a>');
		unset($results);
		unset($s);
	}
	else
	{
		if (file_exists($cachefile))
			unlink($cachefile);
		$lastfoundrevision = 0;
		$goodrevisions = array();
		$bitmap = new swBitmap;
	}
	//echomem("cached",true); 	
	$maxlastrevision = $db->lastrevision;
	
	$bitmap->redim($maxlastrevision,true);

	// only search current versions if flag not set other
	$db->init();
	
	$cachechanged = false;
	
	$currentbitmap = $db->currentbitmap->duplicate();
	$deletedbitmap = $db->deletedbitmap->duplicate();
		
	if (count($goodrevisions)>0)
		$keys = array_keys($goodrevisions);
	else
		$keys = array();
		
	foreach($keys as $k)
	{
		if (stristr($k,'-'))
			$kr = substr($k,0,strpos($k,'-'));
		else
			$kr = $k;
		if(!$currentbitmap->getbit($kr) || $deletedbitmap->getbit($kr))
		{
			$bitmap->unsetbit($kr);
			unset($goodrevisions[$k]);
			$cachechanged = true; 
		}
	}

	echotime('current '.$bitmap->countbits().' / '.$db->lastrevision);
		
	if ($lastfoundrevision < $maxlastrevision || $cachechanged)
	{
		// cachechanged must provoke removal of obsolete revisions and save of new cachefile
		
		$bitmap->redim($maxlastrevision,true);
		
		$nowtime = microtime(true);	
		$dur = sprintf("%04d",($nowtime-$swStartTime)*1000);
		if ($dur>$swMaxOverallSearchTime) 
		{
			echotime('overtime overall');
			return $goodrevisions;   
		}
				
		// if there is an existing search on a substring, we can exclude all urls with no result
		// a cron tab will create searches on all possible strings with 3 characters
		// we therefore test again all substrings with 3 characters
		$lastrevision =$lastfoundrevision; 
	
			
			// restrict on namefilter
			if ($namefilter)
			{
					$filter2 = 'SELECT _revision WHERE _name ~* '.$namefilter;
					$maxfilter2revision = 0;
			    	$filter2revisions = swFilter($filter2,'*','query','internal',$maxfilter2revision); 
			    	foreach($filter2revisions as $k=>$v)
			    	{
			    		$r = $v['_revision'];
			    		if (is_array($r)) $r = array_shift($r);
			    		$f2rs[$r] = 1;
			    		$maxfilter2revision = max($r,$maxfilter2revision); // if it did not work with parameter passing
			    	}
					for($k=0;$k<=$maxfilter2revision;$k++)
					{
						if (!isset($f2rs[$k]))
							$bitmap->unsetbit($k);
					}
					
					echotime('- namefilter '.$bitmap->countbits());
			}
			
			if ($maxlastrevision - $lastfoundrevision > 50 ) // small searches reduction is not interesting
			{
				
				// if it is data search, we can restrict to all revisions that have the field
				if (isset($field) && (($mode == 'query' && substr($field,0,1) != '_' ) || ($mode == 'data' && $field != 'content'  && $field != 'name' && $field != '')) && $operator != '*')
				{
					
					$filter2 = 'SELECT _revision WHERE '.$field.' * ';
					$maxfilter2revision = 0;
					$filter2revisions = swFilter($filter2,'*','query','internal',$maxfilter2revision);  
					foreach($filter2revisions as $k=>$v)
			    	{
			    		$r = $v['_revision'];
			    		if (is_array($r)) $r = array_shift($r);
			    		$f2rs[$r] = 1;
			    		$maxfilter2revision = max($r,$maxfilter2revision); // if it did not work with parameter passing
			    	}
					for($k=0;$k<$maxfilter2revision;$k++)
					{
						if (!isset($f2rs[$k]))
							$bitmap->unsetbit($k);
					}
					echotime('- * '.$bitmap->countbits());
				}	
				
				if ($mode == 'relaxed' && strlen($filter)>=3)
				{
					for($i=0;$i<=strlen($filter)-3;$i++)
					{
						if ($bitmap->countbits()<20) continue;
						$f = substr($filter,$i,3);
						$gr = getTrigram($f);
						if ($gr)
						{
							$gr->redim($bitmap->length, true);
							$bitmap = $bitmap->andop($gr);
						}
						
						echotime('- '.$f.' '.$bitmap->countbits());
					}
				
				}
				
				// search only in records which have the field
				// and use also the 3letter-trick on the field
				if (isset($field) && strlen($field)>=3 && (($mode == 'query' && substr($field,0,1) != '_' ) || ($mode == 'data' && $field != 'content'  && $field != 'name'))  )
				{
						
					$field2 = swNameURL($field);
					for($i=0;$i<=strlen($field2)-3;$i++)
					{
						if ($bitmap->countbits()<20) continue;
						$f = substr($field2,$i,3);
						$gr = getTrigram($f);
						if ($gr)
						{
							$gr->redim($bitmap->length, true);
							$bitmap = $bitmap->andop($gr);
						}
						
						echotime('- '.$f.' '.$bitmap->countbits());
					}
						
						
				}
				
				// use the 3letter trick on the term (trigram)
				if (isset($term) && !$comparefields && strlen($term)>=3 && ( $operator == '==' || $operator == '*=' || $operator == '=*' 
				|| $operator == '*=*' 
				|| $operator == '~~'|| $operator == '*~'|| $operator == '~*'|| $operator == '*~*'))
				{
					
					if (strlen($term)>=3)
					{
						$term2 = swNameURL($term);
						for($i=0;$i<=strlen($term2)-3;$i++)
						{
							if ($bitmap->countbits()<20) continue;
							$f = substr($term2,$i,3);
							$gr = getTrigram($f);
							if ($gr)
							{
								$gr->redim($bitmap->length, true);
								$bitmap = $bitmap->andop($gr);
							}
						
							echotime('-term '.$f.' '.$bitmap->countbits());
						}
					}
				}
			
			}
			
			$starttime = microtime(true);
			if ($swMaxSearchTime<500) $swMaxSearchTime = 500;
			if ($swMaxOverallSearchTime<2500) $swMaxOverallSearchTime = 2500;
			global $swOvertime;
			$overtime = false;
			
			echotime('loop '.$lastfoundrevision);
			//echotime(print_r($bitmap->toarray(),true));
			//echomem("loop",true); 
			
			//echotime(print_r($bitmap->toarray()));
			
			for ($k=$lastfoundrevision+1;$k<=$maxlastrevision;$k++)
			{
				if(!$currentbitmap->getbit($k)) continue;
				if($deletedbitmap->getbit($k)) continue;
				
				if (!$bitmap->getBit($k) && $k<$maxlastrevision-16 ) continue; // last bits always check
				
				//echotime($k);  
				$nowtime = microtime(true);	
				$dur = sprintf("%04d",($nowtime-$starttime)*1000);
				if ($dur>$swMaxSearchTime) 
				{
					echotime('overtime '.$lastrevision.' / '.$maxlastrevision);
					$overtime = true;
					if (!stristr($flags,'internal'))
							$swOvertime=true;
					break;
				}
				$dur = sprintf("%04d",($nowtime-$swStartTime)*1000);
				if ($dur>$swMaxOverallSearchTime) 
				{
					echotime('overtime overall '.$lastrevision.' / '.$maxlastrevision);
					$overtime = true;
					if (!stristr($flags,'internal'))
							$swOvertime=true;
					break;
				}
	
				$lastrevision = $k;
				
				
				$record = new swRecord;
				$record->revision = $k;
				$record->lookup();
				
				

				$urlname = swNameURL($record->name);
				
				// no deleted
				
				if ($record->status == 'deleted') continue;
				if ($record->status == '') continue;
				
				
				// apply namefilter
				
				if ($namefilter != '' && substr($urlname,0,strlen($namefilter)) != $namefilter)
					continue;
				
				
				// apply namespace
				
				if (stristr($urlname,':') && $namespace != '*') // page has namespace
				{
					$spaces = explode('|',$namespace);
					$newspaces = array();
					$ns = substr($urlname,0,strpos($urlname.':',':')); 
					$found = FALSE;
					foreach($spaces as $sp)
					{
						$sp = swNameURL($sp);
						if ($sp != '')
						{
								if (stristr($ns,$sp) || stristr($urlname,$sp)) $found = TRUE;
						}
					}
					if (!$found)
					{
						continue;
					}
				}
				
				
				$content = $record->name.' '.$record->content;
				$row=array();
				
				$fieldlist = $record->internalfields;

				if ($filter == 'FIELDS')
				{
					$keys =array_keys($fieldlist);
					if (count($keys)>0)
						$row['fields'] = $keys;
				}
				elseif (substr($filter,0,6) == 'SELECT')
				{
					
					
					if ($mode=='query')
					{
						$fieldlist['_revision'][] = $record->revision;
						$fieldlist['_status'][] = $record->status;
						$fieldlist['_name'][] = $record->name;
						$fieldlist['_content'][] = $record->content;
						$fieldlist['_*'][] = $record->name."\n".$record->content;
					}
					else
					{
						$fieldlist['revision'][] = $record->revision;
						$fieldlist['status'][] = $record->status;
						$fieldlist['name'][] = $record->name;
						$fieldlist['content'][] = $record->content;
						$fieldlist['*'][] = $content;
					}
					
					// if ($mode=='query') echotime("query now $k $field ".print_r($fieldlist,true));
					
					
					if (!isset($fieldlist[$field])) continue;
					
					$row = array();
					if ($mode == 'query')
					{
						$row = swQueryFieldlistCompare($k,$fieldlist,$fields,$field,$operator,$term,$comparefields);
						if (isset($row['_error'])) return $row;
						
					}
					else
					{
						$found = swFilterCompare($operator,$fieldlist[$field],$term);
						if ($found)
						{
							foreach ($fields as $f)
							{
								if (isset($fieldlist[$f]))
									$row[$f]= $fieldlist[$f];
								else
									$row[$f] = "";
							}
						}
					}
					
				}
				
				if (count($row)>0)
				{
					$goodrevisions[$k] = $row;
				}
				else
					$bitmap->unsetbit($k);
			}
			
			
			
			
			
			echotime('good '.count($goodrevisions).' / '.$lastrevision);
			echomem("filter");	
			
			
			
			
			// save to cache
			
			$results=array();
			$results['filter'] = $filter;
			$results['mode'] = $mode;
			$results['namespace'] = $namespace;
			$results['bitmap'] = $bitmap;
			$results['lastfoundrevision'] = $lastrevision;
			$results['goodrevisions'] = $goodrevisions;
			$results['overtime'] = $overtime ;
			$lastrev=$lastrevision; // return internally
			
			$t = serialize($results);
			
			
			if ($handle = fopen($cachefile2, 'w')) { fwrite($handle, $t);  fclose($handle); }
			else { swException('Write error Query cache'); return;}
		
			echotime('saved');

		// we do not need allurls any more
		$allrevisions = NULL;
	
	}
	
	
	
	if ($rowsort)
	{
		
		foreach($goodrevisions as $k=>$v)
		{
			$goodrevisions[$k] = $v['_row'];
			$goodrevisions[$k] = $v['_row'];
		}
		arsort($goodrevisions);
	}
	
	
	if ($filter=="FIELDS")
	{
		$ts = array();
		foreach($goodrevisions as $k=>$v)
		{
			foreach($v['fields'] as $v)
			{
				$ts[$v]['field'] = $v;
			}	
		}
		if (is_array($ts))
			ksort($ts);
		$goodrevisions = $ts;
		
	}
	
	
	if ($mode=="query")
	{
		
		//echo "<p>";
		//print_r($goodrevisions);
		// flaten tuples
		$set = array();
		foreach($goodrevisions as $r)
		{
			$rowcount = 0;
			
			// we use fields from select statement here to enforce that every row has all fields
			
			foreach($fields as $key)
			{
				if (isset($r[$key]))
					$v = $r[$key];
				else
					$v = array();
				foreach($v as $rev=>$oneval)
				{
					$set[$rev][$key] = $oneval;
				}
			}
		}
		$goodrevisions = $set;
	
	
	}
		
	
	return $goodrevisions;
			
	
}



?>