<?php

if (!defined("SOFAWIKI")) die("invalid acces");


class swFieldsParser extends swParser
{

	
	function info()
	{
	 	return "Handles internal fields";
	}
	
	function dowork(&$wiki)
	{
		$s = $wiki->parsedContent;
		// internal links
		if (strpos($s,"::")===FALSE) return; 
		
		preg_match_all("@\[\[([^\]\|]*)([\|]?)(.*?)\]\]@", $s, $matches, PREG_SET_ORDER);
		
		foreach ($matches as $v)
		{
			
			$val = $v[1]; // link
			
			// handle fields
			
			// ignore internal variables
			if (substr($val,0,1)=="_") continue; 
			
			
			// handle internal fields
			if ($delim = strpos($val,"::"))	// we show only values		
			{ 
				$val = $v[1].$v[2].$v[3]; // we use everything 
				
				$fieldstring = substr($val,$delim+2);  
				$key = substr($val,0,$delim);
				
				$fields = explode('::',$fieldstring);
				
				$t = "";
				
				// if the field is alone in the line and there is no template, remove the newline also
				
				if (trim($t)=='')
				{
					$v0 =$v[0]."\n\r"; 
					$s = str_replace($v0,"",$s);
					$v0 =$v[0]."\r\n"; 
					$s = str_replace($v0,"",$s);
					$v0 =$v[0]."\n"; 
					$s = str_replace($v0,"",$s);
					$v0 =$v[0]."\r"; 
					$s = str_replace($v0,"",$s);
				}
				
				$s = str_replace($v[0],$t,$s);
				
			}
			
		}
		$wiki->parsedContent = $s;
		
		
	}

}

$swParsers["fields"] = new swFieldsParser;


?>