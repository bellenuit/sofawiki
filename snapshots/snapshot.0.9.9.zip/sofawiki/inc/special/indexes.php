<?php

if (!defined("SOFAWIKI")) die("invalid acces");



$swParsedName = "Special:Indexes";

if (!isset($_REQUEST['index'])) $_REQUEST['index'] = '';

if ($_REQUEST['index'] == 'indextrigram') {$t0 = GetLastTrigram(); swIndexTrigram(300);}
if ($_REQUEST['index'] == 'rebuildindex') {$l0 = $db->lastrevision;   $db->init(true);}

$swParsedContent = '
<p><a href="index.php?name=special:indexes&index=indexedbitmap">indexedbitmap</a>
<br><a href="index.php?name=special:indexes&index=currentbitmap">currentbitmap</a>
<br><a href="index.php?name=special:indexes&index=deletedbitmap">deletedbitmap</a>
<br><a href="index.php?name=special:indexes&index=protectedbitmap">protectedbitmap</a>
<br><a href="index.php?name=special:indexes&index=urls">urls</a>
<br><a href="index.php?name=special:indexes&index=trigram">trigram</a>
<br><a href="index.php?name=special:indexes&index=queries">queries</a>
<br>GetLastRevisionFolderItem = '.$db->GetLastRevisionFolderItem().'
<br>lastindex = '.$db->lastrevision .'
<br>lasttrigram = '.GetLastTrigram().'
<br><a href="index.php?name=special:indexes&index=rebuildindex">Rebuild Index</a>
<br><a href="index.php?name=special:indexes&index=indextrigram">Index Trigram</a>';

$swParsedContent .= "\n<form method='get' action='index.php'><p><pre>";
$swParsedContent .= "\n</pre><input type='hidden' name='name' value='special:indexes'>";
$swParsedContent .= "\n<input type='submit' name='submitresetcurrent' value='Reset Current' style='color:red'/>";
$swParsedContent .= "\n<input type='submit' name='submitresetqueries' value='Reset Queries' style='color:red'/>";
$swParsedContent .= "\n<input type='submit' name='submitresettrigram' value='Reset Trigram' style='color:red'/>";
$swParsedContent .= "\n<input type='submit' name='submitresetbitmaps' value='Reset Bitmaps' style='color:red'/>";
$swParsedContent .= "\n<input type='submit' name='submitreseturls' value='Reset URLs' style='color:red'/>";

$swParsedContent .= "\n<input type='submit' name='submitreset' value='Reset ALL' style='color:red'/>";
$swParsedContent .= "\n</p></form>";


	if (isset($_REQUEST['submitreset'])||isset($_REQUEST['submitresetcurrent']))
	{
		// delete all current
		$files = glob($swRoot.'/site/current/*.txt');
		foreach($files as $file) { unlink($file); }
		$swParsedContent = '<p>Deleted current';
	}
		
	if (isset($_REQUEST['submitreset'])||isset($_REQUEST['submitresetqueries']))
	{
		// delete all queries
		$files = glob($swRoot.'/site/queries/*.txt');
		foreach($files as $file) { unlink($file); }
		$swParsedContent .= '<p>Deleted queries';
	}
	
	if (isset($_REQUEST['submitreset'])||isset($_REQUEST['submitresettrigram']))
	{

		// delete all trigram
		$files = glob($swRoot.'/site/trigram/*.txt');
		foreach($files as $file) { unlink($file); }
		
		$file = $swRoot.'/site/indexes/lasttrigram.txt';
		@unlink($file); 	
	
		$swParsedContent .= '<p>Deleted trigram';
	}
	
	if (isset($_REQUEST['submitreset'])||isset($_REQUEST['submitresetbitmaps']))
	{

		// delete index folder
		@unlink($swRoot.'/site/indexes/indexedbitmap.txt');
		@unlink($swRoot.'/site/indexes/currentbitmap.txt');
		@unlink($swRoot.'/site/indexes/deletedbitmap.txt');
		@unlink($swRoot.'/site/indexes/protectedbitmap.txt');

		$db->indexedbitmap = new swBitmap;
		$db->currentbitmap = new swBitmap;
		$db->deletedbitmap = new swBitmap;
		$db->protectedbitmap = new swBitmap;
	
		$swParsedContent .= '<p>Deleted bitmaps';
	}

	if (isset($_REQUEST['submitreset'])||isset($_REQUEST['submitreseturls']))
	{

		// delete index folder
		@unlink($swRoot.'/site/indexes/urls.txt');
	
		$swParsedContent .= '<p>Deleted urls';
	}


if (isset($_REQUEST['submitreset']))
	{	
		$swParsedContent .= "\n<form method='get' action='index.php'><p><pre>";
		$swParsedContent .= "\n</pre><input type='hidden' name='name' value='special:indexes'>";
		$swParsedContent .= "\n<input type='submit' name='submit' value='Reopen' style='color:red'/>";
		$swParsedContent .= "\n</p></form>";

		echo $swParsedContent;
		exit;
	}



switch($_REQUEST['index'])
{
	case 'indexedbitmap': $swParsedContent .= '<h3>indexedbitmap</h3>';
						  $bm = $db->indexedbitmap;
						  $swParsedContent .= '<p>length: '.$bm->length;
						  $swParsedContent .= '<br>countbits: '.$bm->countbits();
						  $swParsedContent .= '<p>'.bitmap2canvas($bm);
						  break;
	case 'currentbitmap': $swParsedContent .= '<h3>currrentbitmap</h3>';
						  $bm = $db->currentbitmap;
						  $swParsedContent .= '<p>length: '.$bm->length;
						  $swParsedContent .= '<br>countbits: '.$bm->countbits();
						  $swParsedContent .= '<p>'.bitmap2canvas($bm);
						  break;
	case 'deletedbitmap': $swParsedContent .= '<h3>deletedbitmap</h3>';
						  $bm = $db->deletedbitmap;
						  $swParsedContent .= '<p>length: '.$bm->length;
						  $swParsedContent .= '<br>countbits: '.$bm->countbits();
						  $swParsedContent .= '<p>'.bitmap2canvas($bm);
						  break;
	case 'protectedbitmap': $swParsedContent .= '<h3>protectedbitmap</h3>';
						  $bm = $db->protectedbitmap;
						  $swParsedContent .= '<p>length: '.$bm->length;
						  $swParsedContent .= '<br>countbits: '.$bm->countbits();
						  $swParsedContent .= '<p>'.bitmap2canvas($bm);
						  break;

	case 'urls': 		$swParsedContent .= '<h3>urls</h3>';
	
						 $path = $swRoot.'/site/indexes/urls.txt';
						 $lines = file($path,FILE_IGNORE_NEW_LINES || FILE_SKIP_EMPTY_LINES);
						 $bm = new swBitmap;
						 foreach($lines as $line)
						 {
						 	$fields = explode("\t",$line);
							$r = $fields[0];
						 	$bm->setbit($r);
						 }
	
							
						  $swParsedContent .= '<p>length: '.$bm->length;
						  $swParsedContent .= '<br>countbits: '.$bm->countbits();
						  $swParsedContent .= '<p>'.bitmap2canvas($bm);
						  break;


	
	case 'trigram':			$swParsedContent .= '<h3>trigram</h3><p>';
							
							if (isset($_REQUEST['t']))
							{
								$bm = getTrigram($_REQUEST['t']);
								$swParsedContent .= $_REQUEST['t'];
						 	    $swParsedContent .= '<p>length: '.$bm->length;
						        $swParsedContent .= '<br>countbits: '.$bm->countbits();
								$swParsedContent .= '<p>'.bitmap2canvas($bm);
							}
							else
							{
								$list = trigramlist();
								foreach($list as $k=>$v)
								{
							 		$swParsedContent .= '<a href="index.php?name=special:indexes&index=trigram&t='.$v.'">'.$v.'</a> ';
								}
							}
							break;
							
	case 'queries':			$swParsedContent .= '<h3>queries</h3><p>';
	
							if (isset($_REQUEST['q']) && isset($_REQUEST['reset']) )
							{
								$path = $swRoot.'/site/queries/'.$_REQUEST['q'].'.txt';
								@unlink($path);
								
								$swParsedContent .= 'reset '.$_REQUEST['q'].'.txt';
								
								break;
								
							}
							
							if (isset($_REQUEST['q']))
							{
								$path = $swRoot.'/site/queries/'.$_REQUEST['q'].'.txt';
								if (file_exists($path))
									$s = file_get_contents($path);
								else
									$s = '';
								$results = unserialize($s);
								
								$swParsedContent .= '<p>filter: '.$results['filter'];
								$swParsedContent .= '<br>mode: '.$results['mode'];
								$swParsedContent .= '<br>namespace: '.$results['namespace'];
								$swParsedContent .= '<br>lastfoundrevision: '.$results['lastfoundrevision'];
								$swParsedContent .= '<br>goodrevisions: '.count($results['goodrevisions']);
								$bm = $results['bitmap'];
						 	    $swParsedContent .= '<br>length: '.$bm->length;
						        $swParsedContent .= '<br>countbits: '.$bm->countbits();
						        $swParsedContent .= '<br>overtime: '.$results['overtime'];
						        $t = filemtime($path);
							 	$d = date('Y-m-d',$t);
						        $swParsedContent .= '<br>modification: '.$d;
								$swParsedContent .= '<br>'.bitmap2canvas($bm);
								$swParsedContent .= '<p><a href="index.php?name=special:indexes&index=queries&q='.$_REQUEST['q'].'&reset=1">reset '.$_REQUEST['q'].'.txt</a> ';
							
								if (isset($_REQUEST['debug']))	
								{
									$swParsedContent .= print_r($results['goodrevisions'],true);
								}
							}
							else
							{
								$list = querylist();
								$swParsedContent .= 'count = '.count($list);
								
								$i = 0;
								foreach($list as $k=>$v)
								{
							 		$swParsedContent .= '<p><a href="index.php?name=special:indexes&index=queries&q='.$v.'">'.$v.'.txt</a> ';
							 		//biggest 25 and last 
							 		$t = filemtime($swRoot.'/site/queries/'.$v.'.txt');
							 		$d = date('Y-m-d',$t);
							 		if ($i<25 || time() - $t < 60*60)
							 		{
											$s = file_get_contents($swRoot.'/site/queries/'.$v.'.txt');
											$results = unserialize($s);
											$swParsedContent .= '<br>' .$d.' '.$results['mode'].' '.$results['namespace']. '<br>'.$results['filter'];
							 		}
							 		$i++;
							 		
								}
								
							}
							
							
							break;
						

	case "indextrigram": $swParsedContent .= '<h3>Index Trigram</h3><p>'.sprintf('%0d',GetLastTrigram() - $t0 ). ' revisions'; break;
	case "rebuildindex": $swParsedContent .= '<h3>Index Rebuild Index</h3><p>'.sprintf('%0d', $db->lastrevision-$l0).' revisions'; break;
}

function querylist()
{
	 global $swRoot;
	 $files = glob($swRoot.'/site/queries/*.txt');
	  
	 $list = array();
	 foreach($files as $file)
	 {
	   $key = sprintf('%05d',filesize($file));
	   	$fn = str_replace($swRoot.'/site/queries/','',$file);
	   	$fn = substr($fn,0,-4);
	   	$list[$key.' '.$fn] = $fn;
	 }
	 krsort($list);
	 return $list;
}
function bitmap2canvas($bm)
{
	$h = ceil($bm->length /512);
	$result = '<canvas id="myCanvas" width="512" height="'.$h.'"></canvas>
	<script type="text/javascript">
	var canvas=document.getElementById("myCanvas");
	var ctx=canvas.getContext("2d");
	ctx.fillStyle="#dddddd";
	ctx.fillRect(0,0,512,'.$h.');
	ctx.fillStyle="#000000";';
	
	$l = $bm->length;
	$list = '';
	for($i=0;$i<$l;$i++)
	{
		if ($bm->getbit($i))
		{
			$r = floor($i / 512);
			$c = $i % 512;
			$result .= 'ctx.fillRect('.$c.','.$r.',1,1);';
			$list .= $i.' ';
		}
	}
	
	$result .= '</script>';
	
	return $result.'<p>'.$list;
	
}

$swParseSpecial = false;


// print_r($_ENV);

?>