<?php

if (!defined("SOFAWIKI")) die("invalid acces");

function swSitemap()

{
		//echo "SITEMAP2";
		
		global $db;
		global $swBaseHrefFolder;
		$list = $db->GetAllUrls();
		ksort($list);
		
		// remove all redirects
		
		$filter = 'SELECT name WHERE content =* #REDIRECT';
		$result = swFilter($filter,'','data');
		
		//print_r($result);
		
		$exclusionlist = array();
		
		foreach($result as $item)
		{
			$name = array_shift($item['name']);
			$name = swNameURL($name);
			$exclusionlist[$name] = true;
		
		}
		//print_r($exclusionlist);
		
		
		
		
		$alluser = new swUser;

		$resultlist []= '<?xml version="1.0" encoding = "UTF-8"?>
    <urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';
    
    
    
    
		
		foreach ($list as $url=>$r)
		{
			if (!$alluser->hasright('view',$url)) continue; // only main namespace
			
			if (isset($exclusionlist[$url])) continue; // redirect
			
				$resultlist[] ='
			<url>
                <loc>'.$swBaseHrefFolder.$url.'</loc>
                <changefreq>weekly</changefreq>
                <priority>1.0</priority>
            </url>';
			
		}
		
		$resultlist []= '
	</urlset>';
	
	$result = join(' ',$resultlist);
	
	global $swRoot;
	$file = $swRoot.'/sitemap.xml';
	if ($handle = fopen($file, 'w')) { fwrite($handle, $result); fclose($handle); }
	else { echo swException('Write error sitemap'); $error = 'Write error sitemap';  return; }

}

?>
