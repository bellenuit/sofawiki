<?php


if (!defined('SOFAWIKI')) die('invalid acces');




function swQuery($filter,$namespace,$mode="relaxed")
{
	// split set in words and filter for each one, then combine them
	
	$filterlist = swQuerySplit($filter);  // will have to be more sophisticated to allow for spaces within [[field::value]]
	global $swSearchWordLimit;
	
	// we remove all terms with less than 3 characters and limit the list length
	$newfilterlist = array();
	for ($i=0;$i<count($filterlist);$i++)
	{
		$term = $filterlist[$i];
		if (strlen($term)>=3)
			$newfilterlist[] = $term;
		if (count($filterlist)==$swSearchWordLimit)
			break;
	}
	$filterlist = $newfilterlist;	

	// limit time for searches
	global $swMaxRelaxedSearchTime;
	$swMaxRelaxedSearchTime = $swMaxRelaxedSearchTime*2/(count($filterlist)+1);
	if (isset($_REQUEST['moreresults'])) $swMaxRelaxedSearchTime *=2;
	
	$revisionlists = array();
	
	foreach ($filterlist as $f)
	{
		$rev = swFilter($f,$namespace,$mode);
		$revisionlists[] = $rev;
	}
	$rev0 = array();
	$c = count($revisionlists);
	if ($c>0)
		$rev0 = $revisionlists[0];
	if ($c==1) return $rev0;
	for ($i=1;$i<$c;$i++)
	{
		$rev1 = $revisionlists[$i];
		//echo "<pre>";print_r($rev1);echo "</pre>";
		foreach($rev0 as $k=>$v)
		{
			//echo "<br>k $k v $v rev1 $rev1[$k]";
			if (isset($rev1[$k]))
				$rev0[$k] *= $rev1[$k];
			else
				unset($rev0[$k]);
		}
	}
	return $rev0;
}

function swFilter($filter,$namespace,$mode='query')
{
	global $swRoot;
	global $db;
	$goodrevisions = array();
	$operator = '';
	$over = false; 
	
	$rowsort =false;
	
	echotime('query '.$mode.' '.$filter);
	//echo $filter;

	// parse select string SELECT fields WHERE field operator term
	
	if ($mode=='data' && substr($filter,0,6) == 'SELECT')
	{
		$filter2 = substr($filter,7);
		
		if ($p = strpos($filter2,' WHERE '))
		{
			$fields = substr($filter2,0,$p);
			$fs = explode(',',$fields);
			$fields = array();
			foreach($fs as $f)	{ $fields[]=trim($f); }
			
			$query = substr($filter2,$p+strlen(' WHERE '));
			$words = explode(' ',$query);
			$wordlist = array();
			foreach($words as $w) { if ($w != '') $wordlist[] = $w; }
			$field = $wordlist[0]; 
			if (count($wordlist)>1)
			{
				$operator = $wordlist[1];
				unset($wordlist[1]);
			}
			else
				$operator = '*';
			unset($wordlist[0]);
			if (count($wordlist)>0)
				$term = trim(join(' ',$wordlist));
			else
				$term = '';
		}
	}
	
	
	
	if ($mode=='data' && substr($filter,0,6) == 'FIELDS')
		$fields = array('fields');
	
	if ($mode == 'relaxed') 
		$filter = swNameURL($filter);

	if ($mode == 'relaxed' || $mode == 'regex')
		$rowsort = true;

	if ($operator == '~~'|| $operator == '*~'|| $operator == '~*'|| $operator == '*~*') 
		$term = swNameURL($term);


	// find already searched revisions
	$lastfoundrevision = 0;
	$mdfilter = $filter;
	$mdfilter .= $mode;
	$mdfilter = urlencode($mdfilter);
	$cachefile2 = $cachefile = $swRoot.'/site/queries/'.md5($mdfilter).'.txt';
	
	
	global $swDebugRefresh;
	if ($swDebugRefresh)
		$refresh=1;
	else	
		$refresh=0;
	
	if (file_exists($cachefile)) 
	{
		if ($refresh)
		{
			unlink($cachefile);
			$lastfoundrevision = 0;
			$goodrevisions = array();
			echotime('refresh');
			
		}
		else
		{
			$s = file_get_contents($cachefile);
		
			$results = unserialize($s);
		
			$lastfoundrevision = $results['lastfoundrevision'];
			$goodrevisions  = $results['goodrevisions'];
			echotime('cached '.$lastfoundrevision);
		}
	}
	
	
	 
	
	
	
	// apply filter to new revisions of currently used names
	$allrevisions = $allrevisions0 = $db->GetCurrentRevisions();  
	
	$maxlastrevision = 0;
	$lastrevision = 0;
	// shorten the list, we have many loops
	foreach($allrevisions as $k=>$v)
	{
		if ($k < $lastfoundrevision) 
			unset($allrevisions[$k]);
		$maxlastrevision = max($k,$maxlastrevision);
	}
	
	// if it is data search, we can restrict to all revisions that have the field
	if (isset($field) && count($allrevisions)>10 && $mode == 'data' && $field != '' && $field != 'name' && $field != 'content' && $operator != '*')
	{
		$filter2 = 'SELECT name WHERE '.$field.' * ';
		$filter2revisions = swFilter($filter2,$namespace,'data');
		if (isset($filter2revisions['lastfoundrevision']))
			$maxfilter2revision = $filter2revisions['lastfoundrevision'];
		else
			$maxfilter2revision = 0;
		
		foreach($allrevisions as $k=>$v)
		{
			if ($k<$maxfilter2revision && !isset($filter2revisions[$k]))
				unset($allrevisions[$k]);
		}
		echotime('- * '.count($allrevisions));
	}	
	
	
	
	
	
	
	// if there is an existing search on a substring, we can exclude all urls with no result
	// a cron tab will create searches on all possible strings with 3 characters
	// we therefore test again all substrings with 3 characters
	if ($lastfoundrevision < $maxlastrevision)
	{
	
		//echotime('lfr '.$lastfoundrevision.' '. $maxlastrevision);
		if ($mode == 'relaxed' && strlen($filter)>=3)
		{
			$lfr = getLastTrigram();
			for($i=0;$i<=strlen($filter)-3;$i++)
			{
				if (count($allrevisions)<10) break;
				$f = substr($filter,$i,3);
				$gr = getTrigram($f);
				if (is_array($gr) && count($gr)>0)
				{
					$gr = array_flip($gr);
					foreach($allrevisions as $k=>$v)
					{
						if ($k>$lfr) continue;
						
						if (!isset($gr[$k]))
						{
							unset($allrevisions[$k]);
						}
					}
				}
				echotime('- '.$f.' '.count($allrevisions));
			}
		
		}
		
		// search only in records which have the field
		// and use also the 3letter-trick on the field
		if (isset($field) && $mode == 'data' && strlen($field)>=3 && $field != 'content'  && $field != 'name' && $filter != 'FIELDS' )
		{
				
			$field2 = swNameURL($field);
			$lfr = getLastTrigram();
			for($i=0;$i<=strlen($field2)-3;$i++)
			{
				if (count($allrevisions)<10) break;
				$f = substr($field2,$i,3);
				$gr = getTrigram($f);
				if (is_array($gr) && count($gr)>0)
				{
					$gr = array_flip($gr);
					foreach($allrevisions as $k=>$v)
					{
						if ($k>$lfr) continue;
						if (!isset($gr[$k]))
						{
							unset($allrevisions[$k]);
						}
					}
				}
				echotime('- '.$f.' '.count($allrevisions));
			}
				
				
		}
		
		// use the 3letter trick on the term (trigram)
		if (isset($term) && $mode == 'data'  && strlen($term)>=3 && ( $operator == '==' || $operator == '*=' || $operator == '=*' 
		|| $operator == '*=*' 
		|| $operator == '~~'|| $operator == '*~'|| $operator == '~*'|| $operator == '*~*'))
		{
			
			if (strlen($term)>3)
			{
				$term2 = swNameURL($term);
				$lfr = getLastTrigram();
				for($i=0;$i<=strlen($term2)-3;$i++)
				{
					if (count($allrevisions)<10) break;
					$f = substr($term2,$i,3);
					$gr = getTrigram($f);
					if (is_array($gr) && count($gr)>0)
					{
						$gr = array_flip($gr);
						foreach($allrevisions as $k=>$v)
						{
							if ($k>$lfr) continue;
							if (!isset($gr[$k]))
							{
								unset($allrevisions[$k]);
							}
						}
					}
					echotime('- '.$f.' '.count($allrevisions));
				}
			}
		}
		
		
		
		$lastrevision = $lastfoundrevision;
		
		ksort($allrevisions,SORT_NUMERIC);// if we break on overtime, we need to check by revision
		
		//print_r($allurls);
		
		$starttime = microtime(true);	
		global $swMaxRelaxedSearchTime;
		global $swMaxOverallSearchTime;
		if ($swMaxOverallSearchTime==0) $swMaxOverallSearchTime = 1000;
		global $swOvertime;
		global $swSearchNamespaces;
		
		echotime('loop');
		
		foreach($allrevisions as $k=>$val)
		{
			
			if ($mode == 'relaxed' && $swMaxRelaxedSearchTime>0)
			{
				$nowtime = microtime(true);	
				$dur = sprintf("%04d",($nowtime-$starttime)*1000);
				if ($dur>$swMaxRelaxedSearchTime)
				{
					echotime('overtime');
					$swOvertime=true;
					$over = true;
					break;
				}
				
			}
			
			if ($swMaxOverallSearchTime>0)
			{
				
				$nowtime = microtime(true);	
				$dur = sprintf("%04d",($nowtime-$starttime)*1000);
				if ($dur>$swMaxOverallSearchTime) 
				{
					echotime('overtime');
					$swOvertime=true;
					$over = true;
					break;
				}
			}	
			$lastrevision = max($k,$lastrevision);
			
			$record = new swRecord;
			$record->revision = $k;
			$ns = $record->wikinamespace();
			if ($ns != '' && !stristr($namespace.' ',$ns.' ') && $namespace!='*')
				continue;	
			
			$record->lookup();
			
			$content = $record->name.' '.$record->content;
			$row=array();
			
			switch($mode)
			{
			case 'data':
				$fieldlist = $record->internalfields;

				if ($filter == 'FIELDS')
				{
					$keys =array_keys($fieldlist);
					if (count($keys)>0)
						$row['fields'] = $keys;
				}
				elseif (substr($filter,0,6) == 'SELECT')
				{
					$fieldlist['revision'][] = $record->revision;
					$fieldlist['name'][] = $record->name;
					$fieldlist['content'][] = $record->content;
					$fieldlist['*'][] = $content;
					
					$row = array();
					
					if (!isset($fieldlist[$field])) continue;
					
					//echo ".";
					
					$found = false;
					switch ($operator)
					{
						case '=': foreach($fieldlist[$field] as $v)
								   {	if (floatval($v)==floatval($term)) $found = true; } break;
						case '<>': foreach($fieldlist[$field] as $v)
								   {	if (floatval($v)!=floatval($term)) $found = true; } break;
						case '<': foreach($fieldlist[$field] as $v)
								   {	if (floatval($v)<floatval($term)) $found = true; } break;
						case '>': foreach($fieldlist[$field] as $v)
								   {	if (floatval($v)>floatval($term)) $found = true; } break;
						case '<=': foreach($fieldlist[$field] as $v)
								   {	if (floatval($v)<=floatval($term)) $found = true; } break;
						case '>=': foreach($fieldlist[$field] as $v)
								   {	if (floatval($v)>=floatval($term)) $found = true; } break;
						case '==': foreach($fieldlist[$field] as $v)
								   {	if ($v==$term) $found = true; } break;
						case '!=': $found = true; foreach($fieldlist[$field] as $v)
								   {	if ($v==$term) $found = false; } break;
						case '=*': foreach($fieldlist[$field] as $v)
								   {	if (substr($v,0,strlen($term))==$term) $found = true; } break;
						case '*=': foreach($fieldlist[$field] as $v)
								   {	if (substr($v,-strlen($term))==$term) $found = true; } break;
						case '*=*': foreach($fieldlist[$field] as $v)
								   {	if (stripos($v,$term) !== FALSE) $found = true; } break;
						case '<<': foreach($fieldlist[$field] as $v)
								   {	if ($v<$term) $found = true; } break;
						case '>>': foreach($fieldlist[$field] as $v)
								   {	if ($v>$term) $found = true; } break;
						case '<<=': foreach($fieldlist[$field] as $v)
								   {	if ($v<=$term) $found = true; } break;
						case '>>=': foreach($fieldlist[$field] as $v)
								   {	if ($v>=$term) $found = true; } break;
						case '!~': $found = true; foreach($fieldlist[$field] as $v)
								   {    $v = swNameURL($v);
								   		if (stripos($v,$term) !== FALSE) $found = false; } break;
						case '~~': foreach($fieldlist[$field] as $v)
								   {	$v = swNameURL($v);
								   		if ($v==$term) $found = true; } break;
						case '~*': foreach($fieldlist[$field] as $v)
								   {	$v = swNameURL($v);
								   		if (substr($v,0,strlen($term))==$term) $found = true; } break;
						case '*~': foreach($fieldlist[$field] as $v)
								   {	$v = swNameURL($v);
								   		if (substr($v,-strlen($term))==$term) $found = true; } break;
						case '*~*': foreach($fieldlist[$field] as $v)
								   {    $v = swNameURL($v);
								   		if (stripos($v,$term) !== FALSE) $found = true; } break;						
					    case '*':  $found = true;  break;
						case '!0': foreach($fieldlist[$field] as $v)
								   {	if ($v != 0 || $v != '') $found = true; } break;
						case 'r=': foreach($fieldlist[$field] as $v)
									{ if (preg_match($term, $v, $matches)) $found = true; break; }
					}
					if ($found)
					{
						
						
						$row['_url'] = swNameURL($record->name);
						foreach ($fields as $f)
						{
							
							
							if (isset($fieldlist[$f]))
								$row[$f]= $fieldlist[$f];
							else
								$row[$f] = "";
	
						}
					}
					
				}
				
				if (count($row)>0)
					$goodrevisions[$k] = $row;
				break;
			case 'regex':
				$matches = array();
				$offset = 0;
				$row = 0;
				
				while (preg_match($filter, $content, $matches, PREG_OFFSET_CAPTURE, $offset))
				{
					if (is_array($matches[0]))
						$m = $matches[0][1];
					else
						$m = $matches[1];
					$row += 1 - ($m / (strlen($content)- $offset) );
					$offset += $m+1;
				}
				if ($row>0)
				{
					$goodrevisions[$k]['_row'] = sprintf('%09.3f',$row);
					$goodrevisions[$k]['_url'] = swNameURL($record->name);
				}
				
				break;
			case 'relaxed': // query
				$content = swNameURL($content);
			default:	
				if (stristr($content,$filter))
				{
					//row value will be simple rating algorithm: 
					//counts the number of occurences and the position
					
					$row = 0;
					$len0 = strlen($content);
					while ($content = stristr($content,$filter))
					{
						$row += strlen($content) / $len0;
						$content = substr($content,1);
					}
					$goodrevisions[$k]['_row'] = sprintf('%09.3f',$row);
					$goodrevisions[$k]['_url'] = swNameURL($record->name);
				}
				
			}
		}
		
		
		
		
		if (!$over)
			$lastrevision = max($lastrevision,$maxlastrevision);

		
		// save to cache
		
		$results=array();
		$results['filter'] = $filter;
		$results['mode'] = $mode;
		$results['lastfoundrevision'] = $lastrevision;
		$results['goodrevisions'] = $goodrevisions;
		$t = serialize($results);
		
		if ($handle = fopen($cachefile2, 'w')) { fwrite($handle, $t);  fclose($handle); }
		else { swException('Write error Query cache'); return;}
	
	} // if ($lastfoundrevision < $maxlastrevision)
	
	echotime('good '. count($goodrevisions));
	if (!$over)
		$lastrevision = max($lastrevision,$maxlastrevision);
	echotime('last ' . $lastrevision);
	
	
	// we do not need allurls any more
	$allrevisions = NULL;
	
	// now we have a list of good revisions.
	// we have to return only the last revision of each name
	
	
	$validrevisions = $allrevisions0;
	$record = new swRecord;
	
	
	foreach($goodrevisions as $k=>$v)
	{
		//echotime($k);
		if (!isset($validrevisions[$k]))
		{
			unset($goodrevisions[$k]);
		}
		else
			// check for namespace
		{
			if (isset($goodrevisions[$k]['_url']))
				$record->name = $goodrevisions[$k]['_url'];
			$ns = $record->wikinamespace();
			if ($ns == '' || stristr($namespace.' ',$ns.' ') || $namespace=='*')
			{
				// ok
			}
			else
				unset($goodrevisions[$k]);
		}
		
		unset($goodrevisions[$k]['_url']); // we do not need that any more 
	}
	
	
	if ($rowsort)
	{
		
		foreach($goodrevisions as $k=>$v)
		{
			$goodrevisions[$k] = $v['_row'];
		}
		arsort($goodrevisions);
	}
	
	
	if ($filter=="FIELDS")
	{
		foreach($goodrevisions as $k=>$v)
		{
			foreach($v['fields'] as $v)
			{
				$ts[$v]['field'] = $v;
			}	
		}
		if (is_array($ts))
			ksort($ts);
		$goodrevisions = $ts;
		
	}
	
	
	
	
	echotime('valid '. count($goodrevisions));
	return $goodrevisions;
			
	
}



?>