<?php

if (!defined('SOFAWIKI')) die('invalid acces');

$swParsedName = swSystemMessage('Search',$lang).': '.$query;

$ns = join(' ',$swSearchNamespaces);

echotime('query');

$names = array();
$allurls = $db->GetAllURLs();
$allrevisions = array_flip($allurls);

//echo " S3 ";

$foundname = false;
$found = false;

if  ($swQuickSearchinTitle && !isset($_REQUEST['allresults']))
{
	
	//echo " S4 ";
	$urlquery = swNameURL($query);
	$urlquerylist = explode('-',$urlquery);
	if ($swQuickSearchRedirect && $r = $allurls[$urlquery] )
	{
		
		$record = new swWiki;
		$record->revision = $r;
		$nsw = $record->wikinamespace();
		if ($nsw == '' ||�stristr($ns.' ',$nsw.' ') || $ns=='*')
		{
			
			$swParsedContent = '#REDIRECT [['.$urlquery.']]';
			$swParseSpecial = true;
			$found = true;
			$foundname = true;
		}
	}
	else
	{
		echotime ('qsit all');
		foreach($allurls as $k=>$v)
		{
			$thisfound = false;
			if (stristr($k,$urlquery))
			{
				$thisfound = true;
			}
			else
			{
				// now search for all not in order
				$allfound = true;
				foreach($urlquerylist as $word)
				{
					if (!stristr($k,$word))
						$allfound = false;
				}
				if ($allfound)
					$thisfound = true;
			}
			if ($thisfound)	
			{
				$record = new swWiki;
				$record->revision = $v;
				$nsw = $record->wikinamespace();
				if ($nsw == '' ||�stristr($ns.' ',$nsw.' ') || $ns=='*')
				{
					$names[$k] = $v;
					$found = true;
					$thisfound = true;
				}
			}
			
		}
	}
}


if (!$found)
{
	$revisions = swQuery(trim($query),$ns);
	foreach($revisions as $k=>$v)
	{
		$n = $allrevisions[$k];
		$names[$n] = $v;
	}
}

$swParseSpecial = false; 

if (!$foundname)
{

	$separator = "\n";
	$gprefix = '<ul>';
	$gpostfix = '</ul>';
	$limit = '';
	
	
	// function can reorder list and apply custom templates for each name
	if (function_exists('swInternalSearchHook')) 
	{
		$hookresult = swInternalSearchHook($names,$query);
		if ($hookresult)
		{
			$gprefix = ''; if (isset($hookresult['gprefix'])) $gprefix =  $hookresult['gprefix'];
			$gpostfix = ''; if (isset($hookresult['gpostfix'])) $gpostfix =  $hookresult['gpostfix'];
			$names = ''; if (isset($hookresult['names'])) $names =  $hookresult['names'];
			$separator = ''; if (isset($hookresult['separator'])) $separator =  $hookresult['separator'];
			if (isset($hookresult['limit'])) $limit =  $hookresult['limit'];
			
			$swParseSpecial = true; 
		}
	}
	
	
	if ($limit==0) $limit = 50;
	
	$start = 0; if (isset($_REQUEST['start'])) $start = $_REQUEST['start'];
	$count = count($names);
	global $lang;
	global $name;
	
	$navigation = '<nowiki><div class="categorynavigation">';
	if ($start>0)
		$navigation .= '<a href="index.php?action=search&query='.$query.'&start='.sprintf("%0d",$start-$limit).'"> '.swSystemMessage('back',$lang).'</a> ';
		
	$navigation .= " ".sprintf("%0d",min($start+1,$count))." - ".sprintf("%0d",min($start+$limit,$count))." / ".$count;
	if ($start<$count-$limit)
		$navigation .= ' <a href="index.php?action=search&query='.$query.'&start='.sprintf("%0d",$start+$limit).'">'.swSystemMessage('forward',$lang).'</a>';
	$navigation .= '</div></nowiki>';
	
	
	$searchtexts = array();
	
	
	
	$i=0;
	if (is_array($names) && count($names)>0)
	{
	foreach ($names as $k=>$v)
	{
		
		$i++;
		if ($i<=$start) continue; 
		if ($i>$start+$limit) continue; 
		
			$record = new swWiki;
			$record->name = $k;
			$record->lookup();
			
			
			
			if (substr($record->content,0,9) == '#REDIRECT') continue;
			
			$link = $record->link("");
			
			$dplen = strlen('#DISPLAYNAME');
			if (substr($record->content,0,$dplen)=='#DISPLAYNAME')
				{
					$pos = strpos($record->content,"\n");
					$record->name = substr($record->content,$dplen+1,$pos+1-$dplen-2);
				}
			
			
			
			if (($record->status=='ok' or $record->status=='protected') && $user->hasright('view', $record->name))
			{
				
					if (isset($hookresult) && $hookresult )
					{
						$searchtexts[] = $v;	
						
					}
					else
					{
	
						$t = "";
						$qs = swQuerySplit($query);
						if (stristr($record->content,$qs[0]))
						{
							
							$pos = stripos2($record->content, $qs[0]);
							$pos = max(0,$pos-80);
							if ($pos>0)
								$pos = stripos2($record->content, ' ', $pos);
							
							$pos2 = stripos2($record->content, ' ', min(strlen($record->content),$pos+160));
							
							if ($pos2===NULL || $pos2=='')
							{
								$record->content = substr($record->content,$pos); 
							}
							else
							{
								$record->content = substr($record->content,$pos,$pos2-$pos);  
							}
							$record->parsers = array();
							$record->parsers['nowiki'] = new swNoWikiParser;
							$t = $record->parse();
							
							
							foreach ($qs as $q)
								$t = swStrReplace($q,'<span class="found">'.$q.'</span>',$t);
							
						}
						
						$searchtexts[] = '<li><a href="'.$link.'">'.$record->name.'</a>
						<br/>'.$t.'</li>';
				
					}
			}
	}
	} // count >0
	
	//print_r($searchtexts);
	
	$swParsedContent = $navigation.$gprefix.join($separator,$searchtexts).$gpostfix.$navigation;
	
	//echo $swParsedContent;

}



if ($swParseSpecial)
{
	if ($found)  $swParsedContent.="\n".'<nowiki><a href="index.php?action=search&query='.$query.'&allresults=1">'.swSystemMessage('all results',$lang).'</a></nowiki>';
	elseif ($swOvertime)  $swParsedContent.="\n".'<nowiki><a href="index.php?action=search&query='.$query.'&allresults=1&moreresults=1">'.swSystemMessage('more results',$lang).'</a></nowiki>';
	$wiki->content = $swParsedContent;
	
	$wiki->parsers = $swParsers;
	$swParsedContent = $wiki->parse();
	
	//echo $swParsedContent;
}


?>