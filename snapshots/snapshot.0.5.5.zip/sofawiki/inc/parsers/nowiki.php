<?php

if (!defined("SOFAWIKI")) die("invalid acces");

class swNoWikiParser extends swParser
{

	function info()
	{
	 	return "Removes all wikitext";
	}


	function dowork(&$wiki)
	{

		$s = $wiki->parsedContent;
		
		// remove templates and images
		$s = preg_replace("/\{{([-\.\w\/\: \|,\'\p{Latin}\p{N}]+)\}}/u", "", $s);
		$s = preg_replace("/\[\[Image:([-\.\w\/\: \|,\'\p{Latin}\p{N}]+)\]\]/u", "", $s);
				
		// remove table code
		$s = preg_replace("/^\{\|(.*)$/", "", $s);
		$s = preg_replace("/^\|\-(.*)$/", "", $s);
		$s = preg_replace("/^\|\}(.*)$/", "", $s);
		$s = preg_replace("/^\| /", "", $s);
		$s = preg_replace("/\|\|/", "", $s);
		
		// links
     	$s = str_replace('[', "", $s);
     	$s = str_replace(']', "", $s);
     	$s = str_replace('{', "", $s);
     	$s = str_replace('}', "", $s);

		// remove linefeeds \n
		$s = str_replace("\r"," ",$s);
		$s = str_replace("\n"," ",$s);
	
		// headers
     	$s = str_replace('====', "", $s);
     	$s = str_replace('===', "", $s);
     	$s = str_replace('==', "", $s);
     	
     	// list
     	$s = str_replace('****', "", $s);
     	$s = str_replace('***', "", $s);
     	$s = str_replace('**', "", $s);
     	$s = str_replace('*', "", $s);
     	
				
		// bold and italics
        $s = str_replace("'''", "", $s);
        $s = str_replace("''", "", $s);
        $s = str_replace("'", "", $s);

		
		$wiki->parsedContent = $s;
		
	}

}
// normally not added
// $parsers["nowiki"] = new swStyleParser;



?>