<?php

if (!defined("SOFAWIKI")) die("invalid acces");


function swImageDownscale($name, $destw)
{
    //  ImageCreateTrueColor not supported on local php distribution mac
	global $swRoot;

	$destw = sprintf("%03d",$destw);
	$path0 = "$swRoot/site/files/$name";
	@mkdir("$swRoot/site/cache/");
	$returnpath = "site/cache/$destw"."-"."$name";
	$path1 = "$swRoot/$returnpath";
	
	if (file_exists($path1))
		return $returnpath;
		
		
	switch (substr($name,-4))
	{
		case ".jpg" : ;
		case "jpeg" : $img = ImageCreateFromJpeg($path0); break;
		case ".png" : $img = ImageCreateFromPNG($path0); break;
		case ".gif" : $img = ImageCreateFromGIF($path0); break;
		
		case ".pdf" : return false;
		default: return false;
	}
	
	
	if ($img)
	{
		$sourcew = ImagesX($img);
		$sourceh = ImagesY($img);
		$desth = $destw *$sourceh / $sourcew; 
	
	
		$back = ImageCreateTrueColor($destw,$desth);
		ImageCopyResampled($back, $img, 0,0,0, 0, $destw, $desth, $sourcew, $sourceh);

		imagejpeg($back,$path1,90);
		
		imagedestroy($img);
		imagedestroy($back);
		
		return $returnpath;
	}

}




?>