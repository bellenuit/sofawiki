<?php

if (!defined("SOFAWIKI")) die("invalid acces");


function swCron()
{
	
	if (function_exists('swInternalCronHook') && swInternalCronHook()) 
	{
		// everything is handled by configuration.php
	}
	else
	{
		// do some housework by default from time to time
		global $swRoot;
		$today = date("Y-m-d",time());
		switch(rand(0,100))
		{
			case 0: echotime('cron index'); global $db; $db->init(true); break; // rebuild indexes 
			
			case 1: echotime('cron trigram'); swIndexTrigram();  break; 
			
			case 2: echotime('cron fields'); swIndexRandomFields(1000);  break; 
			
			case 3: echotime('cron sitemap'); swSitemap();  break; 
			
			case 4: echotime('cron hunt'); swHuntDuplicates(); break;
			
			case 5: echotime ('cron bak url');	
					$path = $swRoot.'/site/indexes/urls.txt';
					if(file_exists($path)) copy($path,$path.'.'.$today.'.bak');
					break;
			case 6: echotime ('cron bak current'); 	
					$path = $swRoot.'/site/indexes/currentbitmap.txt';
					if(file_exists($path)) copy($path,$path.'.'.$today.'.bak');
					break;
			case 7: echotime ('cron bak deleted');	
					$path = $swRoot.'/site/indexes/deletedbitmap.txt';
					if(file_exists($path)) copy($path,$path.'.'.$today.'.bak');
					break;
			case 8: echotime ('cron bak protected'); 	
					$path = $swRoot.'/site/indexes/protectedbitmap.txt';
					if(file_exists($path)) copy($path,$path.'.'.$today.'.bak');
					break;

			
			default:
		
		}
		
		
	}
}



function swIndexRandomFields($maxtime)
{
	global $swMaxOverallSearchTime;
	$mrst = $swMaxOverallSearchTime;
	$swMaxOverallSearchTime=$maxtime;
	global $swSearchNamespaces;
	$ns = join(' ',$swSearchNamespaces);
	
	$q = swFilter('FIELDS',$ns,'data');
	$f = '';
	if (is_array($q))
	{
		$q = array_keys($q);
		shuffle($q);
		$f = array_pop($q);
	}
	if ($f != '')
	{
		$w = 'SELECT name WHERE '.$f.' *';
		$q2 = swFilter($w,$ns,'data');
	}

	$swMaxOverallSearchTime = $mrst;	
}

function swHuntDuplicates($first='')
{

	// normally, $record->writecurrent is responsible for unsetting the current bitmap when 
	// a new record is written.
	// however, when you rebuild the index, this is not done.
	// this cronjob checks for duplicates and removes earlier versions
	global $db;
	echotime ('hunt');
	
	global $swRoot;
	$path = $swRoot.'/site/indexes/urls.txt';
	$result = array();
	if (file_exists($path))
	{
		$lines = file($path,FILE_IGNORE_NEW_LINES || FILE_SKIP_EMPTY_LINES);
		if (count($lines)==0)
			return;
		
		$names = array();
		$revisions = array();
		$maxrevision = 0;
		foreach($lines as $line)
		{
			$fields = explode("\t",$line);
			$r = $fields[0];
			$n = $fields[1];
			$names[$r] = $n;
			$revisions[$n] = $r;
			$maxrevision = max($maxrevision,$r);
		}
		
		for($r = 0; $r<= $maxrevision; $r++)
		{
			if (isset($names[$r]))
			{
				$n = $names[$r];
				if ($r >= $revisions[$n])
					$db->currentbitmap->setbit($r);
				else
					$db->currentbitmap->unsetbit($r);
			}
			else
				$db->currentbitmap->unsetbit($r);
		
		}
		
	}

}



?>