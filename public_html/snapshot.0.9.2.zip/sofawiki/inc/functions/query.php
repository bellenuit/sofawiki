<?php

if (!defined("SOFAWIKI")) die("invalid acces");

// utf8


// from http://www.php.net/manual/fr/function.array-multisort.php 
// modified

// modifiers: ! DESC  # NUMERIC
function array_sort_func($a,$b=NULL) { 
   static $keys; 
   if($b===NULL) return $keys=$a; 
   
   foreach($keys as $k) 
   { 
      $numeric = false;
      $desc = false;
      if (stristr($k,'#')) { $numeric = true; $k = str_replace('#','',$k);}
      if (stristr($k,'!')) { $desc = true;  $k = str_replace('!','',$k) ;}
      
      if ($numeric)
      {
      	$fa = floatval(@$a[$k]);
      	$fb = floatval(@$b[$k]);
      	$p = 1;
      	if ($desc) $p = -1;
      	if ($fa > $fb) return $p;
      	if ($fa < $fb) return -$p;
      }
      else
      {
      	if(@$a[$k]!==@$b[$k]) 
      
         if ($desc)
         	return strcmp(@$b[$k],@$a[$k]); 
         else
         	return strcmp(@$a[$k],@$b[$k]); 
      }
    } 
   return 0; 
} 

function array_sort($keys) { 

	//print_r($keys);

   $array = @$keys[0]; 
   if (!is_array($array)) $array = array();
   array_shift($keys); 
   array_sort_func($keys); 
   usort($array,"array_sort_func");  
   return $array;
} 


function swQueryTupleExpression($row, $term) 
{
	$quotes = explode('"',$term);
	
	for($i=0;$i<count($quotes);$i+=2)
	{
		$arg = '';
		// unquoted
		if ($quotes[$i] != '')
		{
			$args = explode(" ",$quotes[$i]);
			foreach($args as $arg)
				$arguments[]=$arg;
		}
		else
		{
			// escape quote
			if (count($arguments))
			{
				$arg = substr(array_pop($arguments),1).'"';
			}
		}
			
		if ($i+1<count($quotes))
		{
			$arguments[]='"'.$arg.$quotes[$i+1];
		}
	}
	
	//print_r($arguments);
	
	// $arguments = explode(' ',$term);
	
	
	$calcstack = array();
	foreach($arguments as $arg)
	{
		if (array_key_exists($arg,$row))
		{
			array_push($calcstack,$row[$arg]);
		}
		else
		{
			switch ($arg)
			{
				case '': break;
				case '+' : 
					  if (count($calcstack)<2) { return array('_error'=>'Expression Stack empty error +');	}
					  $a = array_pop($calcstack); 
					  $b= array_pop($calcstack); 
					  array_push($calcstack,$b+$a); break;
				case '-' : 
					  if (count($calcstack)<2) { return array('_error'=>'Expression Stack empty error -');	}
					  $a = array_pop($calcstack); 
					  $b= array_pop($calcstack); 
					  array_push($calcstack,$b-$a); break;
				case '*' : 
				      if (count($calcstack)<2) { return array('_error'=>'Expression Stack empty *'); 	}
					  $a = array_pop($calcstack); 
					  $b= array_pop($calcstack); 
					  array_push($calcstack,$b*$a); break;
				case '/' :
				      if (count($calcstack)<2) { return array('_error'=>'Expression Stack empty /'); 	}
					  $a = array_pop($calcstack); 
					  $b= array_pop($calcstack);
					  if ($a == 0)  { return array('_error'=>'Expression division by zero'); 	}
					  array_push($calcstack,$b/$a); break;
				case '.' : 
				      if (count($calcstack)<2) { return array('_error'=>'Expression Stack empty .'); 	}
					  $a = array_pop($calcstack); 
					  $b= array_pop($calcstack); 
					  array_push($calcstack,$b.$a); break;
				case '::' : 
				      if (count($calcstack)<2) { return array('_error'=>'Expression Stack empty ::'); 	}
					  $a = array_pop($calcstack); 
					  $b= array_pop($calcstack); 
					  array_push($calcstack,$b.'::'.$a); break;
				case 'SUBSTR' : 
				      if (count($calcstack)<3) { return array('_error'=>'Expression Stack empty SUBSTR'); 	}
					  $a = array_pop($calcstack); 
					  $b= array_pop($calcstack); 
					  $s= array_pop($calcstack); 
					  array_push($calcstack,substr($s,$b,$a)); break;
				case 'REPLACE' : 
				      if (count($calcstack)<3) { return array('_error'=>'Expression Stack empty SUBSTR'); 	}
					  $a = array_pop($calcstack); 
					  $b= array_pop($calcstack); 
					  $s= array_pop($calcstack); 
					  array_push($calcstack,str_replace($b,$a,$s)); break;
				case 'TRIM' : 
				      if (count($calcstack)<1) { return array('_error'=>'Expression Stack empty TRIM'); 	}
					  $a = array_pop($calcstack); 
					  array_push($calcstack,trim($a)); break;
				case 'ABS' : 
				      if (count($calcstack)<1) { return array('_error'=>'Expression Stack empty ABS'); 	}
					  $a = array_pop($calcstack); 
					  array_push($calcstack,abs($a)); break;
				case 'SIGN' : 
				      if (count($calcstack)<1) { return array('_error'=>'Expression Stack empty SIGN');	}
				      $a = array_pop($calcstack); 
					  if ($a>0) $b=1; elseif($a<0) $b=-1; else $b=0;
					  array_push($calcstack,$b); break;
				case 'COPY' : 
				      if (count($calcstack)<1) { return array('_error'=>'Expression Stack empty COPY'); 	}
					  $a = array_pop($calcstack); 
					  array_push($calcstack,$a);
					  array_push($calcstack,$a);break;
				case 'POP' : 
				      if (count($calcstack)<1) { return array('_error'=>'Expression Stack empty POP'); 	}
					  $a = array_pop($calcstack);  break;
				case 'SWAP' : 
				      if (count($calcstack)<2) { return array('_error'=>'Expression Stack empty SWAP'); 	}
					  $a = array_pop($calcstack); $b = array_pop($calcstack); 
					  array_push($calcstack,$a); array_push($calcstack,$b); break;
				default: 
						switch(substr($arg,0,1))
						{
							case '-': case '0': case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9': 
								array_push($calcstack,$arg); break; //should check also all other letters.
							
							case '"': array_push($calcstack,substr($arg,1)); break;  
							
							default : array_push($calcstack,$arg); break; 
								
							
							//default : return array('_error'=>'Missing field '.$arg); 
						}
			}
		}
	
	}
	
	return array_pop($calcstack); 

}

function swQuerySetKey($set, $term)
{
	$set2 = array();
	if (!is_array($set)) return $set2;
	if (!is_string($term)) return $set2;
	foreach($set as $key=>$row)
	{
		$sortkey = swQueryTupleExpression($row,$term);
		if (is_array($sortkey)) //error
			return $term;
		$set2[$sortkey] = $row;
	}
	return $set2;
}

function swQueryRenameColumn($set, $oldcolumn, $newcolumn)
{
	$set2 = array();
	if (!is_array($set)) return $set2;
	if (!is_string($oldcolumn)) return $set;
	if (!is_string($newcolumn)) return $set;
	foreach($set as $key=>$row)
	{
		$elem = $row;
		$elem[$newcolumn]=@$elem[$oldcolumn];
		unset($elem[$oldcolumn]);
		$set[$key] = $elem;
	}
	return $set;
}



class swQueryFunction extends swFunction
{
	
	
	var $searcheverywhere = false;
	var $outputraw = false;
	
	function info()
	{
	 	return "(arguments) returns a database search as table";
	}

	
	function dowork($args)
	{
		
		$starttime = microtime(true);
		$datatablestyle='';
		
		$rowstack = array();
		$errorline = '';
		$result = '';
		$error = '';
		$numbercolumns = array();
		$outputformat = 'HTML';
		$showkey = false;
		$verbose = false;
		global $lang;
		
		global $swMaxOverallSearchTime;
		$swMaxOverallSearchTime = $swMaxOverallSearchTime*5/(count($args)+1);
		
		global $swSearchNamespaces;
		$ns = join(' ',$swSearchNamespaces).' ';
		
		if (stristr($ns,'*')) $ns = '*';
		
		if ($this->searcheverywhere) $ns = '*';
						
		foreach($args as $line)
		{
			$outerjoin = $leftjoin = false;
			
			if ($error) continue;
			
			$line = trim($line);
			if ($line=='') continue;
			
			$fs = explode(' ',$line);
			$command = array_shift($fs);
			
			
			$datatablestyle = 'queryfunction';
			switch ($command)
			{
				case 'STYLE': 	if (!array_key_exists(0,$fs)) { $error = 'Missing style';  $errorline = $line; break; }
								$datatablestyle = join(' ',$fs);
								break;


				case 'SELECT': 	$ns2 = '';
								if (stristr($line,' FROM '))
								{
									
									$pos1 = strpos($line,' FROM ')+ strlen(' FROM ');
									if (stristr($line,' WHERE '))
										$pos2 = strpos($line,' WHERE ');
									else
										$pos2 = strlen($line);
									$ns2 = substr($line,$pos1,$pos2-$pos1);

									// check ns 2 for allowed namespaces
									/*
									if (stristr($ns2,':'))
									{
										if (! stristr($ns,str_replace(':','',$ns2)))
										{
											//$line = str_replace(' FROM '.$ns2,'',$line);
											$error = 'Invalid FROM'; 
											$errorline = $line;
											continue;
											
										}
									}
									*/
								}

								$set = swFilter($line,$ns,'query','current');
								if (isset($set['_error']))
								{	
									$error = $set['_error']; $errorline = $line; break;
								}

								array_push($rowstack,$set); break;

				case 'IMPORT':  if (!array_key_exists(0,$fs)) { $error = 'Missing pagename'; $errorline = $line; break; }
								$mode = array_shift($fs);
								$iname = swNameURL(array_shift($fs));
								if (stristr($iname,':')) // page has namespace
								{
									if ($ns =='') 
									{ $error = 'invalid name'; $errorline = $line; break; }
					
									$inamens = substr($iname,0,strpos($iname,':')); // get namespace of page
									if (!stristr($ns.'-',$inamens.'-') && $ns!='*')
										{ $error = 'invalid name'; $errorline = $line; break; }
	   							}			
				
								$w = new swWiki;
								$w->name = $iname;
								$w->lookup();
								
								switch ($mode)
								{ 
								
									case "TAB":
								
									$rows = explode("\n",$w->content);
									$firstline = array_shift($rows);
									$fs = explode("\t",$firstline);
									$rs = array();
									foreach($rows as $row)
									{
										$l = explode("\t",$row);
										$r = array();
										for($i=0;$i<count($fs);$i++)
										{	
											$r[$fs[$i]] = $l[$i];
										}
										$rs[] = $r;
									}
									break;
									
								}
								
									array_push($rowstack,$rs); break;
				
				
				case 'WHERE':   if (!array_key_exists(0,$fs)) { $error = 'Missing field'; $errorline = $line; break; }
								if (!array_key_exists(1,$fs)) { $error = 'Missing operator'; $errorline = $line; break; }
								if (count($rowstack)<1) { $error = 'Empty stack'; $errorline = $line; break; }
								$field = array_shift($fs);
								$operator = array_shift($fs);
								$term = join(' ',$fs);
								
								$comparefields = false;
								if (substr($operator,0,1) == '$')
								{	
									$operator = substr($operator,1);
									$comparefields = true;
								}
								
								$r = array_pop($rowstack);
								
								$r2 = array();
								
								//$result .= print_r($r,true);
								foreach($r as $k=>$v)
								{
									
									if ($comparefields)
									{
										
										
										$term2 = swQueryTupleExpression($v, $term);
										if (is_array($term2))
										{
											$error = $term2['_error']; $errorline = $line; break;
										}
										
										
										
										$test = swFilterCompare($operator,@$v[$field],$term2);
									
										
										
									}
									else
									{
										if (!isset($v[$field]))
										{
											$error = 'missing field '.$field; $errorline = $line; break;
										}
											
										$test = swFilterCompare($operator,$v[$field],$term);
									}
									
									if ($test)
									{
										
										$r2[$k] = $v;
									}
								}
								
								array_push($rowstack,$r2); 
									break;
									
				case "FORSELECT" : if (count($rowstack)<1) { $error = 'Empty stack'; $errorline = $line; break; }
								   $forarray = array_pop($rowstack);
				
									if (stristr($line,' FROM '))
									{
									
										$pos1 = strpos($line,' FROM ')+ strlen(' FROM ');
										if (stristr($line,' WHERE '))
											$pos2 = strpos($line,' WHERE ');
										else
											$pos2 = strlen($line);
										$ns2 = substr($line,$pos1,$pos2-$pos1);
	
										// check ns 2 for allowed namespaces
										/*
										if (stristr($ns2,':'))
										{
											if (! stristr($ns,str_replace(':','',$ns2)))
											{
												//$line = str_replace(' FROM '.$ns2,'',$line);
												$error = 'Invalid FROM'; 
												$errorline = $line;
												continue;
												
											}
										}
										*/
									}
									$first = 1;
									$set = array();
									foreach($forarray as $row)
									{
										$v = array_pop($row);
										$q = substr($line,3).' '.$v;
										//echo $q;
										$setr = swFilter($q,$ns,'query','current');
										if (isset($setr['_error']))
										{
											$error = $setr['_error']; $errorline = $line; break;
										}
										foreach($setr as $sk=>$sr)
											$set[$sk] = $sr;

									}
									array_push($rowstack,$set); 
									break;
									
					
				case 'FIELDS': array_push($rowstack,swFilter('FIELDS',$ns,'data')); break;
				
				case 'KEY': 	if (!array_key_exists(0,$fs)){ $error = 'Missing key'; $errorline = $line; break; }
								if (count($rowstack)<1) { $error = 'Empty stack'; $errorline = $line; break; }
								$term = join(' ',$fs);
								$r = array_pop($rowstack); 
								$r2 = swQuerySetKey($r, $term);
								if (isset($r2['_error']))
								{
									 $error = $r2['_error']; $errorline = $line; break;
								}
								array_push($rowstack,$r2); 
								break;
				case 'ORDER': 	if (!array_key_exists(0,$fs)) { $error = 'Missing fieldlist'; $errorline = $line; break; }
				                if (count($rowstack)<1) { $error = 'Empty stack'; $errorline = $line; break; }
								$orders = explode(',',join(' ',$fs));
								$r = array_pop($rowstack); 
								$keys = array();
								$keys[] = $r;
								
								foreach($orders as $o)
								{
									$pars = explode(' ',$o);
									if ($pars[0] == '') array_shift($pars);
									
									$key = $pars[0];
									
									if (stristr($o,'DESC'))
										$key = '!'.$key;
									if (stristr($o,'NUMERIC'))
										$key = '#'.$key;
									
									$keys[] = $key;
								}
								$r2 = array_sort($keys);
								array_push($rowstack,$r2);
								break;
							  
				case "OR": 		if (count($rowstack)<2) { $error = 'Empty stack'; $errorline = $line; break; }
								$term = @$fs[0];
				   
								$r = array_pop($rowstack); 
								$r2 = array_pop($rowstack); 
								$rows2 = array();
								
								if ($term)
								{
									$r = swQuerySetKey($r, $term);
									if (isset($r['_error']))
									{
									 	$error = $r['_error']; $errorline = $line; break;
									}
									$r2 = swQuerySetKey($r2, $term);
									if (isset($r2['_error']))
									{
									 	$error = $r2['_error']; $errorline = $line; break;
									}
								}
								
								foreach($r as $key=>$value)
								{
									$rows2[$key] = $value;
								}
								foreach($r2 as $key=>$value)
								{
									$rows2[$key] = $value;
								}
								array_push($rowstack,$rows2); 
								break;
	
								
								
				
				case "AND": 	if (count($rowstack)<2) { $error = 'Empty stack'; $errorline = $line; break; }
								$term = @$fs[0];
								$r = array_pop($rowstack); 
								$r2 = array_pop($rowstack); 
								$rows2 = array();
								
								if ($term)
								{
									$r = swQuerySetKey($r, $term);
									if (isset($r['_error']))
									{
										 $error = $r['_error']; $errorline = $line; break;
									}
									$r2 = swQuerySetKey($r2, $term);
									if (isset($r2['_error']))
									{
										 $error = $r2['_error']; $errorline = $line; break;
									}
								}
								
								foreach($r as $key=>$value)
								{
									
									if (array_key_exists($key,$r2))
										$rows2[$key] = $value;
								}
								array_push($rowstack,$rows2);
								break;
				case "EXCEPT": 	if (count($rowstack)<2) { $error = 'Empty stack'; $errorline = $line; break; }
								$term = @$fs[0];
								$r = array_pop($rowstack); 
								$r2 = array_pop($rowstack); 
								
								if ($term)
								{
									$r = swQuerySetKey($r, $term);
									if (isset($r2['_error']))
									{
										 $error = $r2['_error']; $errorline = $line; break;
									}
									$r2 = swQuerySetKey($r2, $term);
									if (isset($r2['_error']))
									{
										 $error = $r2['_error']; $errorline = $line; break;
									}
								}
								
								$rows2 = array();
								foreach($r2 as $key=>$value)
								{
									if (!array_key_exists($key,$r))
										$rows2[$key] = $value;
								}
								array_push($rowstack,$rows2);
								break;
								
				case 'CROSS':   if (count($rowstack)<2) { $error = 'Empty stack'; $errorline = $line; break; }
								$r = array_pop($rowstack); 
								$r2 = array_pop($rowstack); 
								$r3 = array();
								foreach ($r as $key=>$row)
								{
									foreach($r2 as $key2=>$row2)
									{
										$r3[$key.'::'.$key2] = $row + $row2;
									}
								}
								array_push($rowstack,$r3);
								break;
				
				case 'OUTERJOIN': $outerjoin = true;
				case 'LEFTJOIN': $leftjoin = true;
				case 'JOIN':	if (count($rowstack)<2) { $error = 'Empty stack'; $errorline = $line; break; }
								if (!array_key_exists(0,$fs)) { $error = 'Missing field'; $errorline = $line; break; }
								$term = join(' ',$fs);
								$r2 = array_pop($rowstack); 
								$r= array_pop($rowstack); 
								
								foreach ($r as $key=>$row)
								{
									$joinvalue = swQueryTupleExpression($row, $term);
									
									if (is_array($joinvalue))
									{
										$error = $joinvalue['_error']; $errorline = $line; break;
									}
									$r[$key]['_joinvalue'] = $joinvalue;
								}
								foreach ($r2 as $key=>$row)
								{
									$joinvalue = swQueryTupleExpression($row, $term);
									
									if (is_array($joinvalue))
									{
										$error = $joinvalue['_error']; $errorline = $line; break;
									}
									$r2[$key]['_joinvalue'] = $joinvalue;
								}
								if ($error) break;
									
								$rows2 = array();
								foreach ($r as $key=>$row)
								{
									$found = false;
									foreach($r2 as $key2=>$row2)
									{
										
										if ($row['_joinvalue'] == $row2['_joinvalue'])
										{
											foreach($row as $k=>$v)
												$rows2[$key.'..'.$key2][$k] = $v;
											foreach($row2 as $k=>$v)
												$rows2[$key.'..'.$key2][$k] = $v;
											unset($rows2[$key.'..'.$key2]['_joinvalue']);
											$found = true;
											$r2found[$key2] = true;
										}
										
										
									}
									if (!$found && @$leftjoin)
									{
										foreach($row as $k=>$v)
												$rows2[$key.'..'][$k] = $v;
										unset($rows2[$key.'..']['_joinvalue']);
									}
								}
								if (@$outerjoin)
								{
									foreach($r2 as $key2=>$row2)
									{
										if (!isset($r2found[$key2]))
										{
											foreach($row2 as $k=>$v)
												$rows2['..'.$key2][$k] = $v;
											unset($rows2['..'.$key2]['_joinvalue']);
										}
									}
								}
								
								array_push($rowstack,$rows2);
								break;
								
				case "GROUP": 	if (count($rowstack)<1) { $error = 'Empty stack'; $errorline = $line; break; }
								$rollup = false;
								if (stristr($line ,' ROLLUP BY ' ))
									$rollup = true;
								$line = str_replace(' ROLLUP BY ', ' BY ', $line);
								$parts = explode(" BY ", substr($line,strlen("GROUP ")));
								$columns = explode(", ",@$parts[0]);
								$bys = explode(",",@$parts[1]);
	
								$r = array_pop($rowstack);
								
								// first order
								$keys = array();
								$groupkeys = array();
								
								// preserve original order as last key
								$i=0;
								foreach($r as $key=>$row)
								{
									$r[$key]['_order'] = $i;
									$i++;
								}
								
								$keys[] = $r;
								foreach($bys as $o)
								{
									$pars = explode(' ',$o);
									if ($pars[0] == '') array_shift($pars);
									
									$key = @$pars[0];
									$groupkeys[] = $key;
									if (stristr($o,' DESC'))
										$key = '!'.$key;
									if (stristr($o,' NUMERIC'))
										$key = '#'.$key;
									
									$keys[] = $key;
								}
								$keys[] = '#_order';
								
								
								
								
								$r2 = array_sort($keys);
								if (!is_array($r2)) $r2 = array();
								
								// now group actually
								
								$r3 = array();
								foreach($r2 as $row)
								{
									$g = '';
									foreach($groupkeys as $k)
									{
										$g .= @$row[$k].'::';
									}
									foreach($row as $k=>$v)
									{
										if ($k != '_order')
											$r3[$g][$k][] = $v;
									}
								}
								
								
								
								// now aggregate
								$r4 = array();
								
								
								
								
								foreach($r3 as $k=>$rowgroup)
								{
									foreach($columns as $c)
									{
										//parse function element
										$c = trim($c);
										if (stristr($c," "))
										{
											$pars = explode(' ',$c);
											$agg = $pars[1];
											$key = $pars[0];
											
										}
										else
										{
											$key = $c;
											$agg = '';
										}
										
										if (!isset($r3[$k][$key]))
										{ $error = 'Invalid field '.$key; $errorline = $line; break; }
										
										if ($rollup)
										{
											$i=0;
											foreach($r3[$k][$key] as $v)
											{
												switch ($agg)
												{
													case '': $r4[$k.'-'.$i][$key] = $v; break;
													
													case 'COUNT': $r4[$k.'-'.$i][$key.'-'.strtolower($agg)] = 1; break;
													
													default: $r4[$k.'-'.$i][$key.'-'.strtolower($agg)] = $v; break;
													
												}
												$i++;
											}
										}
										
										switch($agg)
										{
											case '': if ($rollup)
													 {
														$aun = array_unique($r3[$k][$key]);
														if (count($aun) == 1)
															$r4[$k][$key] = $aun[0];
														else
															$r4[$k][$key] = '';
													 }
													 else
														$r4[$k][$key] = @$r3[$k][$key][0]; break;
											
											case 'MAX' : $r4[$k][$key.'-max'] = max($r3[$k][$key]); break;
											case 'NULL' : $r4[$k][$key.'-null'] = ''; break;
											case 'MIN' : $r4[$k][$key.'-min'] = min($r3[$k][$key]); break;
											case 'COUNT' : $r4[$k][$key.'-count'] = count($r3[$k][$key]); break;
											case 'SUM' : 	$s = 0; foreach($r3[$k][$key] as $v) $s+=$v; 
															$r4[$k][$key.'-sum'] = $s;break;
											case 'AVG' : 	$s = 0; foreach($r3[$k][$key] as $v) $s+=$v; 
															$count = count($r3[$k][$key]);
															if ($count>0) $s /= $count;
															$r4[$k][$key.'-avg'] = $s; break;
											
											default : { $error = 'Invalid aggregator '.$agg; $errorline = $line; break; }
										
										}
										
									}
								
								}
								
								
								// if there is no row, COUNT should be zero
								foreach($columns as $c)
								{
										$c = trim($c);
										if (stristr($c," "))
										{
											$pars = explode(' ',$c);
											$agg = $pars[1];
											$key = $pars[0];
											
										}
										
										if ($agg == 'COUNT' && count($r4) == 0)
										{
											$r4[][$key.'-count'] = 0;
										}
										
										if ($agg == 'SUM' && count($r4) == 0)
										{
											$r4[][$key.'-sum'] = 0;
										}
								}
								
								
								array_push($rowstack,$r4);
								break;
				
				case "LIMIT":   if (count($rowstack)<1) { $error = 'Empty stack'; $errorline = $line; break; }
								if (!array_key_exists(0,$fs)) { $error = 'Missing start'; $errorline = $line; break; }
								$start = intval($fs[0]);
								$r = array_pop($rowstack);
								if (array_key_exists(1,$fs))
									$ende = $fs[1];
								else
									$ende=count($r);
								$i=0;
								
								$rows2 = array();
								foreach($r as $key=>$value)
								{
									if ($i>=$start && $i<$start+$ende)
										$rows2[$key] = $value;
									$i++;
								}
								array_push($rowstack,$rows2);
								break;
				case "COPY":	if (count($rowstack)<1) { $error = 'Empty stack'; $errorline = $line; break; }
								$r = array_pop($rowstack);
								$r2 = $r;
								array_push($rowstack,$r);
								array_push($rowstack,$r2);
								break;
				case "POP":		if (count($rowstack)<1) { $error = 'Empty stack'; $errorline = $line; break; }
								$r = array_pop($rowstack);
								break;
				case "SWAP":	if (count($rowstack)<2) { $error = 'Empty stack'; $errorline = $line; break; }
								$r = array_pop($rowstack);
								$r2 = array_pop($rowstack);
								array_push($rowstack,$r);
								array_push($rowstack,$r2);
								break;
				case "TEMPLATE":if (count($rowstack)<1) { $error = 'Empty stack'; $errorline = $line; break; }
								if (!array_key_exists(0,$fs)) { $error = 'Missing field'; $errorline = $line; break; }
								if (!array_key_exists(1,$fs)) { $error = 'Missing template'; $errorline = $line; break; }
									$column = $fs[0];
									$template = $fs[1];
								
								$r = array_pop($rowstack); 
								
								foreach($r as $key=>$row)
								{
									$r[$key][$column] = '{{'.$template.'|'.$row[$column].'}}';
								}
								
								array_push($rowstack,$r);
								break;
				
				case "OUTPUT" : if (!array_key_exists(0,$fs)) { $error = 'Missing output'; $errorline = $line; break; }
								$outputformat = array_shift($fs);
								switch($outputformat)
								{
									case "HTML":  // HTML htable
									case "FIXED": // SQL style as pre
									case "FIELDS": // sofawiki fields as pre
									case "FIELDSCOMPACT": // sofawiki fields as pre
									case "TAB": // tabs as pre
									case "LIST": // as HTML list
									case "TEXT":  $numbercolumns = explode(', ',join(' ',$fs));
													break;
									case "ROWTEMPLATE": if (!array_key_exists(0,$fs)) { $error = 'Missing rowtemplate'; $errorline = $line; break; }
														$rowtemplate = $fs[0]; break;
									default:  { $error = 'Missing or wrong outputformat'; $errorline = $line; break; }
								}
								
								break;
								
				
				case "SHOWKEY":	$showkey = true;  break;

				case "PROJECT": if (count($rowstack)<1) { $error = 'Empty stack'; $errorline = $line; break; }
								if (!array_key_exists(0,$fs)) { $error = 'Missing fieldlist'; $errorline = $line; break; }
									$columns = ($fs);
									$newcolumn = join(" ",$fs);
								$r = array_pop($rowstack); 
								$r2 =  array();
								foreach($r as $key=>$value)
								{
									foreach($columns as $c)
									{
										$cp = str_replace(',','',$c);
										$r2[$key][$cp] = @$value[$cp];
										
									}
								}
								array_push($rowstack,$r2);
							   break;

				case 'ROTATE' : if (count($rowstack)<1) { $error = 'Empty stack'; $errorline = $line; break; }
								$r = array_pop($rowstack); 
								$r2 = array();
								
								foreach($r as $key=>$tuple)
								{
									foreach($tuple as $k=>$v)
									{
										$r2[$k][$key] = $v;
									}
								}
								
								
							   	array_push($rowstack,$r2);
							   	break;

				case 'RENAME':  if (count($rowstack)<1) { $error = 'Empty stack'; $errorline = $line; break; }
								if (!array_key_exists(0,$fs)) { $error = 'Missing old field'; $errorline = $line; break; }
								if (!array_key_exists(1,$fs)) { $error = 'Missing new field'; $errorline = $line; break; }
								
								
								$renames = explode(', ',join(' ',$fs));
								
								$allcolumns = array();
								foreach($renames as $arename)
								{
									$renamefields = explode(' ',trim($arename));
									$ro = array_shift($renamefields);
									$rn = join(" ",$renamefields);
									$allcolumns[$ro] = $rn;
								}
								
								
								$r = array_pop($rowstack); 
								foreach($r as $key=>$value)
								{
									$elem = $value;
									
									foreach($allcolumns as $column=>$newcolumn)
									{
										if ($column == '*')
										{
											foreach($elem as $k=>$v)
											{
												$elem[$k.$newcolumn] = @$elem[$k];
												unset($elem[$k]);
											}
										}
										elseif($column == '#')
										{
											$elem[$newcolumn]=$key;
										}
										else
											$elem[$newcolumn]=@$elem[$column];
										
										unset($elem[$column]);
									}
									
									$r[$key] = $elem;
								}
								
								array_push($rowstack,$r);
								break;

				case 'RENAMEALL' : if (count($rowstack)<1) { $error = 'Empty stack'; $errorline = $line; break; }
								if (!array_key_exists(0,$fs)) { $error = 'Missing new fields'; $errorline = $line; break; }
								$newcolumns = explode(', ',join(' ',$fs));
								
								$r = array_pop($rowstack);
								$r2 = array();
								foreach($r as $key=>$value)
								{
									$elem = $value;
									$i = 0;
									$elem2 = array();
									foreach($elem as $k=>$v)
									{
										if ($i >= count($newcolumns)) continue;
										$elem2[trim($newcolumns[$i])] = $v;
										$i++;
									}
									$r2[$key] = $elem2;
								}
								
								array_push($rowstack,$r2);
								break;
				case "FORMAT":  if (count($rowstack)<1) { $error = 'Empty stack'; $errorline = $line; break; }
								if (!array_key_exists(0,$fs)) { $error = 'Missing field'; $errorline = $line; break; }
								if (!array_key_exists(1,$fs)) { $error = 'Missing formatstring'; $errorline = $line; break; }
									$column = array_shift($fs);
									$newformat = join(" ",$fs);
								
								$r = array_pop($rowstack); 
								foreach($r as $key=>$value)
								{
									$r[$key][$column] = sprintf($newformat,$r[$key][$column]); 
								}
								
								array_push($rowstack,$r);
								break;
				case "NUMBERFORMAT":  if (count($rowstack)<1) { $error = 'Empty stack'; $errorline = $line; break; }
								if (!array_key_exists(0,$fs)) { $error = 'Missing field'; $errorline = $line; break; }
								
								$numberformats = explode(', ',join(' ',$fs));
								
								$columns = array();
								
								foreach($numberformats as $nf)
								{
									$nfs = explode(' ',$nf);
									$nc = array_shift($nfs);
									$nd = @array_shift($nfs); 
									$columns[$nc] = $nd;
								}
								
									
								
								$r = array_pop($rowstack); 
								foreach($r as $key=>$value)
								{
									foreach($columns as $column=>$decimals)
										$r[$key][$column] = number_format(floatval($r[$key][$column]),$decimals,'.',"'"); 
								}
								
								array_push($rowstack,$r);
								break;
				case "CALC": 	if (count($rowstack)<1) { $error = 'Empty stack'; $errorline = $line; break; }
								if (!array_key_exists(0,$fs)) { $error = 'Missing field'; $errorline = $line; break; }
								if (!array_key_exists(1,$fs)) { $error = 'Missing expression'; $errorline = $line; break; }
									$column = array_shift($fs);
									$arguments = $fs;
									$term = join(' ',$fs);
								
								$r = array_pop($rowstack); 
								
								foreach($r as $key=>$row)
								{
									$c = swQueryTupleExpression($row, $term);
									if (is_array($c))
									{
										$error = $c['_error']; $errorline = $line; break;
									}
									$r[$key][$column] = $c;
								}
								
								array_push($rowstack,$r);
								break;
				case "CONST": 	if (count($rowstack)<1) { $error = 'Empty stack'; $errorline = $line; break; }
								if (!array_key_exists(0,$fs)) { $error = 'Missing field'; $errorline = $line; break; }
								if (!array_key_exists(1,$fs)) { $error = 'Missing value'; $errorline = $line; break; }
									$column = array_shift($fs);
									$const = join(" ",$fs);
								
								$r = array_pop($rowstack); 
								foreach($r as $key=>$value)
								{
									$r[$key][$column] = $const; 
								}
								
								array_push($rowstack,$r);
								break;
				case 'VERBOSE':  $verbose = true; break;
				
				case 'query'  : break; //ignore;
				default:         $error = 'Invalid keyword'; 
								 $errorline = $line; 
			}
		}
		
		if ($error=='')
			$rows = array_pop($rowstack);
		else
			$rows = array();
		
		$endtime = microtime(true);
		
		$verbosetext = '';
		if ($verbose)
		{
			$a2 = $args;
			array_shift($a2);
			$source = join('<br>| ',$a2);
			$source = str_replace('<br>| VERBOSE','',$source);
			$verbosetext = "\n".'<div class="queryverbose">| '.$source;
			if (count($rows)==1)
				$verbosetext .= '<br>'.sprintf('%0d row',count($rows)).' '. sprintf('%0d msec', ($endtime-$starttime)*1000).'</div>';
			else
				$verbosetext .= '<br>'.sprintf('%0d rows',count($rows)).' '. sprintf('%0d msec', ($endtime-$starttime)*1000).'</div>';
		}
		
		$errortext = '';
		if ($error) 
			$errortext .= "\n".'<div class="queryerror">'. swSystemMessage('Query Error - '.$error,$lang).'<br>| '.$errorline.'</div><br>';
		
		global $swOvertime;
		
		$overtimetext = '';
		if ($swOvertime)
			$overtimetext .= "\n".'<div class="queryovertime">'.
		swSystemMessage('Result incomplete, you may want to refresh the page to get more results',$lang)
		.'</div>';
		
		if (count($rows) > 0)
		{

			if ($this->outputraw) return $rows;
			
			switch ($outputformat)
			{
				case 'HTML': 	$result  .= '<table class="'.$datatablestyle.'">';
		
								$first = true;
								$keys = array();
								foreach($rows as $k=>$row)
								{
									foreach ($row as $key=>$v)
									{
										$keys[$key] = 1;  
									}
								}
								if (count($keys)>0)
								{
									$result .= '<thead><tr>';
									if ($showkey) $result .= '<th><nowiki>#</nowkiki></th>';
									foreach ($keys as $key=>$v)
									{
									 	if (in_array($key,$numbercolumns))
											$result .=	'<th style="text-align:right">'.$key.'</th>';
										else
											$result .= '<th>'.$key.'</th>';
									}
									$result .=	'</tr></thead>';
								
								}
												
								$result .= '<tbody>';
	
								foreach ($rows as $rev=>$row)
								{
									if (count($row)>0)
									{
										$result .= '<tr>';
										if ($showkey) $result .=	'<td>'.$rev.'</td>';
										
										foreach ($keys as $key=>$v)
										{
										  $v = @$row[$key];
										  if ($v=='') $v = '&nbsp;'; // no collapse
										 
										 if (in_array($key,$numbercolumns))
										 	$result .=	'<td style="text-align:right">'.$v.'</td>';
										 else
										 	$result .=	'<td>'.$v.'</td>';
										 }
										  
										$result .= '</tr>';
									}
								}
								$result .= '</tbody></table>';
								break;
								
				case "FIXED"  : $lens = array();
								foreach ($rows as $rev=>$row)
								{
									foreach ($row as $k=>$v)
									{
										$lens[$k] = max(@$lens[$k],strlen($v));
										$lens[$k] = max(@$lens[$k],strlen($k));
									}
								}
								$result .= '<pre>';
								$first = true;
								foreach ($rows as $rev=>$row)
								{
									if ($first)
									{
										foreach ($row as $k=>$v)
										{
											if (in_array($k,$numbercolumns))
												$result .= str_pad($k,$lens[$k]," ",STR_PAD_LEFT).' ';
											else
												$result .= str_pad($k,$lens[$k]+1);

										}
										$result .= "<br>";
										
										foreach ($row as $k=>$v)
										{
											$result .= str_pad("-",$lens[$k],"-").' ';
											
										}
										$result .= "<br>";
									}
									
									foreach ($row as $k=>$v)
									{
										if (in_array($k,$numbercolumns))
											$result .= str_pad($v,$lens[$k]," ",STR_PAD_LEFT).' ';
										else
											$result .= str_pad($v,$lens[$k]+1);
									}
									$result .= "<br>";
									$first = false;
								}
								$result .= '</pre>';
								break;
				
				case "FIELDS"  :		 
				case "FIELDSCOMPACT":   
								foreach ($rows as $rev=>$row)
								 {
									if ($showkey) $result .= $rev;
									foreach ($row as $k=>$v)
									{
										  $result .= '[<nowiki>[</nowiki>'.$k.'::'.$v.']] ';
										  if ($outputformat == 'FIELDS') $result .='<br>';
									}
									$result .= '<br>';
								 }
								 break;
				
				case "TAB"   : 	$h = count($rows)*16;
								$h = min(400,max(32,$h));
								
								$result  .= '<textarea style="width:100%; height:'.$h.'px">';
								 foreach ($rows as $rev=>$row)
								 {
									$result .= "<nowiki>";
									if ($showkey) $result .= $rev."\t";
									foreach ($row as $k=>$v)
										  $result .=	$v."\t";
									$result = substr($result,0,-1);
								  	$result .= "\r</nowiki>";  // \n does not work
								}
								
								 $result  .= '</textarea>';
								 break;
		
				case "LIST"   : // to do: convert table into tree to create deep list.
								
									$result  .= '<ul>';
									foreach ($rows as $rev=>$row)
										$result  .= '<li>'.array_shift($row).'</li>';
									$result  .= '</ul>';
								
								break;
		
				case "TEXT"   :  
								
								 foreach ($rows as $rev=>$row)
								 {
									if ($showkey) $result .= $rev;
									foreach ($row as $k=>$v)
										  $result .= $v;
								}
								
								
								 break;
				
				case "ROWTEMPLATE" : foreach ($rows as $rev=>$row)
								 	{
										  $result .= '{{'.$rowtemplate;
										foreach ($row as $k=>$v)
										  $result .= '|'.$v;
										  $result .= '}}';
									}
		   }
		}
		
		 $result = $verbosetext.$result.$errortext.$overtimetext;		
 		
		return $result;
	
	}
}
	
	$swFunctions["query"] = new swQueryFunction;	
	
	?>