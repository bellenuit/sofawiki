<?php 

// This file must be text encoding UTF8 no BOM not to get problems with cookies

if (!defined('SOFAWIKI')) die('invalid acces');

function swUnescape($s)
{
	  	// escape characters
  		$s = str_replace("<colon>",":",$s);
  		$s = str_replace("<leftsquare>","[",$s);
  		$s = str_replace("<rightsquare>","]",$s);
  		$s = str_replace("<leftcurly>","{",$s);
  		$s = str_replace("<rightcurly>","}",$s);
  		$s = str_replace("<pipe>","|",$s);
  		$s = str_replace("<space>"," ",$s);
  		//$s = str_replace("<gt>",">",$s); 
  		//$s = str_replace("<lt>","<",$s);//security problem
  		return $s;
}


function swGetArrayValue($array,$key,$default='')
{
	if (array_key_exists($key,$array))
		return $array[$key];
	else
		return $default;
}


function swQuerySplit($s)
{
	// split on space, but preserve [[field::value space]]
	return explode(' ',$s);
}

function swStrReplace($pattern, $replace, $s)
{
	// use lowercase, uppercase and titlecase
	$patterns = array();
	$patterns[] = $pattern;
	$patterns[] = strtoupper($pattern);
	$patterns[] = strtolower($pattern);
	$patterns[] = strtoupper(substr($pattern,0,1)).substr($pattern,1);

	foreach ($patterns as $p)
	{
		$r = str_replace($pattern,$p,$replace);
		$s = str_replace($p,$r,$s);
	}
	return $s;	
}

function swGetValue($s, $key, $getArray = false)
{
	// equivalent to fields parser
	
	$pattern = '[['.$key.'::';
	$results = array();
	$result = "";
	$pos = true;
	while ($pos !== FALSE)
	{
		$pos = strpos($s, $pattern);
		if ($pos !== FALSE)
		{
			$pos0 = $pos + strlen($pattern);
			$pos2 = strpos($s,']]',$pos0);
			if ($pos2 !== FALSE)
			{
				$result = substr($s,$pos0, $pos2-$pos0);
				$rs =explode('::',$result);
				foreach($rs as $r)
				{
					if (!$getArray) return $r;
					$results[] = $r;
				}
				
			}
		}
		$s = substr($s,$pos+1); 
		
	}
	if (!$getArray)
	{
		if (count($results)>0)
			return $results[0];
		else
			return '';
	}
	return $results;
	
}


function swGetAllFields($s,$allowinternalvariables=false)
{
	
		preg_match_all("@\[\[([^\]\|]*)([\|]?)(.*?)\]\]@", $s, $matches, PREG_SET_ORDER);
		
		$result=array();
		
		foreach ($matches as $v)
		{
			
			$val = $v[1]; // link
			
			// handle fields
			
			if (!$allowinternalvariables)
				if (substr($val,0,1)=='_') continue;
			
			
			// handle internal fields
			if ($delim = stripos($val,'::'))	// we show only values		
			{ 
				$val = $v[1].$v[2].$v[3]; // we use everything 
				
				$fieldstring = substr($val,$delim+2);  
				$key = substr($val,0,$delim);
				
				$fields = explode('::',$fieldstring);
				
				$t = '';
				foreach ($fields as $f)
				{
					$result[$key][]=$f;
				}

				
			}
			
		}
		
		return $result;

}


function swGetAllLinks($s)
{

	preg_match_all("@\[\[([^\]\|]*)([\|]?)(.*?)\]\]@", $s, $matches, PREG_SET_ORDER);
	foreach ($matches as $v)
	{	
		$result[] = $v[1]; 
	}
	return $result;
	
}



function swValidate($v,$invalidcharacters)
{
	$l = strlen($invalidcharacters);
	$i=0;
	for ($i==0;$i<$l;$i++)
	{
		if (strstr($v,substr($invalidcharacters,$i,1))) return false;
	}
	return true;
}


function swNameURL($name)
{
	if (!is_string($name))
	{	
		if (is_array($name))
		{
			debug_print_backtrace();
			exit;
		}
		$name = strval($name);
	}
	
	$s = $name;
	
	$s = swUnescape($s);
	
	// replace spaces by hyphen 
	$s = str_replace(' ','-',$s);
	$s = str_replace('_','-',$s);
	// replace special characters
	$s = str_replace('´','-',$s);
	$s = str_replace('"','-',$s);
	$s = str_replace('&#039;','-',$s);
	$s = str_replace('&amp;','-',$s);
//	$s = str_replace('&quot;','-',$s);
	$s = str_replace("'",'-',$s);
	// replace german umlauts
	$s = str_replace('ä','ae',$s);
	$s = str_replace('æ','ae',$s);
	$s = str_replace('ö','oe',$s);
	$s = str_replace('ø','oe',$s);
	$s = str_replace('œ','oe',$s);
	$s = str_replace('ü','ue',$s);
	$s = str_replace('Ä','Ae',$s);
	$s = str_replace('Ö','Oe',$s);
	$s = str_replace('Ü','Ue',$s);
	
	// replace special characters allowed
	$s = str_replace('?','-',$s);
	$s = str_replace('!','-',$s);
	$s = str_replace('.','-',$s);
	$s = str_replace('«','-',$s);
	$s = str_replace('»','-',$s);
	$s = str_replace('=','-',$s);
	

	$swNameURLstrtable = array('à'=>'a','á'=>'a','â'=>'a','ã'=>'a','ä'=>'a',
	'ç'=>'c',
	'è'=>'e','é'=>'e','ê'=>'e','ë'=>'e',
	'ì'=>'i','í'=>'i','î'=>'i','ï'=>'i',
	'ñ'=>'n',
	'ò'=>'o','ó'=>'o','ô'=>'o','õ'=>'o','ö'=>'o',
	'ù'=>'u','ú'=>'u','û'=>'u','ü'=>'u','ý'=>'y','ÿ'=>'y',
	'À'=>'A','Á'=>'A','Â'=>'A','Ã'=>'A','Ä'=>'A',
	'Ç'=>'C',
	'È'=>'E','É'=>'E','Ê'=>'E','Ë'=>'E',
	'Ì'=>'I','Í'=>'I','Î'=>'I','Ï'=>'I',
	'Ñ'=>'N',
	'Ò'=>'O','Ó'=>'O','Ô'=>'O','Õ'=>'O','Ö'=>'O',
	'Ù'=>'U','Ú'=>'U','Û'=>'U','Ü'=>'U','Ý'=>'Y');

	
	$s = strtr($s,$swNameURLstrtable);
	
	// now replace anything else left with hyphen
	
	$s = preg_replace("@[^-a-zA-Z0-9/:.-_]@","-",$s);
	
    // Capitalize First letter
	$s = strtoupper(substr($s,0,1)).substr($s,1);
	// Capitalize First letter if there is a Name Space
	if (stristr($s,':'))
	{
		$p = strpos($s,':');
		$s = substr($s,0,$p+1).strtoupper(substr($s,$p+1,1)).substr($s,$p+2);
	}
	
	$s = strtolower($s);
	
	// Remove double --
	while (strpos($s,'--'))
		$s = str_replace('--','-',$s);

		
	if ($s == "-") return $s;
	// remove trailing -
	while (substr($s,-1)=="-")
		$s = substr($s,0,-1);
	
	// remove trailing also on languages subpages
	$s = str_replace('-/','/',$s);
		
	return $s;
	
}


function swFileGetContents($url)
{
       $c = curl_init();
        curl_setopt($c, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($c, CURLOPT_URL, $url);
        $contents = curl_exec($c);
        curl_close($c);

        if ($contents) 
        	return $contents;
        else 
            return false;
}

?>