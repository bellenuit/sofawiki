<?php

if (!defined('SOFAWIKI')) die('invalid acces');

$swParsedName = swSystemMessage('Search',$lang).':"'.$query.'"';

$ns = join('|',$swSearchNamespaces);

$urlquery = swNameURL($query);

echotime('query');

$found = false;

if (isset($swQuickSearchRedirect) && $swQuickSearchRedirect && !isset($_REQUEST['allresults']))
{
	$wiki = new swWiki; //must be global wiki to be parsed by functions
	$wiki->name = $urlquery;
	$nsw = $wiki->wikinamespace();
	if ($nsw == '' || stristr($ns.' ',$nsw.' ') || $ns=='*')
	{
		$wiki->lookupLocalName();
		$wiki->lookup();
		if ($wiki->revision)
		{
			$name = $query;
			$swParsedContent = $wiki->content;
			$swParsedContent .= '<nowiki><br><br><i><a href="index.php?action=search&allresults=1&query='.$query.'">'.swSystemMessage('All Results',$lang).' "'.$query.'"</a></i></nowiki>';

			$swParsedName = $wiki->namewithoutlanguage();
			$swParseSpecial = true;
			$found = true;
		}
	}
	
}
$names = array();
if (!$found)
{
	$urlquerylist = explode('-',$urlquery);
	if (stristr($urlquery,'-')) $urlquerylist[] = $urlquery;
	foreach($urlquerylist as $k=>$word)
	{
		if(strlen($word)<3)
			unset($urlquerylist[$k]);
	}
	$first = true;
	
	foreach($urlquerylist as $word)
	{
		if (!$first && !count($names)) continue;
		
		$revisions = swFilter('SELECT _name, _rating WHERE _* *~* '.$word,$ns,'query');
		
		if (!isset($revisions) || !is_array($revisions)) continue;
		
		//print_r($revisions);
		
		if ($first)
		{
			foreach($revisions as $k=>$v)
			{
				$n = $v['_name'];
				$r = $v['_rating'];
				if (isset($names[$n]))
					$names[$n] += $r;
				else
					$names[$n] = $r;
			}
			$first = false;	
		}
		else
		{
			$thisrevision = array();
			foreach($revisions as $k=>$v)
			{
				$n = $v['_name'];
				$r = $v['_rating'];
				$thisrevision[$n] = $r;
			}
			
			foreach($names as $n=>$r)
			{
				if (stristr($word,'-'))
				{
					if (isset($thisrevision[$n]))
					{
						$names[$n] *= 2;
					}//!! last should not exclude, but premium
				}
				else
				{
					if (isset($thisrevision[$n]))
					{
						$names[$n] = $r*$thisrevision[$n];
					}
					else
					{
						unset($names[$n]);
					}
				}
			}
		
		
		}
		
	}


	if (count($names))
		arsort($names);


	$swParseSpecial = false; 
	$separator = "\n";
	$gprefix = '<ul>';
	$gpostfix = '</ul>';
	$limit = '';
	
	
	// function can reorder list and apply custom templates for each name
	if (function_exists('swInternalSearchHook')) 
	{
		$hookresult = swInternalSearchHook($names,$query);
		if ($hookresult)
		{
			$gprefix = ''; if (isset($hookresult['gprefix'])) $gprefix =  $hookresult['gprefix'];
			$gpostfix = ''; if (isset($hookresult['gpostfix'])) $gpostfix =  $hookresult['gpostfix'];
			$names = ''; if (isset($hookresult['names'])) $names =  $hookresult['names'];
			$separator = ''; if (isset($hookresult['separator'])) $separator =  $hookresult['separator'];
			if (isset($hookresult['limit'])) $limit =  $hookresult['limit'];
			
			$swParseSpecial = true; 
		}
	}
	
	
	foreach($names as $k=>$v)
	{	
		if (!$user->hasright('view', $k))
			unset($names[$k]);
	}
	
	
	if ($limit==0) $limit = 50;
	
	$start = 0; if (isset($_REQUEST['start'])) $start = $_REQUEST['start'];
	$count = count($names);
	global $lang;
	global $name;
	
	$navigation = '<nowiki><div class="categorynavigation">';
	if ($start>0 && $count)
		$navigation .= '<a href="index.php?action=search&allresults=1&query='.$query.'&start='.sprintf("%0d",$start-$limit).'"> '.swSystemMessage('back',$lang).'</a> ';
		
	if ($count)
		$navigation .= " ".sprintf("%0d",min($start+1,$count))." - ".sprintf("%0d",min($start+$limit,$count))." / ".$count;
	else
		$navigation .= swSystemMessage('noresult',$lang);
	if ($start<$count-$limit && $count)
		$navigation .= ' <a href="index.php?action=search&allresults=1&query='.$query.'&start='.sprintf("%0d",$start+$limit).'">'.swSystemMessage('forward',$lang).'</a>';
	$navigation .= '</div></nowiki>';
	
	
	$searchtexts = array();
	
	
	
	$i=0;
	if (is_array($names) && count($names)>0)
	{
	foreach ($names as $k=>$v)
	{
	
		
		$i++;
		if ($i<=$start) continue; 
		if ($i>$start+$limit) continue; 
			$record = new swWiki;
			$record->name = $k;
			$record->lookup();
			
			if ($record->status == 'deleted') continue; // should not happen
			
			if (substr($record->content,0,9) == '#REDIRECT') continue;
			
			$link = $record->link("");
			
			$dplen = strlen('#DISPLAYNAME');
			if (substr($record->content,0,$dplen)=='#DISPLAYNAME')
				{
					$pos = strpos($record->content,"\n");
					$record->name = substr($record->content,$dplen+1,$pos+1-$dplen-2);
				}
			
			
			
			if (true)
			{
				
					if (isset($hookresult) && $hookresult )
					{
						$searchtexts[] = $v;	
						
					}
					else
					{
	
						$t = "";
						$pref="";
						$qs = swQuerySplit($query);
						$s0 = $qs[0];
						if (stristr($record->content,$s0))
						{
							
							$pos = stripos($record->content,$s0);
							if ($pos > 40)
							{
								$pos -= 40;
								$possp = stripos($record->content,' ',$pos);
								if ($possp >= $pos && $possp < $pos + 40)
									$pos = $possp;
								$pref = '...';
							}
							else
							{
								$pos = 0;
								$pref = '';
							}
							
							$pos2 = min($pos + 200,strlen($record->content));
							
							$possp = stripos($record->content,' ',$pos2);
							if ($possp >= $pos2 && $possp < $pos2+40)
									$pos2 = $possp;
							

							$record->content = substr($record->content,$pos,$pos2-$pos);  

							$record->parsers = array();
							$record->parsers['nowiki'] = new swNoWikiParser;
							switch($record->wikinamespace())
							{
								case 'User': case 'Template': $t = ''; break;
								default: $t = $record->parse(); 
							}
							
							
							foreach ($qs as $q)
								$t = swStrReplace($q,'<span class="found">'.$q.'</span>',$t);
						}
						
						if (trim($t)) $t = $pref.trim($t). '...'; else $t = '';
						
						if (trim($record->name))
						
							$searchtexts[] = '<li><a href="'.$link.'">'.$record->name.'</a>
						<br/>'.$t.'</li>';
						
						unset($swParseSpecial);
				
					}
			}
	}
	} // count >0
	

	$swParsedContent = $navigation.$gprefix.join($separator,$searchtexts).$gpostfix;
	if ($count)
		$swParsedContent .=$navigation;
	

}

if ($query == '') $swParsedContent = swSystemMessage('Error: query is empty',$lang);

if (isset($swParseSpecial))
{
	
	$wiki->content = $swParsedContent;
	$wiki->parsers = $swParsers;
	$swParsedContent = $wiki->parse();
}

if (isset($swOvertime) && $swOvertime)  $swParsedContent.="\n".'<a href="index.php?action=search&query='.$query.'&allresults=1&moreresults=1">'.swSystemMessage('more results',$lang).'</a>';

if (isset($swOvertime))
	$swParsedContent .= '<br>'.swSystemMessage('Search limited by time out.',$lang).' <a href="index.php?action=search&query='.$query.'">'.swSystemMessage('Search again',$lang).'</a>';


?>