<?php

if (!defined("SOFAWIKI")) die("invalid acces");


class swFieldsParser extends swParser
{

	
	function info()
	{
	 	return "Handles internal fields";
	}
	
	function dowork(&$wiki)
	{
		$s = $wiki->parsedContent;
		
		// internal links
		preg_match_all("@\[\[([^\]\|]*)([\|]?)(.*?)\]\]@", $s, $matches, PREG_SET_ORDER);
		
		foreach ($matches as $v)
		{
			
			$val = $v[1]; // link
			
			// handle fields
			
			// ignore internal variables
			if (substr($val,0,1)=="_") continue; 
			
			
			// handle internal fields
			if ($delim = stripos($val,"::"))	// we show only values		
			{ 
				$val = $v[1].$v[2].$v[3]; // we use everything 
				
				$fieldstring = substr($val,$delim+2);  
				$key = substr($val,0,$delim);
				
				$fields = explode('::',$fieldstring);
				
				$t = "";
				foreach ($fields as $f)
				{
					$wiki->internalfields[$key][]=$f;
					
					
					//if there is a template with the name of the field, use it
					
					$revision = swGetCurrentRevisionFromName("Template:$key");
					if ($revision)
					{
						$fieldwiki = new swWiki;
						$fieldwiki->content = '{{'.$key.'|'.$f.'}}';
						$fieldwiki->parsers[] = new swTemplateParser();
						$fieldwiki->parse();
						$t .= $fieldwiki->parsedContent;
					}
					else
					{
						// do not show
					}
				}
				
			
				
				$s = str_replace($v[0],$t,$s);
				
			}
			
		}
		
		$wiki->parsedContent = $s;
		
		
	}

}

$swParsers["fields"] = new swFieldsParser;


?>