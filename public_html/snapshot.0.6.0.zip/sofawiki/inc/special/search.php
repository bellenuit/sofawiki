<?php

if (!defined('SOFAWIKI')) die('invalid acces');

$swParsedName = swSystemMessage('Search',$lang).': '.$query;

$ns = join(' ',$swSearchNamespaces);

$revisions = swQuery($query,$ns);

$searchtexts = array();

$record = new swWiki;

foreach ($revisions as $k=>$v)
{
	$record->revision = $k;
	$record->lookup();
	
	if (substr($record->content,0,9) == '#REDIRECT') continue;
	
	$link = $record->link("");
	
	$dplen = strlen('#DISPLAYNAME');
	if (substr($record->content,0,$dplen)=='#DISPLAYNAME')
		{
			$pos = strpos($record->content,"\n");
			$record->name = substr($record->content,$dplen+1,$pos+1-$dplen-2);
		}
	
	
	
	if (($record->status=='ok' or $record->status=='protected') && $user->hasright('view', $record->name))
	{
		
		
		$t = "";
		$qs = swQuerySplit($query);
		if (stristr($record->content,$qs[0]))
		{
			
			$pos = stripos2($record->content, $qs[0]);
			$pos = max(0,$pos-80);
			if ($pos>0)
				$pos = stripos2($record->content, ' ', $pos);
			
			$pos2 = stripos2($record->content, ' ', min(strlen($record->content),$pos+160));
			
			if ($pos2===NULL || $pos2=='')
			{
				$record->content = substr($record->content,$pos); 
			}
			else
			{
				$record->content = substr($record->content,$pos,$pos2-$pos);  
			}
			$record->parsers = array();
			$record->parsers['nowiki'] = new swNoWikiParser;
			$t = $record->parse();
			
			
			foreach ($qs as $q)
				$t = swStrReplace($q,'<span class="found">'.$q.'</span>',$t);
			
		}
		
		$searchtexts[] = '<li><a href="'.$link.'">'.$record->name.'</a>
		<br/>'.$t.'</li>';
	}
}

$swParsedContent = '<ul>'.join("\n",$searchtexts).'</ul>';

?>