<?php

if (!defined('SOFAWIKI')) die('invalid acces');

$swParsedName = 'Upload multiple';
$swParsedContent = 'All files in the Upload directory will be moved to the file directory and image pages will be created';

$files = glob($swRoot.'/site/upload/*.*');
natsort($files);
$found = false;
foreach($files as $file)
{
	if (substr($file,0,1) != '.')
	{
		$shortname = str_replace($swRoot.'/site/upload/','',$file);
		$file2 = $swRoot.'/site/files/'.$shortname;
		rename($file,$file2);

		$wiki->name ='Image:'.$shortname;
		$wiki->user = $user->name;
		$wiki->content = '';
		if ($file != '')
			$wiki->insert();

		$swParsedContent .=  '<br/><a href="'.$wiki->link('').'">Image:'.$file.'</a>';
		
		$found = true;
		
	}		
}

$wiki->name = 'Upload multiple';

if (!$found) $swParsedContent .= '<br/><br/>No file found'; 

$swParseSpecial = false;



?>