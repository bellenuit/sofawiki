<?php

if (!defined("SOFAWIKI")) die("invalid acces");

$swParsedName = "Uploading File";
$swParsedContent = "";




$file = $_FILES['uploadedfile'];
$filename = $_POST['filename'];
if (is_uploaded_file($_FILES['uploadedfile']['tmp_name']))
	{
	   $swParsedContent .= "\nFile $filename uploaded.";
	   
	   $newfile = "$swRoot/site/files/$filename";
	   if (file_exists($newfile))
	   {
	   		$swParsedContent .= "<br/>Deleting existing file";
	   }
	   
	   if (!move_uploaded_file($_FILES['uploadedfile']['tmp_name'],$newfile)) 
		  {
		  // if an error occurs the file could not
		  // be written, read or possibly does not exist
		  $swParsedContent =  "<br/><span class='error'>Error Uploading File. $newfile</span>";
	   }
	   else
	   {
			$swParsedContent .=  "<br/>OK.";
	   }
	}
	else
	{
		$swParsedContent .=  "<br/><span class='error'>Error: File $filename not uploaded.</span>";
	}



$wiki->name ="Image:$filename";
$wiki->user = $user->name;
$wiki->content = str_replace("\\","",$content);
if ($filename != "")
	$wiki->insert();

$swParsedContent .=  "<br/><a href='".$wiki->link("")."'>Image:$filename</a>";
$swParsedContent .=  "<br/><img src='site/files/$filename'>";





?>