<?php

if (!defined("SOFAWIKI")) die("invalid acces");

$swParsedName = "Special:Templates";

$names = $db->GetAllNames();
uasort($names, 'strnatcasecmp'); 
$swParsedContent = "";
$oldfirst = "";

foreach ($names as $n=>$s)
{
	if (substr($n,0,9)=="Template:")
	{
		$templatename = substr($n,9);
		$first = strtolower(substr($n,0,1));
		if ($oldfirst && $oldfirst != $first) $swParsedContent .= "\n\n";
		$swParsedContent .= "[[$n|$templatename]] ";
		$oldfirst = $first;
 	}
}


$swParseSpecial = true;



?>