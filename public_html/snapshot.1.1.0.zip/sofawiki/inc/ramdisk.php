<?php

/*

mounts a ramdisk and provides alternative path for cache files

*/

if (!defined('SOFAWIKI')) die('invalid acces');


function swInitRamdisk()
{
	
	global $swRamdiskPath;
	global $swRoot;
	if (is_dir($swRamdiskPath)) 
	{
		 
	 $ramfree = sprintf('%0d',disk_free_space($swRamdiskPath)/1024/1024);
	 
	 echotime('ram free '. $ramfree. ' MB');
	
	 if ($ramfree < 16)
	 {
	 	// purge to prevent full ramdisk
	 	$files1 = glob($swRamdiskPath.'current/*.txt');
	 	$files2 = glob($swRamdiskPath.'queries/*.txt'); // do not touch bitmaps
		$files = array_merge($files1,$files2);
		shuffle($files);
		$files = array_slice($files,0,100);
		foreach($files as $file) unlink($file);
		echotime('deleted 100 files from ramdisk');
		$ramfree = sprintf('%0d',disk_free_space($swRamdiskPath)/1024/1024);
	 	echotime('ram free '. $ramfree. ' MB');
	 	
	 }
	 
	 if (!is_dir($swRamdiskPath.'current')) { exec('mkdir '.$swRamdiskPath.'current'); }
	 if (!is_dir($swRamdiskPath.'indexes')) { mkdir($swRamdiskPath.'indexes',0777); }
	 if (!is_dir($swRamdiskPath.'queries')) { mkdir($swRamdiskPath.'queries',0777); }
	 if (!is_dir($swRamdiskPath.'trigram')) { mkdir($swRamdiskPath.'trigram',0777); }
	 
	if (rand(0,100) == 1 || $_REQUEST['submitsync'] && file_exists($swRamdiskPath.'indexes/indexedbitmap.txt'))
	{
		echotime ('rsync');
		$ex = "rsync -ar --delete $swRamdiskPath/current/ $swRoot/bak/current/";
		echotime ( exec($ex)); 
		$ex = "rsync -ar --delete $swRamdiskPath/indexes/ $swRoot/bak/indexes/";
		echotime ( exec($ex)); 
		$ex = "rsync -ar --delete $swRamdiskPath/queries/ $swRoot/bak/queries/";
		echotime ( exec($ex)); 
		$ex = "rsync -ar --delete $swRamdiskPath/trigram/ $swRoot/bak/trigram/";
		echotime ( exec($ex)); 
	}


	 return;
	}
	
	echotime('no ramdisk');
	$swRamdiskPath = '';
	
	// ramdisk creation does not work from php. you must create it directly in the system including the path to the folder 
	// $ex = 'diskutil erasevolume HFS+ "ramdisk" `hdiutil attach -nomount ram://1165430';
	// echotime(exec($ex));
	
}


if (isset($swRamdiskPath) && $swRamdiskPath != '')
	swInitRamdisk();


?>