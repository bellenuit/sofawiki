<?php

/*

creates trigram indexes of the content for faster searches
the trigram indexes are simple line-separated array in the site/indexes folder

lasttrigram.txt : last revision indexed
aaa.txt 
...
zzz.txt : line arrays of revisions containing the trigram of the filename

the index uses all revisions, even the revisions that are not used any more

*/



if (!defined('SOFAWIKI')) die('invalid acces');

function getLastTrigram()
{
	global $db;
	$bm = $db->trigrambitmap;
	for($i=$bm->length;$i>0;$i--)
	{
		if ($bm->getbit($i)) return $i;
	}
	return 0;
}

function getTrigram($t)
{
	global $swRoot;
	global $db;
	if (strlen($t)<3) return false; 
	if (!stristr('abcdefghijklmnopqrstuvwxyz0123456789.-',substr($t,0,1))) return;  
	if (!stristr('abcdefghijklmnopqrstuvwxyz0123456789.-',substr($t,1,1))) return; 
	if (!stristr('abcdefghijklmnopqrstuvwxyz0123456789.-',substr($t,2,1))) return; 
	if (array_key_exists($t,$db->trigrams)) return $db->trigrams[$t];
	global $swRamdiskPath;
	if ($swRamdiskPath != '') // access does not work
		$file = $swRamdiskPath.'trigram/'.$t.'.txt';
	else
		$file = $swRoot.'/site/trigram/'.$t.'.txt';
	if (file_exists($file))
		$list = file($file,FILE_IGNORE_NEW_LINES);
	else
		$list = array();
	
	
	$bm = $db->trigrambitmap->duplicate();
	$bm = $bm->notop(); // include all files, that were not indexed
	foreach($list as $v)
	{
		$bm->setbit($v);
	}
	return $bm;
}



function swIndexTrigram($numberofrevisions = 1000, $refresh = false)
{
	echotime('trigram start ');
	global $db;
	global $swRoot;
	global $swMaxSearchTime;
	if ($swMaxSearchTime<500) $swMaxSearchTime = 500;
	$db->init(); // provoke init
	$bitmap = $db->trigrambitmap;
	$ibitmap = $db->indexedbitmap;
	
	if ($refresh)
		$bitmap = new swBitmap;
	if ($bitmap->length == 0)
		$refresh = true;
	
	if ($refresh)
		clearTrigrams();
	
	$lastrevision = $db->lastrevision;
	$lasttrigram = 0;
	$n=1;
	$trigramindex = array();
	$affected = array();
	//$bitmap->redim(min($lastrevision, $bitmap->length + $numberofrevisions), false);
	
	
	
	$starttime = microtime(true);
			
	while($lasttrigram <= $lastrevision)
	{
		$nowtime = microtime(true);	
		$dur = sprintf("%04d",($nowtime-$starttime)*1000);
		if ($dur>$swMaxSearchTime) break;
		
		$lasttrigram++;
		if ($bitmap->getbit($lasttrigram)) continue;
		if (!$ibitmap->getbit($lasttrigram)) continue;
		$n++;
		
		//index;
		$w = new swRecord;
		$w->revision=$lasttrigram;
		$w->error = '';
		$w->lookup();
		if ($w->error != '')
		echotime($w->revision.' '.$w->error);
		
		$s = $w->name.' '.$w->content;
		$s = swNameURL($s);
		
		$trigrams = array();
		for($i=0;$i<strlen($s)-3;$i++)
		{
			$t = substr($s,$i,3);
			if (strlen($t)<3) continue;
			if (!stristr('abcdefghijklmnopqrstuvwxyz0123456789.-',substr($t,0,1))) continue;
			if (!stristr('abcdefghijklmnopqrstuvwxyz0123456789.-',substr($t,1,1))) continue;
			if (!stristr('abcdefghijklmnopqrstuvwxyz0123456789.-',substr($t,2,1))) continue;
			$trigrams[$t] = $t;
			$affected[$t] = true;
		}
		array_unique($trigrams);
		
		foreach($trigrams as $t)
			$trigramindex[$t][] = $lasttrigram;
		
		if ($w->error == '') 
        	$bitmap->setbit($lasttrigram);
		if ($n>$numberofrevisions) break;
		
		if (count($affected) * $n > 3000 * $numberofrevisions) break;
	}
	echotime('trigram save ');
	global $swRamdiskPath;
	if ($swRamdiskPath != '')
		$path0 = $swRamdiskPath.'trigram/';
	else
		$path0 = $swRoot.'/site/trigram/';

		if (!is_dir($path0)) mkdir($path0);
	$error = false;
	$fc = 0;
	foreach($trigramindex as $gram=>$revisions)
	{
		if (!count($revisions)) continue;
		$path = $path0.$gram.'.txt';
		if ($swRamdiskPath != '')
		{
			if (file_exists($path))
			{
				$list = file($path,FILE_IGNORE_NEW_LINES);
				unlink($path);
			}
			else
				$list = array();
			$f = @fopen($path,"w");
			$s = '';
			foreach($list as $r) $s.=$r.PHP_EOL;
			foreach($revisions as $r) $s.=$r.PHP_EOL;
			@fwrite($f, $s);
			@fclose($f); 
			$fc++;
			
		}
		elseif ($f = @fopen($path,"a+"))
		{
			$s = '';
			foreach($revisions as $r) $s.=$r.PHP_EOL;
			@fwrite($f, $s);
			@fclose($f); 
			$fc++;
		}
		else
		{
			$error = true;
		}
	
	}
	if (!$error)
	{
		$bitmap->save();
		$db->trigrambitmap = $bitmap;
		echotime('trigram end '.$fc.' affected '.$n);
	}
	else
	{
		echotime('trigram error');
	}
	
	
}

function clearTrigrams()
{
	 global $swRoot;
	 global $swRamdiskPath;
	if ($swRamdiskPath != '')
		$path0 = $swRamdiskPath.'trigram/';
	else
		$path0 = $swRoot.'/site/trigram/';

	 
	 $files = glob($path0.'/*.txt');
	   
	 foreach($files as $file)
	 {
	   	unlink($file);
	 }

}

function trigramlist()
{
	 global $swRoot;
	 global $swRamdiskPath;
	if ($swRamdiskPath != '')
		$path0 = $swRamdiskPath.'trigram/';
	else
		$path0 = $swRoot.'/site/trigram/';

	 
	 $files = glob($path0.'*.txt');
	  
	 $list = array();
	 foreach($files as $file)
	 {
	   $key = sprintf('%05d',filesize($file));
	   	$fn = str_replace($path0,'',$file);
	   	$fn = substr($fn,0,-4);
	   	$list[$key.' '.$fn] = $fn;
	 }
	 krsort($list);
	 return $list;
}



?>