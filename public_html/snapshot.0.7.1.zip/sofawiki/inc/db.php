<?php

/*
SOFA DB
- document oriented database inspired from couchdb but using semantic metawiki syntax
- the database has no tables and no predefined fields.
- fields are declared inline using the semantic mediawiki syntax [[fieldname::value]]
  fieldnames cannot start with an underscore
- multiple occurences of the same field are allowed
- the records are self-contained
- the records are stored as revisioned files adding a header with the reserved fields 
  _id automatically generated integer
  _revision automatically generated integer
  _name the wiki name, can change over time
  _timestamp sever time
  _status ok, request, protected, deleted
- the filename is the revision. the written files are never changed afterwards.
- on insertion of a new revision, the database writes some indexes. 
  these indexes are for performance only, they can be rebuild whenever needed from scratch
  - index to find the most recent ok revision of an id (or discard it if there is a more recent delete)
  - index for each field
  - fulltext index wordbased on each field
- queries can be done
  - individually return a sdRecord by id, by revision or by name
  - return a list of all revisions of an id
  - return a list of all revisions (or only current ids) that are conform to a filter
    filter use regex and are applied on all revisions.
    the filter results are saved, so that the next time only new revisions have to be applied for the same filter
    - filename as md5 of request
    - fields _query, _maxrevision, _timestamp
    
REQUIREMENTS
- php needs write access to the folders parsers, queries and revisions
 
*/


if (!defined('SOFAWIKI')) die('invalid acces');

function swGetAllRevisionsFromName($name)
{
	global $db;
	$url = swNameURL($name);
	$list = array();
	$names = $db->GetAllRevisions();
	
	foreach ($names as $k=>$v)
	{
		if ( swNameURL($v) ==  $url) $list[] = $k;
	}
	return $list;
}

function swGetPath($revision)
{
		global $swRoot;
		return $swRoot.'/site/revisions/'.$revision.'.txt';
}


class swDB extends swPersistance //extend may be obsolete
{
	
	// private
	var $revisions = array();  // revision=>name
	var $currentrevisions = array(); //revision (is much smaller than urls);
	var $urls = array(); // / url=>revision
	var $deletions = array();  // url=>revision 
	var $protections = array();  //  url=>revision 
	// public
	var $salt;
	var $hasindex = false;
	var $lastrevision = 0;
	var $persistance2 = '';
	var $modified = false;
	var $modifiedrevisions = array();
	var $trigrams = array();
	var $inited = false;
	var $usedIndexes = array();
	var $foundIndexes = array();
	
	function init($force = false)
	{
		global $swRoot; 
		global $swLazyIndexing;
		global $swMaxRelaxedSearchTime;
 
		if ($force)
		{
			$swMaxRelaxedSearchTime = 10000;
			$this->inited = false;
			$swLazyIndexing = false;
		}

		if ($this->hasindex)
			return;
		echotime("init"); 
		
		if ($this->inited)
			return;
		$this->inited = true;
		
		$this->lastrevision = 0; 
		
		global $swRoot;
		$file = $swRoot.'/site/indexes/lastrevision.txt';
		if (file_exists($file))
			$list = file($file,FILE_IGNORE_NEW_LINES);
		else
			$list = NULL;
		if (is_array($list))
			$this->lastrevision = $list[0];
		else
			$this->lastrevision = 0;
			
		echotime("lastrev ".$this->lastrevision);
		
		
		if ($this->lastrevision == 0)
		{
			echotime ('last 0');
			$sortedfiles = $this->GetRevisionFolderItems();
			$lastwrite = array_pop($sortedfiles);
			echotime('glob '.$lastwrite);
			$this->modifiedrevisions[] = $lastwrite;
			$this->RebuildIndexes();
			$this->inited = true;
			return;
		}
		
		if (isset($_GET['touch']))
		{
			echotime('touch '.$_GET['touch']);
			$this->modifiedrevisions[] = $_GET['touch'];
			$this->RebuildIndexes();
			return;
		}
		
		$list = $this->getTouchedRevisions();
		
		if (count($list)>0)
		{
			echotime('touchedc '. count($list));
			if ($swLazyIndexing)
			{
				echotime('lazy');
			}
			else
			{
				foreach($list as $r)
				{
					echotime ('touched '.$r);
					$this->modifiedrevisions[] = $r;
				}
				$this->RebuildIndexes();
			}
			return;
		}
		
		
		
		if (!$swLazyIndexing)
		{
			$this->openArray('revisions');
			$revisions = array_keys($this->revisions);
			$this->lastrevision = max($revisions);
			echotime('revisions '.$this->lastrevision); 
			
			$sortedfiles = $this->GetRevisionFolderItems();
			$lastwrite = array_pop($sortedfiles);
			echotime('glob '.$lastwrite); 
			
			if ($lastwrite > $this->lastrevision)
			{
				$this->modifiedrevisions[] = $lastwrite;
				echotime("mustindex");
				$this->RebuildIndexes();
				return;
			}
		}
		
		return;
				
		
	}
	
	function close()
	{
				
		if ($this->modified == true)
		{
			$this->modified = false;		
			
			echotime('closesave');
			$this->modifiedrevisions = array_unique($this->modifiedrevisions);
			$this->saveArray($this->revisions,'revisions');
			$this->saveArray($this->currentrevisions,'currentrevisions');
			$this->saveArray(array_flip($this->urls),'urls');
			$this->saveArray(array_flip($this->deletions),'deletions');
			$this->saveArray(array_flip($this->protections),'protections');
			global $swRoot;
			
			echotime('save '.$this->lastrevision." ".$this->hasindex);
		}
		
		global $swRoot; 
		$path = $swRoot.'/site/indexes/lastrevision.txt';
		if (file_exists($path))
			$list = file($path,FILE_IGNORE_NEW_LINES);
		if (is_array($list))
			$lastrevision = $list[0];
		if ($this->lastrevision != $lastrevision || $this->lastrevision==0)
		{
			echotime("last ".$this->lastrevision." ".$this->hasindex);
			if ($this->hasindex && $f = @fopen($path,"w"))
			{
				@fwrite($f, $this->lastrevision);
				@fclose($f); 
			}
		}
		
		
		
		
	}
	
		
	function openArray($label)
	{
	   global $swRoot;
	   echotime($label);
	   $arr = array();
	   $files = glob($swRoot.'/site/indexes/*.php');


		// man m�sste auch testen ob kontinuierlich alles da ist

	   foreach($files as $file)
	   {
	   		if (!stristr($file,'indexes/'.$label)) continue;
	   		
	   		$this->usedIndexes[$file]=1;
	   		include_once $file;
	   
	   }
	   //echotime($label.'.');

	}


	
	function UpdateIndexes($rev)
	{
		// echotime('r '.$rev);
		
		// be sure that all arrays are loaded if you write a record
		$r = new swRecord;
		$r->revision = $rev;
		$r->lookup();
		
		$this->modified = true;
		$this->revisions[$rev] = $r->name;
		$this->statuses[$rev] = $r->status;

		$url = swNameURL($r->name);
		
		
		// $this->lastrevision not good if we touch
		// check if there is a newer version
		if (isset($this->urls[$url]) && $rev < $this->urls[$url])
		{
			unset($this->currentrevisions[$rev]);
			return;
		}
		if (isset($this->deletions[$url]) && $rev < $this->deletions[$url])
		{
			unset($this->currentrevisions[$rev]);
			return;
		}
		if (isset($this->urls[$url]) && $rev == $this->urls[$url])
			return;
		if (isset($this->deletions[$url]) && $rev == $this->deletions[$url])
			return;
		
		// to find currentrevision index, we look up in urls				
		if (isset($this->urls[$url]))
		{
			$old = $this->urls[$url];
			unset($this->currentrevisions[$old]);
			$this->touchrevision($old);
		}
		
		
		switch ($r->status)
		{
			case 'ok': 
				$this->urls[$url] = $rev;
				$this->currentrevisions[$rev] = 1;
				unset($this->deletions[$url]);
				unset($this->protections[$url]);
				break;
			case 'protected': 
				$this->urls[$url] = $rev;
				$this->protections[$url] = $rev;
				$this->currentrevisions[$rev] = 1;
				unset($this->deletions[$url]);
				break;
			case 'deleted': 
				$this->deletions[$url] = $rev;
				unset($this->urls[$url]);
				unset($this->protections[$url]);
				break;
		}
		
		$this->lastrevision = max($this->lastrevision,$rev);
	}
	
	function touchRevision($r) 
	{
		
		global $swRoot;
		$path = $swRoot.'/site/indexes/touchedrevisions.txt';
		if ($f = @fopen($path,"a"))
		{
			@fwrite($f, $r."\n");
			@fclose($f); 
			echotime('touch '.$r.' ');
		}
		else
		{
			echotime('couldnottouch');
		}
	}

	function getTouchedRevisions()
	{
		
		global $swRoot;
		$path = $swRoot.'/site/indexes/touchedrevisions.txt';
		if (file_exists($path))
		{
			$list = file($path,FILE_IGNORE_NEW_LINES);
		}
		else
		{
			$list = array();
		}
		$list = array_unique($list);
		asort($list,SORT_NUMERIC);
		if (is_array($list))
			return $list;
		$list = array();
		return $list;
		
	}
	
	function clearTouchedRevisions()
	{
		global $swRoot;
		$file = $swRoot.'/site/indexes/touchedrevisions.txt';
		if (file_exists($file))
		{
			echotime('cleartouched');
			unlink($file);
		}		
	}
	
	function GetRevisionFolderItems()
	{
		global $swRoot;
		$files = glob($swRoot.'/site/revisions/*.txt',GLOB_NOSORT);
		$sortedfiles = array();
		
		echotime("glob");
		
		$pathlength = strlen($swRoot.'/site/revisions/');
		
		foreach($files as $file)
		{
			$f = substr($file,$pathlength);
			$f = (int)(substr($f,0,-4));
			//$f = str_replace($swRoot.'/site/revisions/','',$file);
			//$f = str_replace('.txt','',$f);
			
			$sortedfiles[$f] = $f;
		}
		ksort($sortedfiles,SORT_NUMERIC);
		
		
		
		
		return $sortedfiles;
	}
	
	
	function RebuildIndexes()
	{
		echotime("rebuild");  
		
		// we need a lockfile to prevent parallel indexing.
		
		global $swRoot;
		$lockfile = $swRoot.'/site/indexes/lock.txt';
		
		if (file_exists($lockfile))
		{
			echotime('lock');
			return;
		}
		
		if ($f = @fopen($lockfile,"w"))
		{
			@fwrite($f, 'x');
			@fclose($f); 
		}
		
		$this->usedIndexes = array();
		$this->foundIndexes = array();
		
		// cannot use getall, recursive init.
		$this->openArray('revisions');
		$this->openArray('currentrevisions');
		$this->openArray('urls');
		$this->urls= array_flip($this->urls);
		$this->openArray('deletions');
		$this->deletions= array_flip($this->deletions);
		$this->openArray('protections');
		$this->protections= array_flip($this->protections);
		
		/*
		print_r($this->usedIndexes);
		print_r($this->foundIndexes);
		*/
		
		foreach($this->usedIndexes as $k=>$v)
		{
			if(!isset($this->foundIndexes[$k]))
			{
				echotime('indexerror');
				unlink($lockfile);
				return;
			}
		}
		
		
		
		$revisions = array_keys($this->revisions);
		if (count($revisions)>0)
			$this->lastrevision = max($revisions);
		else
			$this->lastrevision = 0;
		
		echotime("revisions ".$this->lastrevision);
		
		
		
		
		
		global $swMaxRelaxedSearchTime;
		if ($swMaxRelaxedSearchTime==0) $swMaxRelaxedSearchTime=10000;
		$starttime = microtime(true);	
		$overtime = false;
		
		
		asort($this->modifiedrevisions);
		$maxmodified = array_pop($this->modifiedrevisions);
		$this->modifiedrevisions[] = $maxmodified; // undo pop
		
		
		
		// make sure that all blocks are written.
		for ($i = $this->lastrevision; $i <= $maxmodified; $i += 10000)
		{
			$this->modifiedrevisions[] = $i;
		}	
		
		asort($this->modifiedrevisions);
		
		$this->clearTouchedRevisions(); // must do before, update can create new.
		
		foreach($this->modifiedrevisions as $r)
		{
			
			if ($r < $this->lastrevision)
				$this->UpdateIndexes($r);
		}
		
		
		echotime('loop '. $this->lastrevision .' '. $maxmodified);
		for ($i = $this->lastrevision+1; $i <= $maxmodified; $i++)
		{
			
			$nowtime = microtime(true);	
			$dur = sprintf("%04d",($nowtime-$starttime)*1000);
			if ($dur>$swMaxRelaxedSearchTime)
			{
				echotime('overtime INDEX');
				global $swError;
				$swError = "Index incomplete. Please reload";
				$overtime = true;
				
				break;
			}
			$this->UpdateIndexes($i);
		}
		
		
		
		
		ksort($this->revisions,SORT_NUMERIC);
		ksort($this->deletions);
		ksort($this->protections);
		ksort($this->urls);
		ksort($this->currentrevisions,SORT_NUMERIC);
		
		if ($overtime)
		{
			$this->touchRevision($maxmodified);
		}
		else
		{
			$this->hasindex = true;
		}
		
		
		
		global $swRoot;
		$path = $swRoot.'/site/indexes/lastrevision.txt';
		if ($f = @fopen($path,"w"))
		{
			@fwrite($f, $this->lastrevision."\n");
			@fclose($f); 
			//echotime('lastrevision '.$this->lastrevision.' ');
		}
		else
		{
			echotime('couldnotlastwrite');
		}
		
		unlink($lockfile);
		
		echotime('built '.$this->lastrevision." ".$this->hasindex);		
	    
	}
	
	function GetAllUrls()
	{
		if (count($this->urls)==0)
		{
			$this->init();
			//debug_print_backtrace();
			$this->openArray('urls');
			$this->urls= array_flip($this->urls);
		}
		return $this->urls;
	}
	
	function GetAllDeletions()
	{
		if (count($this->deletions)==0)
		{
			$this->init();
			$this->openArray('deletions');
			$this->deletions= array_flip($this->deletions);
		}
		return $this->deletions;
	}
	function GetAllProtections()
	{
		if (count($this->protections)==0)
		{
			$this->init();
			$this->openArray('protections');
			$this->protections= array_flip($this->protections);
		}
		return $this->protections;
	}
	
	function GetAllRevisions()
	{
		if (count($this->revisions)==0)
		{
			$this->init();
			$this->openArray('revisions');
		}
		return $this->revisions;
	}
	
	function GetCurrentRevisions()
	{
		if (count($this->currentrevisions)==0)
		{
			$this->init();
			$this->openArray('currentrev');
		}
		return $this->currentrevisions;
	}
	function GetLastRevision()
	{
		if ($this->lastrevision == 0)
			$this->init();
		return $this->lastrevision;
	}
	
	function saveArray($arr, $label)  // must be at end BBedit bug
	{
	   
	   	global $swRoot;
	    ksort($arr,SORT_NUMERIC);
	    $f = false;
	    
	    $list = $this->modifiedrevisions;
	    foreach($list as $tr)
	    {
	    	
	    	$s = (int)($tr/10000);
	    	$starts[$s] = true;
	    }
	    
	    
	    
		$cm = -1;
	    foreach($arr as $k=>$v)
        {
	    	
	    	$m = (int)($k / 10000);
	    	
	    	if (!isset($starts[$m])) continue;
	    	
	    	if ($m != $cm)
	    	{
	    		
	    		if ($f)
	    		{
	    			@fwrite($f, '$db->foundIndexes["'.$path.'"]=1;');
	    			fwrite($f, '?>');
	    			@fclose($f); 
            		rename($temppath,$path);
            		echotime($label.' '.$cm);
	    		}
	    	    
	    		$cm = $m;
	    		
	    		$path = $swRoot.'/site/indexes/'.$label.$cm.'0000.php';
	    		
	    		$temppath = $swRoot.'/site/indexes/'.rand(100000,999999).'.php';
				
				$f = @fopen($temppath,"w");
				@fwrite($f, '<?ph'.'p global $db;'.PHP_EOL);
				
			}
	    	if ($f)
	    		 @fwrite($f, '$db->'.$label.'['.$k.'] = \''.str_replace('\'', '\\\'',$v).'\';'.PHP_EOL);
	    	 
         }
         if ($f)
         {
	    	@fwrite($f, '$db->foundIndexes["'.$path.'"]=1;');
         	fwrite($f, '?>');
         	@fclose($f); 
         	rename($temppath,$path);
         	echotime($label.' '.$cm);
         }
	}

	
	
}






?>