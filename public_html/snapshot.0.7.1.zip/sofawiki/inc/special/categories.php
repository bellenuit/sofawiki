<?php

if (!defined("SOFAWIKI")) die("invalid acces");

$swParsedName = "Special:Categories";


$revisions = $db->GetAllRevisions();
$urls = $db->GetAllURLs();

$swParsedContent = "";
$oldfirst = "";

foreach ($urls as $k=>$v)
{
	if (substr($k,0,9)=="category:" && !stristr($k,'/'))
	{
		$name = $revisions[$v];
		$categoryname = substr($name,9);
		$first = strtolower(substr($categoryname,0,1));
		
		if ($oldfirst && $oldfirst != $first) $swParsedContent .= "\n\n";
		$swParsedContent .= '<a href="http://www.artfilm.ch/arche/index.php?name='.$k.'">'.$categoryname.'</a> ';
		$oldfirst = $first;
 	}
}

$swParseSpecial = false;



?>