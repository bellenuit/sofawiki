<?php

if (!defined('SOFAWIKI')) die('invalid acces');

$swParsedName = 'Special:Fields';

$field = swGetArrayValue($_REQUEST,'field');
$query = swGetArrayValue($_REQUEST,'query');

if ($field) 
	$query = 'SELECT name , '.$field.' WHERE '.$field.' *';
if (!$field && !$query)
	$query = 'FIELDS';

$swParsedContent = '<div id="editzone"><form method="post" action="index.php">
		<p>
		<input type="hidden" name="name" value="special:fields" />
		<textarea name="query" rows=8 cols=90>'.$query.'</textarea>
		<input type="submit" name="submit" value="'.swSystemMessage('Search',$lang).'" /></p></form>';




	$lines = explode("\n",$query);
	
	$dtb = new swDataTableFunction;
	
	$swParsedContent .= '<p><a href="index.php?name=special:fields">All fields</a>';
	
	$swParsedContent .= $dtb->dowork($lines);
					

$query = str_replace("\n","<br>",$query);

$swParseSpecial = false;





?>