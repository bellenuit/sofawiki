<?php

if (!defined("SOFAWIKI")) die("invalid acces");

$swParsedName = "Special:Recent Changes";


$revisions = $db->GetAllRevisions();
uksort($revisions, 'strnatcasecmp'); 
$revisions = array_reverse($revisions, true);  // preserve keys

$swParsedContent = "";
$i = 0;

$item = new swWiki;
$now = date("Y-m-d H:i:s",time()-60*60*24*30);
$lastrevisiontime = date("Y-m-d H:i:s",time());

foreach ($revisions as $r=>$v)
{
	if ($i>30 && $lastrevisiontime<$now) continue;
	if ($i>100) continue;
	
	$item->revision = $r;
	$item->lookup(true);
	
	$lastrevisiontime = $item->timestamp;
	$i++;
	
	if ($item->wikinamespace()=="Image" || $item->wikinamespace()=="Category")
	{
		$swParsedContent .= "$item->timestamp $r [[:$item->name]] $item->status $item->user <i>$item->comment</i>\n";
	}
	else
	{
		$swParsedContent .= "$item->timestamp $r [[$item->name]] $item->status $item->user <i>$item->comment</i>\n";
	}
	
	

}
unset($now);

$swParseSpecial = true;


?>