﻿<?php

if (!defined("SOFAWIKI")) die("invalid acces");


class swTemplateParser extends swParser
{

	var $functions;
	var $transcludenamespaces;
	
	function info()
	{
	 	return "Handles pages transclusion, functions and templates";
	}
	
	function dowork(&$wiki)
	{
	
		$s = $wiki->parsedContent;
		
		global $swFunctions;
		$this->functions = $swFunctions;
		global $swTranscludeNamespaces;
		$this->transcludenamespaces = array_flip($swTranscludeNamespaces);
		
		// internal links
		//  preg_match_all("/\{\{([^\/\{\}]+)\}\}/U", $s, $matches, PREG_SET_ORDER);
		
		
		// if language version, replace {{}} with non-language version of same page
		
		if (stristr($wiki->name,'/') && stristr($s, '{{}}'))
		{
			$myname2 = substr($wiki->name,0,-3);
			$revision = swGetCurrentRevisionFromName($myname2);
			{
				$wiki2 = new swWiki;
				$wiki2->revision = $revision;
				$wiki2->lookup();
				
				if (trim($wiki2->content) == '')
					$s = str_replace('{{}}'."\n",'',$s);
				else
					$s = str_replace('{{}}',$wiki2->content,$s);
			}
		}
		
		
		// replace multiline templates with single line
		
		preg_match_all("/\{{([^\}]*)}}/mu", $s, $matches, PREG_SET_ORDER);
		foreach ($matches as $v)
		{
			$val0 = $v[1]; 
			if (!strpos($val0,"\n|")) continue;
			$val1 = str_replace("\n|","|",$val0);
			$val1 = str_replace("\n| ","|",$val0);
			$val1 = str_replace("\n","",$val1);
			$val1 = str_replace("\r","",$val1);
			$s = str_replace($val0,$val1,$s);
			
		}
		
		//preg_match_all("/\{{([-\.\w\/\: \|,\!\.\?\'«»\p{L}]+)\}}/u", $s, $matches, PREG_SET_ORDER);
		preg_match_all("/\{{([^\}]+)\}}/u", $s, $matches, PREG_SET_ORDER);
		
		foreach ($matches as $v)
		{
			
			
			
			$val0 = $v[1]; 
			$vals = explode('|',$v[1]);
			
			$val = $vals[0];
			
			
			
			
			if (array_key_exists($val,$this->functions))
			{
				$f = $this->functions[$val];
				$c = $f->dowork($vals);
				$s = str_replace("{{".$val0."}}",$c,$s);
				
			}
			
			
			if (strpos($val,":")===0)
			{
				$val = substr($val,1);
			}
			elseif (strpos($val,":")>0)
			{
				// explicite namespace
			}
			else
			{
				$val = "Template:$val";
			}
			
			
			
			
			$fields = split(":",$val);
			if (count($fields)>1 && !array_key_exists($fields[0],$this->transcludenamespaces))
			{
				 //echo "($fields[0]) not includable";
				 // print_r($this->transcludenamespaces);
				 continue;
			}
			
			
			
			$linkwiki = new swWiki();
			
					
					$revision = swGetCurrentRevisionFromName($val,true);
				if ($revision)
				{
					// now check if not deleted
					$linkwiki->revision = $revision;
					$linkwiki->lookup();
					
					if ($linkwiki->visible())
					{
						$c = $linkwiki->content;
						
						
						
						for ($i = 1; $i< count($vals); $i++)
						{
							$c = str_replace("{{{".$i."}}}",$vals[$i],$c);
						}
						
						
						$s = str_replace("{{".$val0."}}",$c,$s);
						
					}
				}
				else
				{
					if ($fields[0]=="System")
					{
						global $swSystemDefaults;
						if (array_key_exists($fields[1],$swSystemDefaults))
							$c = $swSystemDefaults[$fields[1]];
						else
						{
							$c = substr($fields[1],0,strpos($fields[1],"/"));
						}
						$s = str_replace("{{".$val0."}}",$c,$s);
					}
				}
		}
		
		
		
		$s0 = $wiki->parsedContent;
				
		$wiki->parsedContent = $s;
		
		// reparse fields, content may have changed
		
		$fp = new swFieldsParser;
		$fp->dowork($wiki);
		
		// recurse
		if ($s != $s0 &&  stristr($s,"{{") && stristr($s,"}}"))
		{
			
			$this->dowork($wiki);
		}
		
		
		
		
	}

}

$swParsers["templates"] = new swTemplateParser;


?>