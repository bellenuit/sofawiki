<?php

if (!defined("SOFAWIKI")) die("invalid acces");

class swResumeFunction extends swFunction
{

	function info()
	{
	 	return "(name,length) Returns the first words of an article";
	}

	
	function dowork($args)
	{
		
		
		$s = $args[1];		
		$length = $args[2];	
		
		$wiki = new swWiki;
		$wiki->name = $s;
		$wiki->revision = NULL;
		$wiki->lookup();
		$wiki->parsers = array();
		$wiki->parsers['nowiki'] = new swNoWikiParser;
		$s = $wiki->parse();
					
		
		
		$s = str_replace("'''","",$s);
		$s = str_replace("''","",$s);
			
		$p = 1;	
		while (substr($s,0,1)=="=" && $p)
		{
			$p = strpos($s,"\n");
			$s = substr($s,$p+1);
		}
		
		if (strlen($s)<$length) return $s;
		
		
		$p = strpos($s."\n","\n",2);
		
		$s = substr($s,0,$p);
		
		if ($p<$length) return $s;
		
		$list = explode(" ",$s);
		foreach ($list as $elem)
		{
			
			
			if ($t != "")
			{
				if (strlen($t)+1+strlen($elem)>$length)
					return $t."...";
				$t .= " ".$elem;
			}
			else
			{
				if (strlen($elem)>$length)
					return substr($elem,0,$length)."...";
				else
					$t = $elem;
			}
		}		
	}

}

$swFunctions["resume"] = new swResumeFunction;


?>