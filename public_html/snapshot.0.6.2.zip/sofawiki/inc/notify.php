<?

if (!defined("SOFAWIKI")) die("invalid acces");


function swNotify($action,$error,$label,$message,$receiver="")
{
	global $username;
	global $name;
	
	swLog($username,$name,$action,"",$lang,"","",$error,$label,$message,$receiver);
	
	// send email

	global $swNotifyMail;
	global $swNotifyActions;
	$actions = array_flip($swNotifyActions);
	
	if ($swNotifyMail)
	{
		$headers = "From: $swNotifyMail" . "\r\n" .
   		"Reply-To: $swNotifyMail" . "\r\n" .
   		'X-Mailer: PHP/' . phpversion();
   		
		if (array_key_exists($action,$actions))
		{
			if ($receiver !="")
			$receiver .= ", ";
			
			$receiver .= "$swNotifyMail";
		}
	}
	else
	{	
		$headers = "";
	}
	
	
	if ($receiver !="")
		mail($receiver, $label, $message, $headers);
	
}


function swLog($user,$name,$action,$query,$lang,$referer,$time,$error,$label,$message,$receiver)
{
	// write to log
	$timestamp = date("Y-m-d H:i:s",time());
	$daystamp = date("Y-m-d",time());
	$memory = memory_get_usage();
	global $ip;
	if ($user=="")
		$user = $ip;
	
	
	
	$t = "[[timestamp::$timestamp]] [[user::$user]] [[name::$name]] [[action::$action]] ";
	if ($query)
		$t .= "[[query::$query]] ";
	if ($query)
		$t .= "[[lang::$lang]] ";
	if ($referer)
		$t .= "[[referer::$referer]] ";
	if ($time)
		$t .= "[[time::$time]] ";
	if ($memory)
		$t .= "[[memory::$memory]] ";
	if ($error)
		$t .= "[[error::$error]] ";
	if ($label)
		$t .= "[[label::$label]] ";
	if ($receiver)
		$t .= "[[label::$receiver]] ";
	$t .="\n";
	
	$file = "site/logs/$daystamp.txt";
	if (!is_dir("site/logs")) mkdir("site/logs");
	if ($handle = fopen($file, 'a')) { fwrite($handle, $t); fclose($handle); }
	else { swException('Write error swNotify $action.txt');}
	
	
	
	
}


?>