<?php

if (!defined("SOFAWIKI")) die("invalid acces");

class swValueFunction extends swFunction
{

	function info()
	{
	 	return "(name, field, separator) gets the values of a field in a page";
	}

	
	function dowork($args)
	{

		// uses ../utilities.php

		$name = $args[1];		
		$field = $args[2];
		$separator = $args[3];	
		
	
		$wiki = new swWiki();
		$wiki->name = $name;
		$wiki->lookup();
		
		$s = $wiki->content;
		
		

		$results = swGetValue($s,$field,true);
		
		$result = join($separator,$results);
		
		return $result;
		
	}

}

$swFunctions["value"] = new swValueFunction;


?>