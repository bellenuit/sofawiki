<?php 

// This file must be text encoding UTF8 no BOM not to get problems with cookies

if (!defined('SOFAWIKI')) die('invalid acces');


class swPersistance 
{ 
    var $persistance; 
    var $hasbak;
        
    /**********************/ 
    function save() 
    { 
        $s = serialize(get_object_vars($this));
        //echotime($s);
        if($f = @fopen($this->persistance,"w")) 
        { 
            if(@fwrite($f,$s)) 
            { 
                @fclose($f); 
            } 
            else echotime("Could not write to file ".$this->persistance." at Persistant::save"); 
        }  
        else echotime("Could not open file ".$this->persistance." for writing, at Persistant::save"); 
        
        if (isset($this->hasbak) && $this->hasbak)
        {
        	$today = date("Y-m-d",time());
        	$path = $this->persistance.'.'.$today.'.bak';
        	if($f = @fopen($path,"w")) 
       		 { 
            	if(@fwrite($f,$s)) 
            	{ 
               	 @fclose($f); 
            	} 
            	else echotime("Could not write to file ".$path." at Persistant::save"); 
       		 }  
        	else echotime("Could not open file ".$path." for writing, at Persistant::save"); 
        }
        
    } 
    /**********************/ 
    function open() 
    { 
        $vars = array();
        if (file_exists($this->persistance))
        {
       	 	$vars = unserialize(@file_get_contents($this->persistance)); 
       		if (!$vars) 
       		{
       			if (isset($this->hasbak) && $this->hasbak)
       			{
       				$vars = unserialize(@file_get_contents($this->persistance.'.bak')); 
       			}
       			if (!$vars) 
       				echotime("Could not open file ".$this->persistance." for reading, at Persistant::save"); 
       		}
       		 	
        }
        //echotime(print_r($vars,true));
        if (!$vars)  return false;
        foreach($vars as $key=>$val) 
        {            
			$this->{$key} =$vars[$key];
        } 
        return true;
    } 
    /**********************/ 
} 

?>