<?php

if (!defined("SOFAWIKI")) die("invalid acces");

class swTidyParser extends swParser
{

	function info()
	{
	 	return "Removes HTML tags";
	}


	function dowork(&$wiki)
	{

		$s = $wiki->parsedContent;
		
		// echo "<p>s $s";
		
		// preformatted text
		 $s = preg_replace('/^[ ](.*)(\n)/Um', "<pre>$1</pre>", $s); 

        $s = strip_tags($s,'<b><i><u><s><pre><sup><sub><tt><code><span><br/><hr/><small><big><div>');
        // preserve numbered entities
        $s = preg_replace('/&#([^\s&]*);/', "ENTITY$1ENTITYEND", $s);
        $s = str_replace("&","&amp;",$s);
        $s = preg_replace('/ENTITY(.*)ENTITYEND/U', "&#$1;", $s);
		
		$wiki->parsedContent = $s;
		
	}

}

$swParsers["tidy"] = new swTidyParser;


?>