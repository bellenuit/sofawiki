<?php

if (!defined("SOFAWIKI")) die("invalid acces");


function swCron()
{
	
	if (function_exists('swInternalCronHook') && swInternalCronHook()) 
	{
		// everything is handled by configuration.php
	}
	else
	{
		// do some housework by default from time to time
		global $swRoot;
		switch(rand(0,100))
		{
			case 0: echotime('cron index'); global $db; $db->init(true); break; // rebuild indexes 
			
			case 1: echotime('cron trigram'); swIndexTrigram();  break; 
			
			case 2: echotime('cron fields'); swIndexRandomFields(1000);  break; 
			
			case 3: echotime('cron sitemap'); swSitemap();  break; 
			
			default:
		
		}
		
		
	}
}



function swIndexRandomFields($maxtime)
{
	global $swMaxOverallSearchTime;
	$mrst = $swMaxOverallSearchTime;
	$swMaxOverallSearchTime=$maxtime;
	global $swSearchNamespaces;
	$ns = join(' ',$swSearchNamespaces);
	
	$q = swFilter('FIELDS',$ns,'data');
	$f = '';
	if (is_array($q))
	{
		$q = array_keys($q);
		shuffle($q);
		$f = array_pop($q);
	}
	if ($f != '')
	{
		$w = 'SELECT name WHERE '.$f.' *';
		$q2 = swFilter($w,$ns,'data');
	}

	$swMaxOverallSearchTime = $mrst;	
}




?>