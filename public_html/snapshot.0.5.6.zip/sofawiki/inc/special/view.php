<?php

if (!defined("SOFAWIKI")) die("invalid acces");


if ($user->hasright("view", $wiki->name) || $user->hasright("talk", $wiki->simplename()) )
{
		
	if ($wiki->status == "deleted" || $wiki->status == "delete")
	{
		$swError = swSystemMessage("ThisPageHasBeenDeletedError",$lang);
	}
	else
		$swParsedContent = $wiki->parse();
	
	$swFooter = "Revision:$wiki->revision, $wiki->user, Date:$wiki->timestamp, Status:$wiki->status";
	$swFooter = "";  // do not show

}
else
{
	$swError = swSystemMessage("NoAccessError",$lang);
	$swFooter = "";
}

$swParsedName = $wiki->localname($lang);  // must be here, because the wiki can be redirected
if ($name != $wiki->name and $user->hasright("modify", $wiki->name))
{
	$swEditMenus[] = "<a href='".$wiki->link("edit")."'>".swSystemMessage("Edit",$lang)." $wiki->name</a>";
}

$t = "";
if ($wiki->istalk())
{

	if ($user->hasright("talk", $wiki->simplename()) || $user->hasright("modify", $wiki->name))
	{
		
		// do not propose it when it is protected
		 if ($wiki->status != "protected")
		$t = "<a href='".$wiki->link("newtalk")."'>".swSystemMessage("NewTalk",$lang)."</a>";
		
		
	}
	elseif ($username != "")
	{
		
		$t = "<div id='help'>".swSystemMessage("NewTalkNotPossibleWithThisUser",$lang)."</div>";
	}
	else
	{
		$t = "<div id='help'>".swSystemMessage("NewTalkNotPossible",$lang)."</div>";
	}	
	
	if ($wiki->content == "")
	{
		
		$swParsedContent = $t;
	}
	else
	{
		$swParsedContent = $t."<hr/>".$swParsedContent;
	}
	
}
unset($t);
						

?>