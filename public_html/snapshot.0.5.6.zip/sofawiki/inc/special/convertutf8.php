<?php

if (!defined("SOFAWIKI")) die("invalid acces");

$swParsedName = "Convert UTF8";
$swParsedContent = "";
$swParsedContent .= "Converts Latin1-revisions to UTF8-revisions<br/><br/>";



$zipfile = new zipfile();  

$emptydirectories = array();
$includeddirectories = array();

$emptydirectories[] = "sofawiki/site/cache"; 
$emptydirectories[] = "sofawiki/site/indexes";
$emptydirectories[] = "sofawiki/site/queries";
$emptydirectories[] = "sofawiki/site/current";

$includeddirectories[] = "sofawiki/site/revisions";

$files = array();


foreach($emptydirectories as $dir)
{
	$swParsedContent .= "$dir<br/>";
	
	// clear all file sin folder
	
}

foreach ($includeddirectories as $dir)
{
	$swParsedContent .= "$dir<br/>";
	$dir = substr($dir,strlen("sofawiki/"));
	$absolutedir = "$swRoot/".$dir;
	
	$formats = array("php","css","txt");
	
	foreach ($formats as $f)
	{
		$files = glob($absolutedir."/*.$f");
		natsort($files);
		foreach($files as $file)
		{
			file_get_contents($file);
			
			$zf = str_replace($swRoot,"sofawiki",$file);
			$zipfile -> add_file(file_get_contents($file), $zf,filemtime($file)); 
			$swParsedContent .= "&nbsp;$zf<br/>";
		}
	}
}

$today = date("Ymd",time());

$filename = "site".".zip";
$fd = fopen("$swRoot/bak/".$filename, "wb");
$out = fwrite ($fd, $zipfile -> file());
fclose ($fd);

$filename = "site$today".".zip";
$fd = fopen("$swRoot/bak/".$filename, "wb");
$out = fwrite ($fd, $zipfile -> file());
fclose ($fd);
	
$swParsedContent .=  "<br/><a href='backup.zip'>backup.zip</a>";





?>