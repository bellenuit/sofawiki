<?php

if (!defined("SOFAWIKI")) die("invalid acces");

class swResumeFunction extends swFunction
{
	var $searcheverywhere = false;
	function info()
	{
	 	return "(name,length) Returns the first words of an article";
	}

	
	function dowork($args)
	{
		
		
		$s = $args[1];	
		if (isset($args[2])) $length = floatval($args[2]); else $length = 255;	
		
		global $swTranscludeNamespaces;
		$transcludenamespaces = array_flip($swTranscludeNamespaces);

		if (!$this->searcheverywhere && stristr($s,':') 
		&& !array_key_exists('*',$transcludenamespaces))
		{
			$fields = explode(':',$s);
			if (!array_key_exists($fields[0],$transcludenamespaces))
			return '';  // access error
		}
		
		$wiki = new swWiki;
		$wiki->name = $s;
		$wiki->revision = NULL;
		$wiki->lookup();
		$wiki->parsers = array();
		$wiki->parsers['nowiki'] = new swNoWikiParser;
		$s = $wiki->parse();
					
		
		
		$s = str_replace("'''","",$s);
		$s = str_replace("''","",$s);
			
		$p = 1;	
		while (substr($s,0,1)=="=" && $p)
		{
			$p = strpos($s,"\n");
			$s = substr($s,$p+1);
		}
		
		if (strlen($s)<$length) return $s;
		
		
		$p = strpos($s."\n","\n",2);
		
		$s = substr($s,0,$p);
		
		if ($p<$length) return $s;
		
		$list = explode(". ",$s);
	
		$t = '';
		
		foreach ($list as $elem)
		{
			if (strlen($t)>$length) return $t.'.';
			
			if ($t != "")
			{
				$test = $t.'. '.$elem;
				if (strlen($test)<=$length*1.5)
					$t .= '. '.$elem;
				else
					return $t.".";
				
			}
			else
			{
				if (strlen($elem)>$length*1.5)
					return substr($elem,0,$length)."...";
				else
					$t = $elem;
			}
		}
		return $t;
	}

}

$swFunctions["resume"] = new swResumeFunction;


?>