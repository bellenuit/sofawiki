<?php


if (!defined('SOFAWIKI')) die('invalid acces');




function swQuery($filter,$namespace,$mode="relaxed")
{
	
	// split set in words and filter for each one, then combine them
	
	$filterlist = swQuerySplit($filter);  // will have to be more sophisticated to allow for spaces within [[field::value]]
	global $swSearchWordLimit;
	
	// we remove all terms with less than 3 characters and limit the list length
	$newfilterlist = array();
	for ($i=0;$i<count($filterlist);$i++)
	{
		$term = $filterlist[$i];
		if (strlen($term)>=3)
			$newfilterlist[] = $term;
		if (count($filterlist)==$swSearchWordLimit)
			break;
	}
	$filterlist = $newfilterlist;	

	// limit time for searches
	global $swMaxRelaxedSearchTime;
	$swMaxRelaxedSearchTime = $swMaxRelaxedSearchTime*2/(count($filterlist)+1);
	if (isset($_REQUEST['moreresults'])) $swMaxRelaxedSearchTime *=2;
	
	$revisionlists = array();
	
	foreach ($filterlist as $f)
	{
		$rev = swFilter($f,$namespace,$mode);
		$revisionlists[] = $rev;
	}
	$rev0 = array();
	$c = count($revisionlists);
	if ($c>0)
		$rev0 = $revisionlists[0];
	if ($c>1) 
	{
		for ($i=1;$i<$c;$i++)
		{
			$rev1 = $revisionlists[$i];
			//echo "<pre>";print_r($rev1);echo "</pre>";
			foreach($rev0 as $k=>$v)
			{
				//echo "<br>k $k v $v rev1 $rev1[$k]";
				if (isset($rev1[$k]))
					$rev0[$k] *= $rev1[$k];
				else
					unset($rev0[$k]);
			}
		}
	}
	
    arsort($rev0,SORT_NUMERIC);
//	print_r($rev0);
	return $rev0;
}


function swFilterCompare($operator,$values,$term)
{	
	if (!is_array($values))  // single value
		$values = array($values);
	
	$valuelist = array();
	
	if ($operator == '*')
	{
		if (count($values)>0) return true;
		return false;
	}
	
	foreach($values as $v)
	{
		$valuelist[] = swUnescape($v);
	}
	
	
	$term = swUnescape($term);
		
	switch ($operator)
	{
		case '=': foreach($valuelist as $v)
				   {	if (floatval($v)==floatval($term)) return true; } break;
		case '<>': foreach($valuelist as $v)
				   {	if (floatval($v)==floatval($term)) return true; } break;
		case '<': foreach($valuelist as $v)
				   {	if (floatval($v)<floatval($term)) return true; } break;
		case '>': foreach($valuelist as $v)
				   {	if (floatval($v)>floatval($term)) return true; } break;
		case '<=': foreach($valuelist as $v)
				   {	if (floatval($v)<=floatval($term)) return true; } break;
		case '>=': foreach($valuelist as $v)
				   {	if (floatval($v)>=floatval($term)) return true; } break;
		case '==': foreach($valuelist as $v)
				   {	if ($v==$term) return true; } break;
		case '!=': foreach($valuelist as $v)
				   {	if ($v!=$term) return true; }  break;
		case '=*': foreach($valuelist as $v)
				   {	if (substr($v,0,strlen($term))==$term) return true; } break;
		case '!=*': return true; foreach($valuelist as $v)
				   {	if (substr($v,0,strlen($term))==$term) $found = false; } break;
		case '*=': foreach($valuelist as $v)
				   {	if (substr($v,-strlen($term))==$term) return true; } break;
		case '!*=': return true;foreach($valuelist as $v)
				   {	if (substr($v,-strlen($term))==$term) $found = false; } break;
		case '*=*': foreach($valuelist as $v)
				   {	 if (stripos($v,$term) !== FALSE) return true; } break;
		case '!*=*': return true;foreach($valuelist as $v)
				   {	if (stripos($v,$term) !== FALSE) $found = false; } break;
		case '<<': foreach($valuelist as $v)
				   {	if ($v<$term) return true; } break;
		case '>>': foreach($valuelist as $v)
				   {	if ($v>$term) { return true; } } break;
		case '<<=': foreach($valuelist as $v)
				   {	if ($v<=$term) return true; } break;
		case '>>=': foreach($valuelist as $v)
				   {	if ($v>=$term) return true; } break;
		case '!~': return true; foreach($valuelist as $v)
				   {    $v = swNameURL($v);
						if (stripos($v,$term) !== FALSE) $found = false; } break;
		case '~~': foreach($valuelist as $v)
				   {	$v = swNameURL($v);
						if ($v==$term) return true; } break;
		case '~*': foreach($valuelist as $v)
				   {	$v = swNameURL($v);
						if (substr($v,0,strlen($term))==$term) return true; } break;
		case '*~': foreach($valuelist as $v)
				   {	$v = swNameURL($v);
						if (substr($v,-strlen($term))==$term) return true; } break;
		case '*~*': foreach($valuelist as $v)
				   {    $v = swNameURL($v);
						if (stripos($v,$term) !== FALSE) return true; } break;						
		case '!0': foreach($valuelist as $v)
				   {	if ($v != 0 || $v != '') return true; } break;
		case 'r=': foreach($valuelist as $v)
					{ if (preg_match($term, $v, $matches)) return true; }
					break;
		default:   return false;
	}
	return false;
}

function swQueryFieldlistCompare($revision, $fieldlist,$fields,$field,$operator,$term,$comparefields)
{
	// compares a tuple against an operation and a term and returns a tuple
	
	$row = array();
	
	// normalize array, to a table
	$maxcount = 0;
	foreach($fieldlist as $v)
	{
		$maxcount = max($maxcount,count($v));
	}	
	$fieldlist2 = array();
	foreach($fieldlist as $key=>$v)
	{
		for($fi=0;$fi<count($v);$fi++)
		{
			$fieldlist2[$fi][$key] = $v[$fi];
		}
		for ($fi=count($v);$fi<$maxcount;$fi++)
		{
			$fieldlist2[$fi][$key] = $v[count($v)-1];
		}
	}
	
	// compare
	for ($fi=0;$fi<$maxcount;$fi++)
	{
		$onefieldvalue = $fieldlist2[$fi][$field];
		if ($comparefields)
		{
			$term2 = swQueryTupleExpression($fieldlist2[$fi], $term);
			if (is_array($term2))
			{
				return $term2; //error
			}
			else
				$found = swFilterCompare($operator,array($onefieldvalue),$term2);
		}
		else
			$found = swFilterCompare($operator,array($onefieldvalue),$term);
			
		if ($found)
		{
			
			foreach ($fields as $f)
			{
				// we cannot return an error here, because the data might be an old revision with other data scheme
				$row[$f][$revision.'-'.$fi] = @$fieldlist2[$fi][$f];
			}
		}
	}
	//print_r($row);
	return $row;

}

function swFilter($filter,$namespace,$mode='query',$flags="current")
{
	global $swRoot;
	global $db;
	$goodrevisions = array();
	$operator = '';
	$fields = array();
	$field = '';
	$term = '';
	$over = false; 
	$namefilter = '';
	$namefilter0 = '';
	$rowsort =false;
	
	//echomem("start",true); 
	echotime('query '.$mode.'-'.$namespace.' '.$filter);
	//echo $filter;

	// parse select string SELECT fields WHERE field operator term
	
	if (($mode=='data' || $mode=='query') && substr($filter,0,6) == 'SELECT')
	{
		$filter2 = substr($filter,7);
		
		if ($p = strpos($filter2,' FROM '))
		{
			//namefilter from query is not the same that the namespace that depends on 
			//the user rights
			$p+= strlen(' FROM ');
			if (!$p2 = strpos($filter2,' WHERE '))
				$p2 = strlen($filter2);
			$namefilter = $namefilter0 = substr($filter2,$p,$p2-$p);
			$filter2 = str_replace(' FROM '.$namefilter,'',$filter2);
			
			$namefilter = trim($namefilter);
			$namefilter = swNameURL($namefilter);
		}
		
		if (!stristr($filter2,' WHERE '))
			$filter2 .= ' WHERE ';
		
		if ($p = strpos($filter2,' WHERE '))
		{
			$fields = substr($filter2,0,$p);
			$fs = explode(',',$fields);
			$fields = array();
			foreach($fs as $f)	{ $fields[]=trim($f); }
			$fields = array_unique($fields);
			
			
			$query = substr($filter2,$p+strlen(' WHERE '));
			$words = explode(' ',$query);
			$wordlist = array();
			foreach($words as $w) { if ($w != '') $wordlist[] = $w; }
			if (count($wordlist)>0)
			{
				$field = $wordlist[0]; 
				if (count($wordlist)>1)
				{
					$operator = $wordlist[1];
					unset($wordlist[1]);
				}
				else
					$operator = '*';
				unset($wordlist[0]);
				if (count($wordlist)>0)
					$term = trim(join(' ',$wordlist));
				else
					$term = '';
			}
			else
			{
				// find all
				$field = $fields[0];
				$operator = '*';
				$term = '';
			}
		}
	}
	
	$comparefields = false;
	if (substr($operator,0,1) == '$')
	{	
		$operator = substr($operator,1);
		$comparefields = true;
	}
	
	
	if (($mode=='data' || $mode=='query') && substr($filter,0,6) == 'FIELDS')
		$fields = array('fields');
	
	if ($mode == 'relaxed') 
		$filter = swNameURL($filter);

	if ($mode == 'relaxed' || $mode == 'regex')
		$rowsort = true;

	if ($operator == '~~'|| $operator == '*~'|| $operator == '~*'|| $operator == '*~*') 
		$term = swNameURL($term);

	// VIRTUAL
	if ($mode=='query' && stristr($namefilter0, 'VIRTUAL '))
	{
		echotime('virtual');
		$urlname = str_replace('VIRTUAL ','',$namefilter0);
		$urlname = trim($urlname);
		$urlname = swNameURL($urlname);
		$namespace2 = swNameURL($namespace);
		if (stristr($urlname,':')) // page has namespace
		{
			if ($namespace =='') 
				return(array('_error'=>'invalid name '.$urlname));
					
			$ns = substr($urlname,0,strpos($urlname,':')); // get namespace of page
			if (!stristr($namespace2.'-',$ns.'-') && $namespace!='*')
				return(array('_error'=>'invalid name '.$urlname));
	    }
		
		$w = new swWiki;
		$w->name = $urlname;
		$w->lookup();
		
		if ($w->revision == 0) return(array('_error'=>'unknown name '.$urlname));
		
		$w->parsedContent = $w->content;
		$fp = new swTidyParser;
		$fp->dowork($w);
		$fp = new swTemplateParser;
		$fp->dowork($w);
		
		$s = $w->parsedContent; //field output has nowiki tags
		$s = str_replace('<nowiki>','',$s);
		$s = str_replace('</nowiki>','',$s);
		
		$list = swGetAllFields($s);
		
		$row = swQueryFieldlistCompare($w->revision,$list,$fields,$field,$operator,$term,$comparefields);
		
		// flatten
		$r2 = array();
		foreach($row as $f=>$fs)
		{
			foreach($fs as $k=>$v)
			{
				$r2[$k][$f] = $v;
			}
		}
		return $r2;
	}
	
	
	
	// find already searched revisions
	$lastfoundrevision = 0;
	$mdfilter = $filter;
	$mdfilter .= $namespace;
	$mdfilter .= $mode;
	$mdfilter = urlencode($mdfilter);
	$cachefile2 = $cachefile = $swRoot.'/site/queries/'.md5($mdfilter).'.txt';
	
	
	
	global $swDebugRefresh;
	if ($swDebugRefresh)
		{ $refresh=1; echotime('refresh');}
	else	
		$refresh=0;
		
	if (stristr($flags,'refresh')) $refresh=1;
	
	if (file_exists($cachefile) && !$refresh) 
	{
		$s = file_get_contents($cachefile);
		$results = unserialize($s);
		//echomem("open",true); 
		$lastfoundrevision = $results['lastfoundrevision'];
		
		
		$goodrevisions  = $results['goodrevisions'];
		if (isset($results['bitmap']))
			$bitmap = $results['bitmap'];
		else
			$bitmap = new swBitmap;
		echotime('cached '.count($goodrevisions).' / '.$lastfoundrevision.' '.md5($mdfilter).'.txt');
		unset($results);
		unset($s);
	}
	else
	{
		if (file_exists($cachefile))
			unlink($cachefile);
		$lastfoundrevision = 0;
		$goodrevisions = array();
		$bitmap = new swBitmap;
	}
	//echomem("cached",true); 	
	$maxlastrevision = $db->lastrevision;
	
	if ($lastfoundrevision < $maxlastrevision)
	{
	
		$bitmap->redim($maxlastrevision,true);
		
				
		// if there is an existing search on a substring, we can exclude all urls with no result
		// a cron tab will create searches on all possible strings with 3 characters
		// we therefore test again all substrings with 3 characters
		$lastrevision =$lastfoundrevision; 
	
			
			// restrict on namefilter
			if ($namefilter && ($mode == 'query' || $mode == 'data'))
			{
					$filter2 = 'SELECT name WHERE name ~* '.$namefilter;
			    	$filter2revisions = swFilter($filter2,'*','data'); // must stay data for $maxfilter2revision being number
			    	//print_r($filter2revisions);
			    	$ak = array_keys($filter2revisions);
					if (count($ak)>0)
						$maxfilter2revision = max($ak);
					else
						$maxfilter2revision = 0;
					for($k=0;$k<$maxfilter2revision;$k++)
					{
						if (!isset($filter2revisions[$k]))
							$bitmap->unsetbit($k);
					}
					
					echotime('- nf '.$bitmap->countbits());
			}
			
			if ($maxlastrevision - $lastfoundrevision > 50 ) // small searches reduction is not interesting
			{
				
				// if it is data search, we can restrict to all revisions that have the field
				if (isset($field) && (($mode == 'query' && substr($field,0,1) != '_' ) || ($mode == 'data' && $field != 'content'  && $field != 'name' && $field != '')) && $operator != '*')
				{
					
					$filter2 = 'SELECT '.$field.' WHERE '.$field.' * ';
					$filter2revisions = swFilter($filter2,'*','data',$flags);  // must stay data for $maxfilter2revision being number
					$ak = array_keys($filter2revisions);
					if (count($ak)>0)
						$maxfilter2revision = max($ak);
					else
						$maxfilter2revision = 0;
					$term2 = swNameURL($term);
					for($k=0;$k<$maxfilter2revision;$k++)
					{
						if (!isset($filter2revisions[$k]))
							$bitmap->unsetbit($k);


						//experimental
						
						// we cannot use it with comparefields because we do not know the other fields
						if (!$comparefields && isset($filter2revisions[$k]) && !swFilterCompare($operator,$filter2revisions[$k][$field],$term))
							$bitmap->unsetbit($k);
						
						
					}
					echotime('- * '.$bitmap->countbits());
				}	
				
				if ($mode == 'relaxed' && strlen($filter)>=3)
				{
					for($i=0;$i<=strlen($filter)-3;$i++)
					{
						if ($bitmap->countbits()<50) continue;
						$f = substr($filter,$i,3);
						$gr = getTrigram($f);
						if ($gr)
						{
							$gr->redim($bitmap->length, true);
							$bitmap = $bitmap->andop($gr);
						}
						
						echotime('- '.$f.' '.$bitmap->countbits());
					}
				
				}
				
				// search only in records which have the field
				// and use also the 3letter-trick on the field
				if (isset($field) && strlen($field)>=3 && (($mode == 'query' && substr($field,0,1) != '_' ) || ($mode == 'data' && $field != 'content'  && $field != 'name'))  )
				{
						
					$field2 = swNameURL($field);
					for($i=0;$i<=strlen($field2)-3;$i++)
					{
						if ($bitmap->countbits()<50) continue;
						$f = substr($field2,$i,3);
						$gr = getTrigram($f);
						if ($gr)
						{
							$gr->redim($bitmap->length, true);
							$bitmap = $bitmap->andop($gr);
						}
						
						echotime('- '.$f.' '.$bitmap->countbits());
					}
						
						
				}
				
				// use the 3letter trick on the term (trigram)
				if (isset($term) && ($mode == 'data' || $mode == 'query')  && !$comparefields && strlen($term)>=3 && ( $operator == '==' || $operator == '*=' || $operator == '=*' 
				|| $operator == '*=*' 
				|| $operator == '~~'|| $operator == '*~'|| $operator == '~*'|| $operator == '*~*'))
				{
					
					if (strlen($term)>3)
					{
						$term2 = swNameURL($term);
						for($i=0;$i<=strlen($term2)-3;$i++)
						{
							if ($bitmap->countbits()<50) continue;
							$f = substr($term2,$i,3);
							$gr = getTrigram($f);
							if ($gr)
							{
								$gr->redim($bitmap->length, true);
								$bitmap = $bitmap->andop($gr);
							}
						
							echotime('- '.$f.' '.$bitmap->countbits());
						}
					}
				}
			
			}
			
			$starttime = microtime(true);	
			global $swMaxRelaxedSearchTime;
			global $swMaxOverallSearchTime;
			if ($swMaxOverallSearchTime<300) $swMaxOverallSearchTime = 1000;
			global $swOvertime;
			
			echotime('loop');
			//echomem("loop",true); 
			
			for ($k=$lastfoundrevision+1;$k<=$maxlastrevision;$k++)
			{
				if (!$bitmap->getBit($k) && $k<$maxlastrevision-16 ) continue; // last bits always check
				
				
				if ($mode == 'relaxed' && $swMaxRelaxedSearchTime>0)
				{
					$nowtime = microtime(true);	
					$dur = sprintf("%04d",($nowtime-$starttime)*1000);
					if ($dur>$swMaxRelaxedSearchTime)
					{
						echotime('overtime '.$lastrevision.' / '.$maxlastrevision);
						$swOvertime=true;
						$over = true;
						break;
					}
					
				}
				
				if ($swMaxOverallSearchTime>0)
				{
					
					$nowtime = microtime(true);	
					$dur = sprintf("%04d",($nowtime-$starttime)*1000);
					if ($dur>$swMaxOverallSearchTime) 
					{
						echotime('overtime');
						$swOvertime=true;
						$over = true;
						break;
					}
				}	
				$lastrevision = $k;
				
				
				$record = new swRecord;
				$record->revision = $k;
				$record->lookup();
				
				

				$urlname = swNameURL($record->name);
				
				// apply namefilter
				
				if ($namefilter != '' && substr($urlname,0,strlen($namefilter)) != $namefilter)
					continue;
				
				
				// apply namespace
				
				$namespace2 = swNameURL($namespace);
				if (stristr($urlname,':')) // page has namespace
				{
					if ($namespace =='') 
						continue;
					
					$ns = substr($urlname,0,strpos($urlname,':')); // get namespace of page
					if (!stristr($namespace2.'-',$ns.'-') && $namespace!='*')
						continue;
				}
				
				
				$content = $record->name.' '.$record->content;
				$row=array();
				
				switch($mode)
				{
				case 'data':
				case 'query':
					$fieldlist = $record->internalfields;
	
					if ($filter == 'FIELDS')
					{
						$keys =array_keys($fieldlist);
						if (count($keys)>0)
							$row['fields'] = $keys;
					}
					elseif (substr($filter,0,6) == 'SELECT')
					{
						
						
						if ($mode=='query')
						{
							$fieldlist['_revision'][] = $record->revision;
							$fieldlist['_status'][] = $record->status;
							$fieldlist['_name'][] = $record->name;
							$fieldlist['_content'][] = $record->content;
						}
						else
						{
							$fieldlist['revision'][] = $record->revision;
							$fieldlist['status'][] = $record->status;
							$fieldlist['name'][] = $record->name;
							$fieldlist['content'][] = $record->content;
							$fieldlist['*'][] = $content;
						}
						
						// if ($mode=='query') echotime("query now $k $field ".print_r($fieldlist,true));
						
						
						if (!isset($fieldlist[$field])) continue;
						
						$row = array();
						if ($mode == 'query')
						{
							$row = swQueryFieldlistCompare($k,$fieldlist,$fields,$field,$operator,$term,$comparefields);
							if (isset($row['_error'])) return $row;
							
						}
						else
						{
							$found = swFilterCompare($operator,$fieldlist[$field],$term);
							if ($found)
							{
								foreach ($fields as $f)
								{
									if (isset($fieldlist[$f]))
										$row[$f]= $fieldlist[$f];
									else
										$row[$f] = "";
								}
							}
						}
						
					}
					
					if (count($row)>0)
					{
						$goodrevisions[$k] = $row;
					}
					else
						$bitmap->unsetbit($k);
					break;
				case 'regex':
					$matches = array();
					$offset = 0;
					$row = 0;
					
					while (preg_match($filter, $content, $matches, PREG_OFFSET_CAPTURE, $offset))
					{
						if (is_array($matches[0]))
							$m = $matches[0][1];
						else
							$m = $matches[1];
						$row += 1 - ($m / (strlen($content)- $offset) );
						$offset += $m+1;
					}
					if ($row>0)
					{
						$goodrevisions[$k]['_row'] = sprintf('%09.3f',$row);
					}
					else
						$bitmap->unsetbit($k);
					
					break;
				case 'relaxed': // query
					$content = swNameURL($content);
				default:	
					if (stristr($content,$filter))
					{
						//row value will be simple rating algorithm: 
						//counts the number of occurences and the position
						
						$row = 0;
						$len0 = strlen($content);
						if (stristr($record->name,$filter))
						{
							$row += 100;
						}
						while ($content = stristr($content,$filter))
						{
							$row += strlen($content) / $len0;
							$content = substr($content,1);
						}
						$goodrevisions[$k]['_row'] = sprintf('%09.3f',$row);
					}
					else
						$bitmap->unsetbit($k);
					
				}
			}
			
			
			
			
			
			echotime('good '.count($goodrevisions).' / '.$lastrevision);
			echomem("filter");	
			
			
			// now we have a list of goodrevisions.
			// some revisions may not be valid depending on flag, we will remove them 
			
			$db->init();
			$currentbitmap = $db->currentbitmap->duplicate();
			$deletedbitmap = $db->deletedbitmap->duplicate();
			
			foreach($goodrevisions as $k=>$v)
			{
				if (!stristr($flags,'all') && !$currentbitmap->getbit($k))
				{
					$bitmap->unsetbit($k);
					unset($goodrevisions[$k]);
					continue;
				}
				
				if (!stristr($flags,'deleted') && $deletedbitmap->getbit($k))
				{
					$bitmap->unsetbit($k);
					unset($goodrevisions[$k]);
					continue;
				}
				
			}
			echotime('valid '.count($goodrevisions).' / '.$lastrevision);
			
			// save to cache
			
			$results=array();
			$results['filter'] = $filter;
			$results['mode'] = $mode;
			$results['namespace'] = $namespace;
			$results['flags'] = $flags;
			$results['bitmap'] = $bitmap;
			$results['lastfoundrevision'] = $lastrevision;
			$results['goodrevisions'] = $goodrevisions;
			
			$t = serialize($results);
			
			
			if ($handle = fopen($cachefile2, 'w')) { fwrite($handle, $t);  fclose($handle); }
			else { swException('Write error Query cache'); return;}
		
			echotime('saved');

		// we do not need allurls any more
		$allrevisions = NULL;
	
	}
	
	
	
	if ($rowsort)
	{
		
		foreach($goodrevisions as $k=>$v)
		{
			$goodrevisions[$k] = $v['_row'];
		}
		arsort($goodrevisions);
	}
	
	
	if ($filter=="FIELDS")
	{
		$ts = array();
		foreach($goodrevisions as $k=>$v)
		{
			foreach($v['fields'] as $v)
			{
				$ts[$v]['field'] = $v;
			}	
		}
		if (is_array($ts))
			ksort($ts);
		$goodrevisions = $ts;
		
	}
	
	
	if ($mode=="query")
	{
		
		//echo "<p>";
		//print_r($goodrevisions);
		// flaten tuples
		$set = array();
		foreach($goodrevisions as $r)
		{
			$rowcount = 0;
			
			// we use fields from select statement here to enforce that every row has all fields
			
			foreach($fields as $key)
			{
				if (isset($r[$key]))
					$v = $r[$key];
				else
					$v = array();
				foreach($v as $rev=>$oneval)
				{
					$set[$rev][$key] = $oneval;
				}
			}
		}
		$goodrevisions = $set;
	
	
	}
	
	
	return $goodrevisions;
			
	
}



?>