<?php

if (!defined("SOFAWIKI")) die("invalid acces");

$swParsedName = "".swSystemMessage("Search",$lang).": $query";

$ns = join(" ",$swSearchNamespaces);

$revisions = swQuery($query,$ns);

$searchtexts = array();

$record = new swWiki;

foreach ($revisions as $k=>$v)
{
	$record->revision = $k;
	$record->lookup();
	
	if (($record->status=="ok" or $record->status=="protected") && $user->hasright("view", $record->name))
	{
		
		
		$t = "";
		$qs = swQuerySplit($query);
		if (stristr($record->content,$qs[0]))
		{
			
			$pos = stripos($record->content, $qs[0]);
			$pos = max(0,$pos-80);
			if ($pos>0)
				$pos = stripos($record->content, " ", $pos);
			
			$pos2 = stripos($record->content, " ", min(strlen($record->content),$pos+160));
			
			if ($pos2===NULL || $pos2=="")
			{
				$record->content = substr($record->content,$pos); 
			}
			else
			{
				$record->content = substr($record->content,$pos,$pos2-$pos);  
			}
			$record->parsers = array();
			$record->parsers["nowiki"] = new swNoWikiParser;
			$t = $record->parse();
			
			
			foreach ($qs as $q)
				$t = swStrReplace($q,"<span class='found'>$q</span>",$t);
			
		}
		
		$searchtexts[] = "<li><a href='".$record->link("")."'>$record->name</a>
		<br/>$t</li>";
	}
}

$swParsedContent = "<ul>".join("\n",$searchtexts)."</ul>";

?>