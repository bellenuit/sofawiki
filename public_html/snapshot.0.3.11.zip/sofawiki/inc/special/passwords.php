<?php

if (!defined("SOFAWIKI")) die("invalid acces");

$swParsedName = "Special:Passwords";


if (array_key_exists("mypass", $_POST)) 
	$mypass = $_POST['mypass'];
else
	$mypass="";
if (array_key_exists("myname", $_POST)) 
	$myname = $_POST['myname'];
else
	$myname="";
if (array_key_exists("myemail", $_POST)) 
	$myemail = $_POST['myemail'];
else
	$myemail="";
if (array_key_exists("myusertemplate", $_POST)) 
	$myusertemplate = $_POST['myusertemplate'];
else
	$myusertemplate="";


$swParsedContent = "<p>Password Encryptor
<div id='editzone'>";
		


	$swParsedContent .= "<form method='post' action='index.php?name=Special:Passwords'>
		<p>Username <input type='text' name='myname' value='$myname' />
		Password <input type='text' name='mypass' value='$mypass' />
		Email <input type='text' name='myemail' value='$myemail' />
		User Template <input type='text' name='myusertemplate' value='$myusertemplate' />
		<input type='Submit' name='submitencrypt' value='Encrypt' /></p>
</form>";

if ($mypass != "")
{
	$myuser = new swUser;
	$myuser->pass=$mypass;
	$myuser->username=$myname;
	$passencrypted = $myuser->encryptpassword();
	
	$userwiki = new swWiki;
	$userwiki->name = "User:$myname";
	try {
		$userwiki->lookup();
	} catch(exception $e) {
		
	}
	
	if ($myusertemplate != "")
	{
		$otheruser = new swWiki;
		$otheruser->name = "User:$myusertemplate";
		try {
		$otheruser->lookup();
	} catch(exception $e) {
		
	}
		$otherusercontent = $otheruser->content;
		$otherusercontent = preg_replace("/\[\[\_pass\:\:(.*)\]\]/","",$otherusercontent);
		$otherusercontent = preg_replace("/\[\[email\:\:(.*)\]\]/","",$otherusercontent);
		if ($myemail != "")
		{
			$otherusercontent .= "\n[[email::$myemail]]";
		}
	
	}
	
	switch ($userwiki->status)
	
	{
		case "ok":
		case "protected":
	
			$swParsedContent .= "<p><a href='index.php?name=User:$myname'>User:$myname</a></p><p>$mypass </p><p>[[_pass::$passencrypted]]</p>";
			break;
			
		default : $swParsedContent .=  "Create user $myname with pass $mypass<form method='post' action='index.php'>
		<input type ='Hidden' name='action' value='preview'>
		<input type='text' name='name' value=\"$userwiki->name\" />
		<br><textarea name='content' rows='10' cols='80' style='width:95%'>[[_pass::$passencrypted]]
$otherusercontent</textarea>
		<input type='Submit' name='submitpreview' value='Preview' /></p>
</form>";
	}
	
}

$swParsedContent .= "</div>";

$swParseSpecial = false;



?>