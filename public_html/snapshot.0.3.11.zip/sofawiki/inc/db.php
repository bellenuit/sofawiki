<?php

/*
SOFA DB
- document oriented database inspired from couchdb but using semantic metawiki syntax
- the database has no tables and no predefined fields.
- fields are declared inline using the semantic mediawiki syntax [[fieldname::value]]
  fieldnames cannot start with an underscore
- multiple occurences of the same field are allowed
- the records are self-contained
- the records are stored as revisioned files adding a header with the reserved fields 
  _id automatically generated integer
  _revision automatically generated integer
  _name the wiki name, can change over time
  _timestamp sever time
  _status ok, request, protected, deleted
- the filename is the revision. the written files are never changed afterwards.
- on insertion of a new revision, the database writes some indexes. 
  these indexes are for performance only, they can be rebuild whenever needed from scratch
  - index to find the most recent ok revision of an id (or discard it if there is a more recent delete)
  - index for each field
  - fulltext index wordbased on each field
- queries can be done
  - individually return a sdRecord by id, by revision or by name
  - return a list of all revisions of an id
  - return a list of all revisions (or only current ids) that are conform to a filter
    filter use regex and are applied on all revisions.
    the filter results are saved, so that the next time only new revisions have to be applied for the same filter
    - filename as md5 of request
    - fields _query, _maxrevision, _timestamp
    
REQUIREMENTS
- php needs write access to the folders parsers, queries and revisions
 
*/


if (!defined("SOFAWIKI")) die("invalid acces");



class swDB
{
	
	
	private $revisions = array();  // revision=>name
	private $names = array();  // name=>revision (last with ok or protected or deleted)
	private $statuses = array();  // name=>status
	private $proposals = array();  // revision=>name (only newer than revision in names)
	private $deletions = array();  // revision=>name (only newer than revision in names)
	public $salt;
	public $hasindex = false;
	
	
	function init()
	{
		global $swRoot;
		
		if (! file_exists("$swRoot/site/indexes/state.txt") || ! file_exists("$swRoot/site/indexes/revisions.txt")) $this->RebuildIndexes();	
		if (!file_exists("$swRoot/site/indexes/state.txt")) throw new Exception('Init missing state.txt file');
		if (!file_exists("$swRoot/site/indexes/revisions.txt")) throw new Exception('Init missing revisions.txt file');
		if (!$this->hasindex)
			$this->readIndex();
		
	}
	
	function readIndex()
	{
		global $swRoot;
		$this->hasindex = false;
		
		$s = file_get_contents("$swRoot/site/indexes/revisions.txt"); 
		$list = split("\n",$s);
		
		$this->revisions = array();
		$this->names = array();
		$this->statuses = array();
		$this->proposals = array();
		$this->deletions = array();
		
		foreach ($list as $listitem)
		{
			$name = swGetValue($listitem, "_name");
			$revision = swGetValue($listitem, "_revision");
			$status = swGetValue($listitem, "_status");
			if ($name && $revision && $status)
			{
				$this->revisions[$revision] = $name;
				if ($status == "ok" || $status == "protected")
				{
					$this->names[$name] = $revision;
					$this->statuses[$name] = $status;
					// overwrite old proposals and deletions
					foreach($this->proposals as $k=>$v)
					{
						if ($v==$name) unset($this->proposals[$k]);
					}
					foreach($this->deletions as $k=>$v)
					{
						if ($v==$name) unset($this->deletions[$k]);
					}
					
				}
				if ($status == "proposed")
				{
					$this->proposals[$revision] = $name;
				}
				if ($status == "deleted")
				{
					$this->deletions[$revision] = $name;
					unset($this->names[$name]);
				}
			}
		}
		$this->hasindex = true;
	
	}
	
	function UpdateIndexes($record)
	{
		$lastrevision = $record->revision;
		$timestamp = date("Y-m-d H:i:s",time());
		$file = "site/indexes/state.txt";
		$t = "[[_lastrevision::$lastrevision]]"
		. "\n[[_timestamp::$timestamp]]";
		if ($handle = fopen($file, 'w')) { fwrite($handle, $t); fclose($handle); }
		else { throw new Exception('Write error revision $this->revision');}
		
		$file = "site/indexes/revisions.txt";
		$t = "\n[[_revision::$record->revision]][[_status::$record->status]][[_name::$record->name]]";
		if ($handle = fopen($file, 'a+')) { fwrite($handle, $t); fclose($handle); }
		else { throw new Exception('Write error UpdateIndexes revisions.txt');}
	}
	
	function RebuildIndexes()
	{
		global $swRoot;
		$files = glob("$swRoot/site/revisions/*.txt");
		$r = new swRecord;
		$lastid = "0";
		$lastrevision= "0";
		$timestamp = date("Y-m-d H:i:s",time());
		$fileinfos = array();
		
		foreach($files as $file)
		{
			$r->revision = str_replace(".txt","",$file);
			$r->revision = str_replace("$swRoot/site/revisions/","",$r->revision);
			$r->db = $this;
			$r->lookup(true);
			$lastrevision = max($lastrevision,$r->revision);
			$fileinfos["$r->timestamp $r->revision"] = "[[_revision::$r->revision]][[_status::$r->status]][[_name::".swNameURL($r->name)."]]";
		}
		ksort($fileinfos);
	
		$file = "$swRoot/site/indexes/state.txt";
		$t = "[[_lastrevision::$lastrevision]]"
		. "\n[[_timestamp::$timestamp]]";
		if ($handle = fopen($file, 'w')) { fwrite($handle, $t); fclose($handle); }
		else { throw new Exception('Write error RebuildIndexes state.txt');}
		
		$file = "$swRoot/site/indexes/revisions.txt";
		$t = join("\n",$fileinfos);
		if ($handle = fopen($file, 'w')) { fwrite($handle, $t); fclose($handle); }
		else { throw new Exception('Write error RebuildIndexes revisions.txt');}
	}
	
		
	function GetAllNames()
	{
		$this->init();
		return $this->names;
	}
	
	function GetAllProposals()
	{
		$this->init();
		return $this->proposals;
	}
	function GetAllDeletions()
	{
		$this->init();
		return $this->deletions;
	}
	
	function GetAllRevisions()
	{
		$this->init();
		return $this->revisions;
	}

	function GetAllStatuses()
	{
		$this->init();
		return $this->statuses;
	}
	
}


function swGetLastRevision()
{ 
	global $swRoot;
	$s = file_get_contents("$swRoot/site/indexes/state.txt");
	return swGetValue($s,"_lastrevision");
}


function swGetAllRevisionsFromName($name)
{
	global $db;
	$db->init();
	$name = swNameURL($name);
	$list = array();
	$names = $db->GetAllRevisions();
	foreach ($names as $k=>$v)
	{
		if ( swNameURL($v) ==  $name) $list[] = $k;
	}
	return $list;
}

function swGetCurrentRevisionFromName($name)
{
	global $db;
	$db->init();
	$name = swNameURL($name);
	$list = $db->GetAllNames();
	foreach ($list as $k=>$v)
	{
		if ( swNameURL($k) ==  $name) return $v;
	}
}

function swGetPath($revision)
{
		global $swRoot;
		return "$swRoot/site/revisions/$revision".".txt";
}

function swQuery($filter,$namespace)
{
	// split set in words and filter for each one, then combine them
	
	$filterlist = swQuerySplit($filter);  // will have to be more sophisticated to allow for spaces within [[field::value]]
	$revisionlists = array();
	foreach ($filterlist as $f)
	{
		$rev = swFilter($f,$namespace);
		$revisionlists[] = $rev;
	}
	
	$c = count($revisionlists);
	$rev0 = $revisionlists[0];
	if ($c==1) return $rev0;
	for ($i=1;$i<$c;$i++)
	{
		$rev1 = $revisionlists[$i];
		foreach($rev0 as $k=>$v)
		{
			if (array_key_exists($k, $rev1))
				$rev0[$k] *= $rev1[$k];
			else
				unset($rev0[$k]);
		}
	}
	return $rev0;
}

function swFilter($filter,$namespace,$regex=false)
{
	global $swRoot;
	global $db;
	$goodrevisions = array();
	$db->init();
	
	// find already searched revisions
	$lastfoundrevision = 0;
	$mdfilter = $filter;
	if ($regex) $mdfilter .= "regex";
	$cachefile = "$swRoot/site/queries/".md5($mdfilter).".txt";
	
	
	if (file_exists($cachefile) && !$regex)
	{
		$s = file_get_contents($cachefile);
		$lastfoundrevision = swGetValue($s, "_lastrevision");
		$list = split("\n",$s);
	
		$goodrevisions = array();
	
		foreach ($list as $listitem)
		{
			$revision = swGetValue($listitem, "_revision");
			$rating = swGetValue($listitem, "_rating");
			$goodrevisions["$revision"] = $rating;
		}
	}
	
	// apply filter to new revisions of currently used names
	$revisions = $db->GetAllNames();
	
	foreach($revisions as $r)
	{
		
		if ($r <= $lastfoundrevision) continue;
		$record = new swRecord;
		$record->revision = $r;
		$record->lookup();
		
		$content = $record->name." ".$record->content;
		
		if ($regex)
		{
			$matches = array();
			$offset = 0;
			$rating = 0;
			
			while (preg_match($filter, $content, $matches, PREG_OFFSET_CAPTURE, $offset))
			{
				/*echo "<p>filter $filter<pre>";
				print_r($matches);
				echo "</pre>";*/
				
				if (is_array($matches[1]))
					$m = $matches[0][1];
					
				else
					$m = $matches[1];
				
				$rating += 1 - ($m / (strlen($content)- $offset) );
				$offset += $m+1;
				$goodrevisions[$r] = sprintf("%09.3f",$rating);
			}
			
		}
		else
		{
			if (stristr($content,$filter))
			{
				//simple rating algorithm: 
				//counts the number of occurences and the position
				
				$rating = 0;
				$len0 = strlen($content);
				while ($content = stristr($content,$filter))
				{
					$rating += strlen($content) / $len0;
					$content = substr($content,1);
				}
				$goodrevisions[$r] = sprintf("%09.3f",$rating);
			}
		}
	}
	
	
	$lastrevision = swGetLastRevision();
	
	// save to cache
	$lines = array();
	foreach($goodrevisions as $k=>$v)
	{
		$lines[] = "[[_revision::$k]][[_rating::$v]]";
	}
	$query2 = urlencode($filter);
	$t = "[[_query::$query2]][[_lastrevision::$lastrevision]]\n".
	join("\n",$lines);
	if ($handle = fopen($cachefile, 'w')) { fwrite($handle, $t); fclose($handle); }
	else { throw new Exception('Write error Query cache');}
	
	
	// now we have a list of good revisions.
	// we have to return only the last revision of each name
	$validrevisions = array_flip($db->GetAllNames());
	$record = new swRecord;
	
	foreach($goodrevisions as $k=>$v)
	{
		if (!array_key_exists($k,$validrevisions))
			unset($goodrevisions[$k]);
		else
			// check for namespace
		{
			$record->name = $validrevisions[$k];
			$ns = $record->wikinamespace();
			if ($ns == "" || stristr($namespace." ",$ns." "))
			{
				// ok
			}
			else
				unset($goodrevisions[$k]);
		}
	}
	arsort($goodrevisions);
	
	return $goodrevisions;
			
	
}



?>