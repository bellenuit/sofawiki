<?php

if (!defined("SOFAWIKI")) die("invalid acces");

$swParsedName = "Snapshot";
$swParsedContent = swSnapshot($user->name);


?>