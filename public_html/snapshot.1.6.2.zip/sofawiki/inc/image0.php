<?php

if (!defined('SOFAWIKI')) die('invalid acces');


// STUB

function swImageDownscale($name, $destw, $desth=0)
{
    return false;
}




?>