<?php

if (!defined("SOFAWIKI")) die("invalid acces");

class swLinksParser extends swParser
{
	function info()
	{
	 	return "Handles internal and external links";
	}

	function dowork($wiki)
	{
		$s = $wiki->parsedContent;
		
		
		 // must start with whitespace
		  $s = " ".$s;

		 // external links without markup must not start with [
		 $s = preg_replace('@[^[](https?://[-A-Za-z0-9.?&=%/+;:#_]+)@', ' <a href="$1" target="_blank">$1</a>', $s);
		 
		 // external links with markup
		 $s = preg_replace('@\[(https?://[-A-Za-z0-9.?&=%/+;#_]+)\]@', ' <a href="$1" target="_blank">$1</a>', $s);

		 // external links with markup and alternate text
		 $s = preg_replace('@\[(https?://[-A-Za-z0-9.?&=%/+;#_]+) (.*?)\]@', ' <a href="$1" target="_blank">$2</a>', $s);

		 // mail links without markup must have space before
		  $s = preg_replace('/\s([-a-zA-Z0-9_.]+@[-a-zA-Z0-9_.]+)/', ' <a href="mailto:$1" target="_blank">$1</a>', $s);
		 
		 // mail links with markup
		 $s = preg_replace('/\[mailto:([-a-zA-Z0-9_.]+@[-a-zA-Z0-9_.]+)\]/', ' <a href="mailto:$1" target="_blank">$1</a>', $s);

		 // mail links with markup and alternate text
		  $s = preg_replace('/\[mailto:([-a-zA-Z0-9_.]+@[-a-zA-Z0-9_.]+) (.*?)\]/', ' <a href="mailto:$1" target="_blank">$2</a>', $s);


 		 $s = substr($s,1);	

		// internal links
		preg_match_all("@\[\[([^\]\|]*)([\|]?)(.*?)\]\]@", $s, $matches, PREG_SET_ORDER);
		
		$categories = array();
		
		foreach ($matches as $v)
		{
			
			$val = $v[1]; // link
			
			if ($v[2] == "|") // pipe
			{
				if ($v[3] != "")
					$label = $v[3];
				else
				{	// pipe trick
					$label = preg_replace("@(.*):+(.*)@", "$2", $val);  // remove namespace
					$label = preg_replace("@(.*)\(+(.*)@", "$1", $label); // remove label
				}
			}
			else
			{
				$label = $val;
				if (substr($label,0,1) == ":") $label = substr($label,1);
			}
			
			$val0 = $val;
			if (stristr($val,"::") && substr($val,0,1)=="_") continue; // internal variables
			if ($val2 = stristr($val,"::"))
			{ $val = substr($val2,2);  }
			$linkwiki = new swWiki();
			
			if (substr($val,0,8) == "Special:")
			{
				$linkwiki->name = $val;
				$s = str_replace($v[0], "<a href='".$linkwiki->link("")."'>$label</a>",$s);
			}
			elseif (substr($val,0,9) == "Category:")
			{
				
				$v2 = substr($val,9);
				$linkwiki->name = $val;
				try{
						$linkwiki->lookup(true);
					}
				catch(Exception $e)
				{  }
				if ($linkwiki->visible())
				{
						$v = "<a href='".$linkwiki->link("")."'>$v2</a>";
				}
				else
				{
						$v = "<a href='".$linkwiki->link("")."' class='invalid'>$v2</a>";
				}
				$categories[] = "<li>$v</li>";
				$s = str_replace("[[".$val."]]","",$s);
			}
			else
			{ 
				if (substr($val,0,10) == ":Category:") { $val = substr($val,1); }
				
				$languagefound = false;
				
				// catch interlanguage links
				global $swLanguages;
				foreach ($swLanguages as $l)
				{
					
					$test = substr($val,0,strlen($l)+1);
					// echo "lang $l $test";
					if ($test=="$l:")
					{
						// echo "lang";
						$val = substr($val,3);
						$wiki->interlanguageLinks[$l] = $val;
						$languagefound = true;
						global $swLangMenus, $lang;
						$w2 = new swWiki;
						$w2->name = $val;
						$swLangMenus[$l] = "<a href='".$w2->link("view")."&amp;lang=$l'>".swSystemMessage("$l",$lang)."</a>";

						
					}
					
				
				}
				if ($languagefound) 
				{
					$s = str_replace($v[0], "",$s);
					continue;
				}
				
				// add a hook here for custom handler
				
				if (function_exists('swInternalLinkHook')) {
  					$hooklink = swInternalLinkHook($val,$label);
  					if ($hooklink)
  					{
  						$s = str_replace($v[0], $hooklink,$s);
  						continue;
  					}
				}
				
				
				
				$revision = swGetCurrentRevisionFromName($val);
				if ($revision)
				{
					// now check if not deleted
					$linkwiki->revision = $revision;
					try{
						$linkwiki->lookup(true);
					}
					catch(Exception $e)
					{  }
					if ($linkwiki->visible())
					{
						$s = str_replace($v[0], "<a href='".$linkwiki->link("")."'>$label</a>",$s);
					}
					else
					{
						$s = str_replace($v[0], "<a href='".$linkwiki->link("")."' class='invalid'>$label</a>",$s);
					}
				
				}
				else
				{
					$linkwiki = new swWiki();
					$linkwiki->name = $val;
					
					$s = str_replace($v[0], "<a href='".$linkwiki->link("")."' class='invalid'>$label</a>",$s);
				}
				
				$wiki->internalLinks[] = $val0;
			}
		}

		if (count($categories) > 0)
		{
			$s .= "\n\n<div id='categories'>\n<ul>".join(" ",$categories)."\n</ul>\n</div>";
		}
		

		$wiki->parsedContent = $s;
		
		
	}

}

$swParsers["links"] = new swLinksParser;


?>