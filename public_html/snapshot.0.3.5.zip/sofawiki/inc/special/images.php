<?php

if (!defined("SOFAWIKI")) die("invalid acces");

$swParsedName = "Special:Images";

$names = $db->GetAllNames();
uksort($names, 'strnatcasecmp');   
$swParsedContent = "";
$oldfirst = "";

foreach ($names as $n=>$s)
{
	
	if (substr($n,0,6)=="Image:")
	{
		$n = substr($n,6);
		$first = strtolower(substr($n,0,1));
		if ($oldfirst && $oldfirst != $first) $swParsedContent .= "\n\n";
		$swParsedContent .= "[[:Image:$n|$n]] ";
		$oldfirst = $first;
 	}
}

$swParseSpecial = true;



?>