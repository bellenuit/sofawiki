<?php

define("SOFAWIKI",true);  // all included files will check for this variable
$swError = "";
$swVersion = "0.4.8";
$swMainName = "Main";

/*
	include files
	all files included from here and from site/configuration.php
*/

$swRoot = dirname(__FILE__);

// core
if (defined("SOFAWIKIINDEX"))
	include_once "$swRoot/inc/cookies.php"; // 0.3.2 moved to index.php
	
	
	
include_once "$swRoot/inc/cron.php";
include_once "$swRoot/inc/db.php";
include_once "$swRoot/inc/function.php";
include_once "$swRoot/inc/legacy.php";

include_once "$swRoot/inc/notify.php";
include_once "$swRoot/inc/parser.php";
include_once "$swRoot/inc/record.php";
include_once "$swRoot/inc/user.php";
include_once "$swRoot/inc/utilities.php";
include_once "$swRoot/inc/wiki.php";
// external code
include_once "$swRoot/inc/diff.php";
include_once "$swRoot/inc/pdf.php";
include_once "$swRoot/inc/zip.php";

// functions
$swFunctions = array();
include_once "$swRoot/inc/functions/substr.php";
include_once "$swRoot/inc/functions/info.php";
include_once "$swRoot/inc/functions/value.php";

// parsers
$swParsers = array();
include_once "$swRoot/inc/parsers/redirection.php";
include_once "$swRoot/inc/parsers/lang.php";
include_once "$swRoot/inc/parsers/tidy.php";
include_once "$swRoot/inc/parsers/templates.php";
include_once "$swRoot/inc/parsers/category.php";
include_once "$swRoot/inc/parsers/images.php";
include_once "$swRoot/inc/parsers/links.php";
include_once "$swRoot/inc/parsers/style.php";

// search only
include_once "$swRoot/inc/parsers/nowiki.php";

// system defaults localization
$swSystemDefaults = array();
include "$swRoot/inc/system-defaults-en.php";
include "$swRoot/inc/system-defaults-fr.php";
include "$swRoot/inc/system-defaults-de.php";
include "$swRoot/inc/system-defaults-es.php";
include "$swRoot/inc/system-defaults-da.php";

// special pages
$swSpecials["All Pages"] = "allpages.php";
$swSpecials["Recent Changes"] = "recentchanges.php";
$swSpecials["Proposed Changes"] = "proposedchanges.php";
$swSpecials["Protected Pages"] = "protectedpages.php";
$swSpecials["Deleted Pages"] = "deletedpages.php";
$swSpecials["Categories"] = "categories.php";
$swSpecials["Images"] = "images.php";
$swSpecials["Upload"] = "upload.php";
$swSpecials["Upload Multiple"] = "uploadmultiple.php";
// does not work $swSpecials["Index PDF"] = "indexpdf.php";
$swSpecials["Templates"] = "templates.php";
$swSpecials["Users"] = "users.php";
$swSpecials["Passwords"] = "passwords.php";
$swSpecials["Mail"] = "mail.php";
$swSpecials["System Messages"] = "systemmessages.php";
$swSpecials["Info"] = "info.php";
$swSpecials["Special Pages"] = "specialpages.php";
$swSpecials["Snapshot"] = "snapshot.php";
$swSpecials["Backup"] = "backup.php";
$swSpecials["Regex"] = "regex.php";
$swSpecials["Logs"] = "logs.php";
$swSpecials["Update"] = "update.php";

/*
	initialize variables
*/

$swLanguages = array();

$swTranscludeNamespaces = array();
$swTranscludeNamespaces[] = "";
$swTranscludeNamespaces[] = "Template";
$swTranscludeNamespaces[] = "System";

$swSearchNamespaces = array();
$swSearchNamespaces[] = "";

$swNewUserFormFields = array();
$swAllUserRights = "[[_view::Main]] ";
$swNewUserRights = "[[_view::Main]] ";
$swNewUserEnable = true;
$swMaxNewTalkLength  = 0;
$swNotifyMail = "";
$swNotifyActions = array();

$swSkins["default"] = "$swRoot/inc/skins/default.php";
$swSkins["tribune"] = "$swRoot/inc/skins/tribune.php";
$swSkins["iphone"] = "$swRoot/inc/skins/iphone.php";
$swSkins["tele"] = "$swRoot/inc/skins/tele.php";
$swSkins["zeitung"] = "$swRoot/inc/skins/zeitung.php";
$swDefaultSkin = "default";

$swDefaultLang = "en";

$db = new swDB;
$db->init();



if (file_exists("$swRoot/site/configuration.php"))
	include_once "$swRoot/site/configuration.php";
else
	include_once "$swRoot/inc/configuration-install.php";
	
	
// code depending on configuration
if ($swImageScaler)
	include_once "$swRoot/inc/image.php";
else
	include_once "$swRoot/inc/image0.php";
if ($swTwitterUser)
	$swSpecials["Twitter"] = "twitter.php";

$db->salt = $swEncryptionSalt;


// public functions

function swMessage($msg,$lang)
{
	// wrapper as shortcut
	$lang = substr($lang,0,2); // cut off
	$t = new swTemplateParser;
	$ts = new swStyleParser;
	$tl = new swLinksParser;
	$w = new swWiki;
	if ($lang)
		$w->parsedContent = "{{:".$msg."/$lang}}";
	else
		$w->parsedContent = "{{:".$msg."}}";
	$t->dowork($w);
	$ts->dowork($w); $tl->dowork($w);
	$s = $w->parsedContent;
	if ($msg != $s)
		return $s;
	$w->parsedContent = "{{:$msg}}";
	$t->dowork($w);
	if ($styled) { $ts->dowork($w); $tl->dowork($w); }
	$t = $w->parsedContent;
	if ($t != "") return $t;
	
	
}


function swSystemMessage($msg,$lang,$styled=false)
{
	// wrapper as shortcut
	
	$lang = substr($lang,0,2); // cut off
	$t = new swTemplateParser;
	$ts = new swStyleParser;
	$tl = new swLinksParser;
	$w = new swWiki;
	if ($lang)
		$w->parsedContent = "{{System:".$msg."/$lang}}";
	else
		$w->parsedContent = "{{System:".$msg."/en}}";
	$t->dowork($w);
	if ($styled) { $ts->dowork($w); $tl->dowork($w); }
	$s = $w->parsedContent;
	
	
	if ($msg != $s)
		return $s;
	$w->parsedContent = "{{System:$msg}}";
	$t->dowork($w);
	if ($styled) { $ts->dowork($w); $tl->dowork($w); }
	$t = $w->parsedContent;
	
	
	
	if ($t != "") return $t;
	return $msg;
}




?>