<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title><?php echo $swParsedName ?></title>
<link rel='stylesheet' href="inc/skins/default.css"/>
</head>
<body>

<div id='search'>
<?php 
echo $swSearchMenu; 
?>
</div>


<div id='menu'>
<?php 

echo "<span class='error'>$swError</span>\r\n";
echo $swHomeMenu. "<br/>"; 
foreach($swEditMenus as $item) {echo $item." <br/>"; }
echo "<br/>";
// foreach($swHistoryMenus as $item) {echo $item." \r\n" ; }

foreach($swLangMenus as $item) {echo $item." <br/>" ; }
echo "<br/>";
foreach($swLoginMenus as $item) {echo $item." <br/>" ; }


 ?>
</div>


<div id='title'>

<h1><?php echo "$swParsedName" ?></h1>

</div><!-- title -->

<div id='content'><?php echo "

$swParsedContent
" ?>

<div id="info">
<?php echo "$swFooter" ?>
</div>

</div><!-- content -->



</body>
</html>