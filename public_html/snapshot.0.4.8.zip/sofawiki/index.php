<?php

/*
	SofaWiki
	Matthias Buercher 2010 
	matti@belle-nuit.com
	
	index.php 
	main entry point
*/

define("SOFAWIKIINDEX",true);
$starttime = microtime();

include "api.php";



// get valid globals

// general
if (array_key_exists("name", $_REQUEST)) 
	$name = $_REQUEST["name"];	
else
	$name = $swMainName;
if (array_key_exists("name2", $_REQUEST)) 
	$name2 = $_REQUEST["name2"];
else
	$name2 = $name;
if (array_key_exists("action", $_REQUEST)) 
	$action = $_REQUEST["action"];
else
	$action = "";
if (array_key_exists("query", $_REQUEST))
	$query = $_REQUEST["query"];
else
	$query = "";
if (array_key_exists("content", $_REQUEST))
	$content = $_REQUEST["content"];
else
	$content = "";
if (array_key_exists("comment", $_REQUEST))
	$comment = $_REQUEST["comment"];
else
	$comment = "";
	

$name = str_replace("\\","",$name);	
$name2 = str_replace("\\","",$name2);	
$comment = 	str_replace("\\","",$comment);

$history = addHistory($name);
foreach($history as $v)
{
	if ($v != $name)
		$swHistoryMenus[] = "<a href='index.php?name=$v'>$v</a>";
	else
		$swHistoryMenus[] = "$v";
	
		
}

$ip = $_SERVER["REMOTE_ADDR"];
$referer =  $_SERVER["HTTP_REFERER"];

// use only server referer
$referer = preg_replace("$\w*://([^/]*)/(.*)$","$1",$referer);
	
// editing
if (array_key_exists("id", $_REQUEST))  $id = $_REQUEST["id"];   //obsolete??
if (array_key_exists("revision", $_REQUEST))  $revision = $_REQUEST["revision"]; else $revision=0;
if (array_key_exists("content", $_REQUEST)) $content = $_REQUEST["content"];

// submits overrides action
if (array_key_exists("submitmodify", $_REQUEST))
	$action = "modify";
if (array_key_exists("submitmodifymulti", $_REQUEST))
	$action = "modifymulti";
if (array_key_exists("submitpropose", $_REQUEST))
	$action = "propose";
if (array_key_exists("submitproposemulti", $_REQUEST))
	$action = "proposemulti";
if (array_key_exists("submitpreview", $_REQUEST))
	$action = "preview";
	

// fix trailing and leading spaces
$name = trim($name);
$name2 = trim($name2);

//verify
session_start();


// create user
$username = "";
if ($action == "logout")  unset($_SESSION[$swMainName."-username"]);
if(isset($_SESSION[$swMainName."-username"])&& $_SESSION[$swMainName."-username"] != "")
{
        $username = $_SESSION[$swMainName."-username"];
        if ($username == $poweruser->username)
		{
			$user = $poweruser;
			$user->name = "User:$username";
		}
		else
		{
			$user = new swUser;
			$user->username = "$username";
			$user->name = "User:$username";
			$user->lookup();

		}
}
else
{
	if (array_key_exists("username", $_POST)) 
		$username = $_POST["username"];
	if (array_key_exists("username", $_GET)) 
		$username = $_GET["username"];
		
	if (array_key_exists("pass", $_REQUEST)) 
		$pass = $_REQUEST["pass"];
	else 
		$pass = "";
		
	if ($username == $poweruser->username)
	{
		$user = $poweruser;
		$user->pass = $pass;	
	}
	else
	{
		$user = new swUser;
		$user->username = $username;
		$user->name = "User:$username";
		$user->pass = $pass;
		$user->lookup();
	}
	$user->name = "User:$username";
		
	if ($user->validpassword())
	{
		$_SESSION[$swMainName."-username"] = $username;
		$action="view";
	}
    else
    {
		if ($username != "")
		{
			$swError = swSystemMessage("WrongPasswordError",$lang);
			$action = "login";
		}
		$user = new swUser;
		$user->name = "";
		$user->pass = "";
		$user->content = $swAllUserRights;
		
    }
}
if ($action == "logout")
{
	$user = new swUser;
	$user->name = "";
	$user->pass = "";
	$user->content = $swAllUserRights;
}


// create wiki
$wiki = new swWiki;
$wiki->name = $name;
$wiki->comment = $comment;
$wiki->parsers = $swParsers;
$swRedirectedFrom = "";

if (substr($name,0,8) == "Special:" && $action != "login")
{
	$action = "special";
}
elseif ($action != "new")
{
	
	if ($revision) 
	{
		// we will only allow this if user has right to view the history
		
		if ($user->hasright("modify", $wiki->wikinamespace()) || $user->hasright("propose", $wiki->wikinamespace()) |
		$user->hasright("protect", $wiki->wikinamespace()) || $user->hasright("delete", $wiki->wikinamespace())) 
		{
			$wiki->revision=$revision;
		}
		else
		{
			$swError = swSystemMessage("NoAccessError",$lang);
			$swFooter = "";
		}
	}
	

	$wiki->lookup();
	
	

	if ($wiki->error != "")
	{
		switch ($wiki->error)
		{ 
			case "No record with this name": 
				if ($action != "modify" && $action != "propose" && $action != "modifymulti" && $action != "proposemulti") 
				{
					if (!$wiki->istalk() && $action !="preview")  // this is not a talk namespace
						$swError ="$action ".swSystemMessage("ThisPageDoesNotExistError",$lang); 
					else
					{
						// ok
					}
				}
				break;		
			case "Deleted record": $swError = swSystemMessage("ThisPageHasBeenDeletedError",$lang); break;
			default:
			$swError = "Exception: ".$wiki->error;
		}
	}
}

if ($revision && $name == $swMainName) $name = $wiki->name;

$swParsedName = "";
$swParsedContent = "";
$swFooter = "";


// create menus
$swHomeMenu = "<a href='index.php'>".swSystemMessage("Home",$lang)."</a>";

$swLangMenus = array();
foreach ($swLanguages as $v)
{
	if ($v==$lang) 
		$swLangMenus[$v] = swSystemMessage("$v",$lang);
	else
		$swLangMenus[$v] = "<a href='".$wiki->link("view","--")."&amp;lang=$v'>".swSystemMessage("$v",$lang)."</a>";
}
unset($v);

$swSearchMenu = " <form method='get' action='index.php'><p>
 <input type='hidden' name='action' value='search' />
 <input type='text' name='query' value='$query' />
 <input type='submit' name='submit' value='".swSystemMessage("Search",$lang)."' /> 
 </p></form> 
";

$swLoginMenus= array();
if ($user->username != "")
{
		$swLoginMenus['user'] = "".swSystemMessage("User",$lang).":".$user->nameshort();
		$swLoginMenus['logout'] = "<a href='index.php?action=logout' rel='nofollow'>".swSystemMessage("Logout",$lang)."</a>";
}
elseif ($action != "login")
{
	$swLoginMenus['login'] = "<a href='index.php?action=login&amp;name=$name' rel='nofollow'>".swSystemMessage("Login",$lang)."</a>";
}		

$swEditMenus = array();


// page based edit menus
if ($action != "special" && $action != "login" && $action != "logout" && $action!="search")
{
	// view
	if ($user->hasright("view", $wiki->name) || $user->hasright("talk", $wiki->simplename()) )
	{
		if ($wiki->istalk() || ($action != "view" && $action != ""))
			$swEditMenus['view'] = "<a href='".$wiki->articlelink("view")."' rel='nofollow'>".swSystemMessage("View",$lang)."</a>";
		else
			$swEditMenus['view'] = swSystemMessage("View",$lang);
	}
	
	// talk
	if ($user->hasright("talk", $wiki->simplename()) || $user->hasright("view", $wiki->talkname()) )
	{
		if ($wiki->istalk())
		$swEditMenus['talk'] = "".swSystemMessage("Talk",$lang)."";
		else
		{
			$count = $wiki->talkcount();
			if ($count == 0) $msg = swSystemMessage("ZeroTalk",$lang);
			if ($count == 1) $msg = swSystemMessage("OneTalk",$lang);
			if ($count > 1) $msg = $count." ".swSystemMessage("Talks",$lang);
			
			$swEditMenus['talk'] = "<a href='".$wiki->link("talk")."' rel='nofollow'>".$msg."</a>";
			unset($msg);
			unset($count);
		}
	}
	
	// edit
	if ($user->hasright("modify", $wiki->name) || $user->hasright("propose", $wiki->name) ||
	$user->hasright("protect", $wiki->name) || $user->hasright("delete", $wiki->name) || $action == "modifymulti" )
	{
	
		if ($wiki->status != "" && $wiki->status != "deleted" && $wiki->status != "delete") // page does exist // delete is obsolete
		{
			if ($action != "edit" )
				$swEditMenus['edit'] = "<a href='".$wiki->link("edit")."' rel='nofollow'>".swSystemMessage("Edit",$lang)."</a>";
			else
				$swEditMenus['edit'] = swSystemMessage("Edit",$lang);
			
			if (count($swLanguages)>1 && $wiki->status != "protected")
			{
				if ($action == "editmulti" )
					$swEditMenus['editmulti'] = swSystemMessage("Edit",$lang)." Multi";
				else
				{
					$swEditMenus['editmulti'] = "<a href='".$wiki->link("editmulti","")."' rel='nofollow'>".swSystemMessage("Edit",$lang)." Multi</a>";
				}
			}
		}
	}
	
	// further edit menus
	if ($action == "edit" || $action == "editmulti" || $action == "modifymulti" )
	{
		
		if ($name && $wiki->status != "" || $action == "editmulti" || $action == "modifymulti" )
		{
			
			foreach ($swLanguages as $v)
			{
				$swEditMenus["edit$v"] = "<a href='".$wiki->link("edit",$v)."' rel='nofollow'>".swSystemMessage("Edit",$lang)." $v</a>";
			}
			unset($v);
		}
		
	}
	
	// history
	
	
	if ($user->hasright("modify", $wiki->name) || $user->hasright("propose", $wiki->name) ||
	$user->hasright("protect", $wiki->name) || $user->hasright("delete", $wiki->name) )
	{
		if ($wiki->status=="deleted" || $wiki->status=="delete") 
		{
			if ($user->hasright("delete", $wiki->name))
				$swEditMenus['history'] = "<a href='".$wiki->link("history")."' rel='nofollow'>".swSystemMessage("History",$lang)."</a>";
		}
		elseif($wiki->status != "")
		{
			$swEditMenus['history'] = "<a href='".$wiki->link("history")."' rel='nofollow'>".swSystemMessage("History",$lang)."</a>";
		}
		
	}
	
	
}

// global edit menus
if ($user->hasright("create", $wiki->name) || $user->hasright("propose", "?"))
{
	if($wiki->status != "")
		$swEditMenus['new'] = "<a href='index.php?action=new' rel='nofollow'>".swSystemMessage("New",$lang)."</a>";
	elseif ($action != "special")
		$swEditMenus['new'] = "<a href='".$wiki->link("edit")."' rel='nofollow'>".swSystemMessage("New",$lang)."</a>";
}


if ($user->hasright("special","special") && $action != "logout")
	$swEditMenus['special'] = "<a href='index.php?name=Special:Special_Pages' rel='nofollow'>".swSystemMessage("Special",$lang)."</a>";

if ($user->hasright("upload","") && $action != "logout")
	$swEditMenus['upload'] = "<a href='index.php?name=Special:Upload' rel='nofollow'>".swSystemMessage("Upload",$lang)."</a>";		

switch ($action)
{
	case "special":  	if ($user->hasright("special",str_replace("Special:","",$name)) || $user->hasright("special","special") ||
							($user->hasright("upload","") && $name=="Special:Upload" ) )
						{
							$specialname = substr($name,8);
							$swParseSpecial = false;
							$specialfound = false;
								foreach ($swSpecials as $k=>$v)
								{
									if (swNameURL($k) == $specialname)
									{
										include "inc/special/$swSpecials[$k]";
										$specialfound = true;
									}
								}
								unset($k);
								unset($v);
								if (!$specialfound)
									$swError = swSystemMessage("ThisPageDoesNotExistError",$lang); 
							if ($swParseSpecial)
							{
								$wiki->content = $swParsedContent;
								$swParsedContent = $wiki->parse();
							}
						}
						else
						{
							$swError = swSystemMessage("NoAccessError",$lang);
						}
						
						if ($user->hasright("create", $wiki->name) || $user->hasright("propose", "?"))
							$swEditMenus[] = "<a href='index.php?action=new'>".swSystemMessage("New",$lang)."</a>";


						break;
	case "login":    include_once "inc/special/login.php";
				 	 break;
	case "newuser":    include_once "inc/special/newuser.php";
				 	 break;
	case "newusersubmit":    include_once "inc/special/newuser.php";
				 	 break;

	case "lostpassword":    include_once "inc/special/lostpassword.php";
				 	 break;
	case "lostpasswordsubmit":    include_once "inc/special/lostpassword.php";
				 	 break;

	case "logout":   $swParsedName = "Logout";
					 $swParsedContent = swSystemMessage("You have logged out",$lang);
					 break;
	
	case "upload":   if ($user->hasright("upload", ""))
					 	include_once "inc/special/upload.php";
				 	 break;

	case "uploadfile":   if ($user->hasright("upload", ""))
					 	include_once "inc/special/uploadfile.php";
				 	 break;
	case "snapshot":   if ($user->hasright("upload", ""))
					 	include_once "inc/special/snapshot.php";
				 	 break;
	
	case "install": include_once "inc/special/install.php";
				 	 break;
	
	case "new":     $name="";$wiki->name = ""; // no break!
	case "edit":    
	case "editmulti": include_once "inc/special/edit.php";
				    break;
	case "newtalk":    
	case "newtalksubmit":    
					
					$submitted = false;
					
					$w = new swWiki;
					$w->name = $name;
					$w->name = $w->talkname();
					$w->lookup();

					
					
					if ($w->status=="protected")
					{	$swError = "no access"; break; }
					
					if ($action == "newtalksubmit")
					{
						// verify that all arguments are there
						if ( $content == "" )
							$swError = swSystemMessage("NewTalkEmpty",$lang);
						
						// verify that no field has a tag
						$s = $content;
							if (stristr($s,"<") || stristr($s,">")) 
							$swError = swSystemMessage("NewTalkInvalidCharactersError",$lang);
						
						// verify the the length
						if ($swMaxNewTalkLength>0)
						{
							$l = strlen($content);
							if ($l>$swMaxNewTalkLength)
								$swError = swSystemMessage("NewTalkTooLong",$lang). " ($l > $swMaxNewTalkLength)";
						}
							

						if (!$swError)
						{
							
							$timestamp = date("Y-m-d H:i:s",time());
							
							if ($w->content)
								$w->content = $content."\n''$username: $timestamp''\n----\n".$w->content;
							else
								$w->content = $content."\n''$username: $timestamp''";
								
							
							
							if ($action !="preview")
							{
								
								$w->insert();
							
								$label = $swMainName.":".swSystemMessage("YourTalkTitle",$lang);
								$message = swSystemMessage("NewTalkSubmit",$lang)."\n
								User=$user->name\n
								Content=$content\n";
							
								swNotify("newtalksubmit",$swError,$label,$message);
							
								$submitted = true;
							}
						
						}
						
					}

					include_once "inc/special/talk.php";
				    break;
						
	case "history":	 include_once "inc/special/history.php";
				     break;
	case "diff":	include_once "inc/special/diff.php";
				     break;

	case "preview":  if (!swValidate($name2,"\"\\<>[]{}*")) $swError = swSystemMessage("InvalidCharacters",$lang)." (name2)";
					 if (!swValidate($name,"\"\\<>[]{}*")) $swError = swSystemMessage("InvalidCharacters",$lang)." (name)";
					 $wiki->content = str_replace("\\","",$content);
					 $wiki->comment = str_replace("\\","",$comment);
					 include_once "inc/special/edit.php";
					 break;
	case "modify":	
	case "modifymulti":	
					if (!swValidate($name2,"\"\\<>[]{}*")) $swError = swSystemMessage("InvalidCharacters",$lang)." (name2)";
					if (!swValidate($name,"\"\\<>[]{}*")) $swError = swSystemMessage("InvalidCharacters",$lang)." (name)";
					if ($wiki->status == "" && ! $user->hasright("create", $wiki->name))
					{
						$swError = swSystemMessage("NoAccessError",$lang);
					}
					elseif ($user->hasright("modify", $wiki->name))
					{

							// validate globals
							
							if (!$_POST["submitmodify"]&&!$_POST["submitmodifymulti"])
							{
								$swError = swSystemMessage("NotModifyWithoutPost",$lang);
							}
							
							
							// check for editing conflict
							if ($revision > 0)
							{
								$r = swGetCurrentRevisionFromName("$name");
								if ($r <> $revision)
								{
									$swError = swSystemMessage("EditingConflict",$lang)." name: $name current: $r revision: $revision ";
									// set the old current content to the wiki
									$currentwiki =  new swWiki;
									$currentwiki->revision = $r;
									$currentwiki->lookup();
									
									
									$conflictwiki = new swWiki;
									$conflictwiki->content = $content;
									
									$revision = $r;
									
									
									include_once "inc/special/editconflict.php";
								}
							}
							
							
							if (!$swError)
							{
								$wiki->user = $user->name;
								$wiki->content = str_replace("\\","",$content);
								$wiki->comment = str_replace("\\","",$comment);
								$wiki->insert();

								$swParsedName = "Saved: $name";
								$swParsedContent = $wiki->parse();
							}
					}
					else
					{
						$swError = swSystemMessage("NoAccessError",$lang);
					}
				    break;
	case "propose":  if ($action=="preview")
					{
						$wiki->content = str_replace("\\","",$content);
						$wiki->comment = str_replace("\\","",$comment);
						include_once "inc/special/edit.php";
					}
					elseif ($user->hasright("propose", $wiki->name))
					{

							$swParsedContent = "<div id='help'>".swSystemMessage("ProposeThankYou",$lang)."</div>
							
							<p><pre>".htmldiff($wiki->content,$content)."</pre>";
							
							$wiki->user = $user->name;
							$wiki->content = str_replace("\\","",$content);
							$wiki->comment = str_replace("\\","",$comment);
							$wiki->propose();

							$swParsedName = "Proposed: $name";
							
							$label = $swMainName.":".$swParsedName;
							$message = swSystemMessage("Proposed Page",$lang)."\nUser=$username\nName=$name\n";
							swNotify("propose",$swError,$label,$message);

					}
					else
					{
						$swError = swSystemMessage("NoAccessError",$lang);
					}
	
						break;
	case "rename":
					if ($user->hasright("rename", $wiki->name))
					{
					 		$swEditMenus[] = "<a href='".$wiki->link("")."'>".swSystemMessage("View",$lang)."</a>";
							$swEditMenus[] = "<a href='".$wiki->link("edit")."'>".swSystemMessage("Edit",$lang)."</a>";
							$swEditMenus[] = "<a href='".$wiki->link("history")."'>".swSystemMessage("History",$lang)."</a>";
							
							$wiki->user = $user->name;
							$name2 = str_replace("\\","",$name2);
							
							if ($name2 != $wiki->name)
							{
								$wiki2 = new swWiki;
								$wiki2->name = $wiki->name;
								$wiki2->user = $wiki->user;
								$wiki2->content = "#REDIRECT [[$name2]]";
								$wiki2->insert();
								$wiki->name = $name2;
							}
							
							$wiki->insert();

							$swParsedName = "Renamed: $name2";
							$swParsedContent = $wiki->parse();
							
							
							// to do: move also talk page?

					}
					else
					{
						$swError = swSystemMessage("NoAccessError",$lang);
					}
				    break;

	
	
	case "delete": 	
					if ($user->hasright("delete", $wiki->name))
					{
						$wiki->user = $user->name;
						$wiki->delete();
						$swParsedName = "Deleted: $name";
						$swEditMenus[] = "<a href='".$wiki->link("edit")."'>".swSystemMessage("Edit",$lang)."</a>";
					}
					else
					{
						$swError = swSystemMessage("NoAccessError",$lang);
					 }
					 break;						

	case "protect": 	if ($user->hasright("protect", $wiki->name))
						{
							$wiki->user = $user->name;
							$wiki->protect();
							$swParsedName = "Protected: $name";
							$swParsedContent = $wiki->parse();
							$swEditMenus[] = "<a href='".$wiki->link("")."'>".swSystemMessage("View",$lang)."</a>";
							$swEditMenus[] = "<a href='".$wiki->link("edit")."'>".swSystemMessage("Edit",$lang)."</a>";
							$swEditMenus[] = "<a href='".$wiki->link("history")."'>".swSystemMessage("History",$lang)."</a>";
						}
						else
						{
							$swError = swSystemMessage("NoAccessError",$lang);
					    }
					 break;						

	case "unprotect": 	if ($user->hasright("protect", $wiki->name))
						{
							$wiki->user = $user->name;
							$wiki->unprotect();
							$swParsedName = "Unprotected: $name";
							$swParsedContent = $wiki->parse();
							$swEditMenus[] = "<a href='".$wiki->link("")."'>".swSystemMessage("View",$lang)."</a>";
							$swEditMenus[] = "<a href='".$wiki->link("edit")."'>".swSystemMessage("Edit",$lang)."</a>";
							$swEditMenus[] = "<a href='".$wiki->link("history")."'>".swSystemMessage("History",$lang)."</a>";
						}
						else
						{
							$swError = swSystemMessage("NoAccessError",$lang);
					    }
					 break;						

	
	case "revert":		if ($user->hasright("modify", $wiki->name))
						{
							$swEditMenus[] = swSystemMessage("View",$lang);
							$swEditMenus[] = "<a href='".$wiki->link("edit")."'>".swSystemMessage("Edit",$lang)."</a>";
							$swEditMenus[] = "<a href='".$wiki->link("history")."'>".swSystemMessage("History",$lang)."</a>";
							
							$wiki->user = $user->nameshort();
							$wiki->insert();
							
							$swParsedName = "Reverted: $wiki->name";
							$swParsedContent = $wiki->parse();

						}
						else
						{
							$swError = swSystemMessage("NoAccessError",$lang);
						}
						break;
	
	case "accept":		if ($user->hasright("modify", $wiki->name))
						{
							$swEditMenus[] = "".swSystemMessage("View",$lang)."";
							$swEditMenus[] = "<a href='".$wiki->link("edit")."'>".swSystemMessage("Edit",$lang)."</a>";
							$swEditMenus[] = "<a href='".$wiki->link("history")."'>".swSystemMessage("History",$lang)."</a>";
							
							$wiki->user = $user->nameshort();
							$wiki->insert();
							
							$swParsedName = "Accepted: $wiki->name";
							$swParsedContent = $wiki->parse();

						}
						else
						{
							$swError = swSystemMessage("NoAccessError",$lang);
						}
						break;
	
	case "search":		include_once "inc/special/search.php";
						break;
	
	case "talk": 		
	case "view": 		
	
	default: 			include_once "inc/special/view.php";

}




if ($swRedirectedFrom)
	$swParsedContent .= "<p><i>Redirected from $swRedirectedFrom</i></p>";



// apply page skin
if (!array_key_exists($skin,$swSkins)) $skin = "default";
if ($swSkins[$skin])
	$templatefile = "$swSkins[$skin]";
else
	$templatefile = "$swSkins[default]";
if (file_exists($templatefile))
{
	include $templatefile;
}
else
	die("missing page template $swSkins[default]");

// do cron job


// debug

if ($username != "")
	$u = $username;
else
	$u = $ip;
$endtime = microtime();
if ($endtime<$starttime) $endtime = $starttime;
$usedtime = sprintf("%004d",($endtime-$starttime)*1000);
swLog($username,$name,$action,$query,$lang,$referer,$usedtime,$swError,"","","");
swCron();


?>