<?php

if (!defined("SOFAWIKI")) die("invalid acces");

class swSubstrFunction extends swFunction
{

	function info()
	{
	 	return "(s, start, length) Emulates the PHP substr function";
	}

	
	function dowork($args)
	{
		$s = $args[1];		
		$start = $args[2];		
		$ende = $args[3];	
	
		
		return substr($s,$start,$ende);
		
	}

}

$swFunctions["substr"] = new swSubstrFunction;


?>