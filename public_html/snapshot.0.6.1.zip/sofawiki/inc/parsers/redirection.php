<?php

if (!defined("SOFAWIKI")) die("invalid acces");

class swRedirectionParser extends swParser
{
	function info()
	{
	 	return "Handles directves #REDIRECT and #DISPLAYNAME";
	}

	
	
	function dowork(&$wiki)
	{
		
	
		$s = $wiki->parsedContent;
		$key = "#REDIRECT"; 
		
		if (substr($s,0,strlen($key))==$key)
		{
			
			$myname = $wiki->name;
			$pos = strpos($s,"[[") + strlen("[[");
			$pos2 = strpos($s,"]]",$pos);
			
			$wiki->name = substr($s,$pos,$pos2-$pos);
			$wiki->revision = NULL;
			$wiki->lookup();
					
			global $swRedirectedFrom;
			$swRedirectedFrom = $myname;
			$wiki->parsedContent = 	"$wiki->content"; 	
			
			// edit menu 
		}
		
		$key = "#DISPLAYNAME"; 
		
		if (substr($s,0,strlen($key))==$key)
		{
			
			if ($p=strpos($s,"\n"))
			{
				
			}
			else
			{
				$p = strlen($s);
			}
			
			$wiki->name = substr($s,strlen($key),$p-strlen($key));
			$wiki->content = substr($s,$p+1);
		}
		
		
		
	}

}

$swParsers["redirection"] = new swRedirectionParser;


?>