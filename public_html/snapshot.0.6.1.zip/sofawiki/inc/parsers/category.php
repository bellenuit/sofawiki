<?php

if (!defined("SOFAWIKI")) die("invalid acces");

class swCategoryParser extends swParser
{

	function info()
	{
	 	return "Creates category directory";
	}


	function dowork(&$wiki)
	{

		if (substr($wiki->originalName,0,9) == "Category:")
		{
			
			global $swSearchNamespaces;
			$namespaces = join(" ",$swSearchNamespaces);
			
			
			$revisions = swFilter("[[".$wiki->originalName."]]",$namespaces);
			
			$record = new swWiki;
			
			$list = array();

			foreach ($revisions as $k=>$v)
			{
					$record->revision = $k;
					$record->lookup();
					
					$list[$record->name] = "<li>[[".$record->name."]]</li>";
			}
			ksort($list);
			
			$s = $wiki->parsedContent;
			
			$s .= "\n<div id='categoryList'><ul>".join("\n",$list)."\n</ul></div>";
			
			$wiki->parsedContent = $s;
		}
		
	}

}
$swParsers["category"] = new swCategoryParser;



?>