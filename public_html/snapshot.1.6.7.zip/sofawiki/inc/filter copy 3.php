<?php

if (!defined('SOFAWIKI')) die('invalid acces');



function swFilterCompare($operator,$values,$term)
{	
	if (!is_array($values))  // single value
		$values = array($values);
	
	$valuelist = array();
	
	if ($operator == '*')
	{
		if (count($values)>0) return true;
		return false;
	}
	
	if (substr($operator,0,1)=='!')
	{
		$op = substr($operator,1);
		$result = swFilterCompare($op,$values,$term);
		return !$result;
	}	
	
	foreach($values as $v)
	{
		$valuelist[] = swUnescape($v);
	}
	
	
	$term = swUnescape($term);
		
	switch ($operator)
	{
		
		case '=': foreach($valuelist as $v)
				   {	if (floatval($v)==floatval($term)) return true; } break;
		case '<>': foreach($valuelist as $v)
				   {	if (floatval($v)==floatval($term)) return true; } break;
		case '<': foreach($valuelist as $v)
				   {	if (floatval($v)<floatval($term)) return true; } break;
		case '>': foreach($valuelist as $v)
				   {	if (floatval($v)>floatval($term)) return true; } break;
		case '<=': foreach($valuelist as $v)
				   {	if (floatval($v)<=floatval($term)) return true; } break;
		case '>=': foreach($valuelist as $v)
				   {	if (floatval($v)>=floatval($term)) return true; } break;
		case '==': foreach($valuelist as $v)
				   {	if ($v==$term) return true; } break;
		case '=*': foreach($valuelist as $v)
				   {	if (substr($v,0,strlen($term))==$term) return true; } break;
		case '*=': foreach($valuelist as $v)
				   {	if (substr($v,-strlen($term))==$term) return true; } break;
		case '*=*': foreach($valuelist as $v)
				   {	 if (stripos($v,$term) !== FALSE) return true; } break;
		case '<<': foreach($valuelist as $v)
				   {	if ($v<$term) return true; } break;
		case '>>': foreach($valuelist as $v)
				   {	if ($v>$term) { return true; } } break;
		case '<<=': foreach($valuelist as $v)
				   {	if ($v<=$term) return true; } break;
		case '>>=': foreach($valuelist as $v)
				   {	if ($v>=$term) return true; } break;
		case '~~': foreach($valuelist as $v)
				   {	$v = swNameURL($v);
						if ($v==$term) return true; } break;
		case '~*': foreach($valuelist as $v)
				   {	$v = swNameURL($v);
						if (substr($v,0,strlen($term))==$term) return true; } break;
		case '*~': foreach($valuelist as $v)
				   {	$v = swNameURL($v);
						if (substr($v,-strlen($term))==$term) return true; } break;
		case '*~*': foreach($valuelist as $v)
				   {    $v = swNameURL($v);
						if (stripos($v,$term) !== FALSE) return true; } break;						
		case '0': foreach($valuelist as $v)
				   {	if ($v == 0 || $v == '') return true; } break;
		case 'r=': foreach($valuelist as $v)
					{ if (preg_match($term, $v, $matches)) return true; }
					break;
		default:   return false;
	}
	return false;
}


function swQueryFieldlistCompare($revision, $fieldlist,$fields,$field,$operator,$term,$comparefields)
{
	// compares a tuple against an operation and a term and returns a tuple
	
	$row = array();
	
	// normalize array, to a table, but using only used fields and field
	$maxcount = count($fieldlist[$field]);
	foreach($fields as $v)
	{
		if (isset($fieldlist[$v]))
			$maxcount = max($maxcount,count($fieldlist[$v]));
	}	
	$fieldlist2 = array();
	foreach($fieldlist as $key=>$v)
	{
		for($fi=0;$fi<count($v);$fi++)
		{
			$fieldlist2[$fi][$key] = $v[$fi];
		}
		for ($fi=count($v);$fi<$maxcount;$fi++)
		{
			$fieldlist2[$fi][$key] = $v[count($v)-1];
		}
	}
	
	// compare
	for ($fi=0;$fi<$maxcount;$fi++)
	{
		$onefieldvalue = @$fieldlist2[$fi][$field];
		if ($comparefields)
		{
			$term2 = swQueryTupleExpression($fieldlist2[$fi], $term);
			if (is_array($term2))
			{
				return $term2; //error
			}
			else
				$found = swFilterCompare($operator,array($onefieldvalue),$term2);
		}
		else
			$found = swFilterCompare($operator,array($onefieldvalue),$term);
			
		if ($found)
		{
			
			foreach ($fields as $f)
			{
				// we cannot return an error here, because the data might be an old revision with other data scheme
				if ($f == '_rating')
				{
						$content = $fieldlist[$field];
						$content = array_shift($content);
						$contenturl = swNameURL($content);
						$termurl = swNameURL($term);
						
						//row value will be simple rating algorithm: 
						//counts the number of occurences and the position
						$rating = 0;
						$len0 = strlen($contenturl);
						while ($contenturl = stristr($contenturl,$termurl))
						{
							$rating += strlen($contenturl) * strlen($termurl) / $len0 / $len0 ;
							//echo $termurl."=".$contenturl." ";
							$contenturl = substr($contenturl,1);
						}
						//echo $rating;
						
						$row[$revision.'-'.$fi][$f] = sprintf('%09.3f',$rating);
				}
				else
					$row[$revision.'-'.$fi][$f] = @$fieldlist2[$fi][$f];
			}
		}
	}




	return $row;

}

function swGetFilterCacheHeader($filter,$namespace,$mode='query')
{
	global $swRoot;
	if (rand(0,100) < 1) swFilter($filter,$namespace,$mode);
	
	// find already searched revisions
	$mdfilter = $filter;
	$mdfilter .= $namespace;
	$mdfilter .= $mode;
	$mdfilter = urlencode($mdfilter);
	$cachefilebase = $swRoot.'/site/queries/'.md5($mdfilter);
	$cachefile = $cachefilebase.'.txt';
		
	if (file_exists($cachefile)) 
	{
		if ($handle = fopen($cachefile, 'r'))
		{
			while ($arr = swReadField($handle))
			{
				if (@$arr['_primary'] == '_header')
				{
					fclose($handle);
					return $arr;
				}
			}
			fclose($handle);
		}
	 }
}


function swFilter($filter,$namespace,$mode='query',$flags='',$checkedbm = NULL)
{
	
	global $swIndexError;
	global $swMaxSearchTime;
	global $swMaxOverallSearchTime;
	global $swStartTime;
	
	$verbose = 0;
	if (isset($_REQUEST['verbose'])) $verbose = 1;
	
	global $swRoot;
	global $db;
	$lastfoundrevision = 0;
	$goodrevisions = array();
	$bitmap = new swBitmap;
	$checkedbitmap = new swBitmap;
	$operator = '';
	$fields = array();
	$field = '';
	$term = '';
	$namefilter = '';
	$namefilter0 = '';
	
	if ($swIndexError) return $goodrevisions;
	
	if ($mode != 'query')
	{
		echotime('filter mode depreciated '.$mode);
		swNotify('filter','filtermodedepreciated','filter '.$mode,$filter);
	}
	// parse select string SELECT fields WHERE field operator term
	
	if (substr($filter,0,6) == 'SELECT')
	{
		$filter2 = substr($filter,7);
		
		if ($p = strpos($filter2,' FROM '))
		{
			//namefilter from query is not the same that the namespace that depends on 
			//the user rights
			$p+= strlen(' FROM ');
			if (!$p2 = strpos($filter2,' WHERE '))
				$p2 = strlen($filter2);
			$namefilter = $namefilter0 = substr($filter2,$p,$p2-$p);
			$filter2 = str_replace(' FROM '.$namefilter,'',$filter2);
			
			$namefilter = trim($namefilter);
			$namefilter = swNameURL($namefilter);
			
			// the filter has to use now the more specific of the namespace and the namefilter
			
			
			
			// namefilter for main namespace only
			if ($namefilter == 'main:')
			{	
				$namespace = '';
				$namefilter = '';
			}
									
			// if the namespace is all, then the new namespace is the namefilter
			elseif (stristr($namespace,'*'))
				$namespace = $namefilter;

			//VIRTUAL
			if (strpos($namespace, 'virtual-') === 0)
				$namespace = substr($namespace, strlen('virtual-'));

				
			// if the namefilter does not contain : then the new namespace is common namespace and all namespaces starting with namefilter
			elseif(!stristr($namefilter,':'))
			{
				$spaces = explode('|',$namespace);
				$newspaces = array();
				$newspaces[$namefilter] = $namefilter;
				foreach($spaces as $sp)
				{
					$sp = swNameURL($sp);
					$test = substr($sp,0,strlen($namefilter));
					if ($test == $namefilter)
						$newspaces[$sp] = $sp;
				}
				//echotime(print_r($newspaces,true));
				$namespace = join('|',$newspaces);
			}
			// if the namefilter contains : and is valid in the namespace then the new namespace is the namefilter
			else
			{
				$spaces = explode('|',$namespace);
				$newspaces = array();
				$ns = substr($namefilter,0,strpos($namefilter.':',':')); 
				$found = FALSE;
				foreach($spaces as $sp)
				{
					$sp = swNameURL($sp);
					if (stristr($ns,$sp) || stristr($namefilter,$sp)) $found = TRUE;
				}
				if ($found)
				{
					$namespace = $namefilter;
				}
				else
				{
					// if the namefilter contains : and is not valid, then an empty result is returned
					return(array('_error'=>'invalid name '.$namefilter));
				}
			}
						
			
		}
		
		// implicit WHERE 
		if (!stristr($filter2,' WHERE')) $filter2 .= ' WHERE';
		
		if ($p = strpos($filter2,' WHERE'))
		{
			$fields = substr($filter2,0,$p);
			$fs = explode(',',$fields);
			$fields = array();
			foreach($fs as $f)	{ $fields[]=trim($f); }
			$fields = array_unique($fields);
			
			$query = substr($filter2,$p+strlen(' WHERE')+1);
			$words = explode(' ',$query);
			$wordlist = array();
			foreach($words as $w) { if ($w != '') $wordlist[] = $w; }
			if (count($wordlist)>0)
			{
				$field = $wordlist[0]; 
				if (count($wordlist)>1)
				{
					$operator = $wordlist[1];
					unset($wordlist[1]);
				}
				else
					$operator = '*';
				unset($wordlist[0]);
				if (count($wordlist)>0)
					$term = trim(join(' ',$wordlist));
				else
					$term = '';
			}
			else
			{
				// find all
				$field = '_name';
				$operator = '*';
				$term = '';
			}
		}
		else
		{
			// find all
			$field = '_name';
			$operator = '*';
			$term = '';
		}
	}
	
	echotime('filter ['.$mode.'|'.$namespace.'] '.$filter);
	
	
	$comparefields = false;
	if (substr($operator,0,1) == '$')
	{	
		$operator = substr($operator,1);
		$comparefields = true;
	}
	
	
	if (substr($filter,0,6) == 'FIELDS')
		$fields = array('fields');
	
	if ($operator == '~~'|| $operator == '*~'|| $operator == '~*'|| $operator == '*~*') 
		$term = swNameURL($term);

	// VIRTUAL
	if ($mode=='query' && stristr($namefilter0, 'VIRTUAL '))
	{
		echotime('virtual');
		$urlname = str_replace('VIRTUAL ','',$namefilter0);
		$urlname = trim($urlname);
		$urlname = swNameURL($urlname);
		if (stristr($urlname,':')) // page has namespace
		{
			$spaces = explode('|',$namespace);
			$newspaces = array();
			$ns = substr($urlname,0,strpos($urlname.':',':')); 
			$found = FALSE;
			foreach($spaces as $sp)
			{
				$sp = swNameURL($sp);
				if (stristr($ns,$sp) || stristr($urlname,$sp)) $found = TRUE;
			}
			if (!$found)
			{
				return(array('_error'=>'invalid name '.$urlname.' ('.$namespace.')'));
			}
	    }
		
		$w = new swWiki;
		$w->name = $urlname;
		$w->lookup();
		
		if ($w->revision == 0) return(array('_error'=>'unknown name '.$urlname));
		
		$w->parsedContent = $w->content;
		$fp = new swTidyParser;
		$fp->dowork($w);
		$fp = new swTemplateParser;
		$fp->dowork($w);
		
		$s = $w->parsedContent; //field output has nowiki tags
		$s = str_replace('<nowiki>','',$s);
		$s = str_replace('</nowiki>','',$s);
		
		$list = swGetAllFields($s);
		$list['_name'] = $w->name;
		
		$row = swQueryFieldlistCompare($w->revision,$list,$fields,$field,$operator,$term,$comparefields);
		
		return $row;
	}
	
	
	
	// find already searched revisions
	$mdfilter = $filter;
	$mdfilter .= $namespace;
	$mdfilter .= $mode;
	$mdfilter = urlencode($mdfilter);
	$cachefilebase = $swRoot.'/site/queries/'.md5($mdfilter);
	$cachefile = $cachefilebase.'.txt';
	
	global $swDebugRefresh;
	if ($swDebugRefresh || stristr($flags,'refresh'))
		{ echotime('refresh'); if (file_exists($cachefile)) unlink($cachefile);}
	
	$chunks = array();
	if (file_exists($cachefile)) 
	{
		if ($handle = fopen($cachefile, 'r'))
		{
			// one file for header
			
			while ($arr = swReadField($handle))
			{
				if (@$arr['_primary'] == '_header')
				{
					$bitmap = unserialize($arr['bitmap']);
					$checkedbitmap = unserialize($arr['checkedbitmap']);
					if (isset($arr['chunks']))
					$chunks = unserialize($arr['chunks']);
				}
			}
			fclose($handle);
			echotime('<a href="index.php?name=special:indexes&index=queries&q='.md5($mdfilter).'" target="_blank">'.md5($mdfilter).'.txt</a> ');
			
			// 1+ file for revisions
			foreach($chunks as $chunk)
			{
				$chunkfile = $cachefilebase.'-'.$chunk.'.txt';
				$handle = fopen('php://memory','r+');
				fwrite($handle,file_get_contents($chunkfile));
				fseek($handle,0);
				$i =0;
				//if ($handle = fopen($chunkfile, 'r'))
				{
					while ($arr = swReadField($handle))
					{
						$primary = @$arr['_primary'];
						unset($arr['_primary']);
						$goodrevisions[$primary] = $arr;
						$i++;
					}
					fclose($handle);
					echotime($chunk.'.'.$i);
				}
			}
			echotime('cached '.count($goodrevisions));
		}

	}
	$cachechanged = false;
	$db->init();

	$maxlastrevision = $db->lastrevision;
	$indexedbitmap = $db->indexedbitmap->duplicate();
	if ($indexedbitmap->length < $maxlastrevision) RebuildIndexes($indexedbitmap->length); // fallback
	$bitmap->redim($maxlastrevision,false);
	$checkedbitmap->redim($maxlastrevision,false);
	$currentbitmap = $db->currentbitmap->duplicate();
	$deletedbitmap = $db->deletedbitmap->duplicate();
	$notchecked = $checkedbitmap->notop();
	$tocheck = $indexedbitmap->andop($notchecked);
	unset($notchecked);
	$tocheck = $currentbitmap->andop($tocheck);
	$tocheckcount = $tocheck->countbits();
	if ($tocheckcount>0) 
	{ 
		echotime('tocheck '.$tocheckcount); 
	}
	$checkedcount = 0;

	// update changes for revisions that are not valid any more
	
	foreach($goodrevisions as $k=>$v)
	{
		$kr = substr($k,0,strpos($k,'-'));
		if($indexedbitmap->getbit($kr) && !$currentbitmap->getbit($kr))
		{
			$bitmap->unsetbit($kr);
			unset($goodrevisions[$k]);
			$cachechanged = true; 
			$checkedcount++;
		}
		if($deletedbitmap->getbit($kr))
		{
			$bitmap->unsetbit($kr);
			unset($goodrevisions[$k]);
			$cachechanged = true; 
			$checkedcount++;
		}
		if (!$indexedbitmap->getbit($kr))
		{
			$db->UpdateIndexes($kr); // fallback
		}
	}
	$nowtime = microtime(true);	
	$dur = sprintf("%04d",($nowtime-$swStartTime)*1000);
	if ($dur>$swMaxOverallSearchTime) 
		echotime('overtime overall');

	if (($tocheckcount > 0 || $cachechanged) && $dur<=$swMaxOverallSearchTime)
	{
		
		// cachechanged must provoke removal of obsolete revisions and save of new cachefile
				
		// if there is an existing search on a substring, we can exclude all urls with no result
		// a cron tab will create searches on all possible strings with 3 characters
		// we therefore test again all substrings with 3 characters

			if ($tocheckcount > 16 ) // small searches reduction is not interesting
			{
	
					// restrict on namefilter
					if ($namefilter)
					{
							
							
							$filter2 = 'SELECT _revision WHERE _name ~* '.$namefilter;

							$filtercache = swGetFilterCacheHeader($filter2,'*','query'); 
							
							$bm = unserialize($filtercache['bitmap']);
							$chbm = unserialize($filtercache['checkedbitmap']);
							
							
							if (is_a($chbm,'swBitmap') && is_a($bm,'swBitmap'))
							{
								for ($k=1;$k<=$maxlastrevision;$k++)
								{
									if ($tocheck->getbit($k) && $chbm->getbit($k) && !$bm->getbit($k) )
									{
										$tocheck->unsetbit($k);$checkedbitmap->setbit($k);$checkedcount++;
									}								
								}
							}
							$tocheckcount = $tocheck->countbits();
							echotime('- namefilter '.$tocheckcount);
					}


				
				// if it is query search, we can restrict to all revisions that have the field
				if ($tocheckcount > 16 && isset($field) && $mode == 'query' )
				{
					
					$filter2 = 'SELECT _revision, '.$field.' WHERE '.$field.' * ';
					if ($filter2 != $filter) // no recursion
					{
						$filtercache = swGetFilterCacheHeader($filter2,'*','query'); 
							
						$bm = unserialize($filtercache['bitmap']);
						$chbm = unserialize($filtercache['checkedbitmap']);
							
							
						if (is_a($chbm,'swBitmap') && is_a($bm,'swBitmap'))
						{
							for ($k=1;$k<=$maxlastrevision;$k++)
								{
										if ($tocheck->getbit($k) && $chbm->getbit($k) && !$bm->getbit($k) )
										{
											$tocheck->unsetbit($k);$checkedbitmap->setbit($k);$checkedcount++;
										}								
								}
						}
						$tocheckcount = $tocheck->countbits();
						echotime('- * '.$tocheckcount);
					}
				}	
				
				if ($tocheckcount > 16 && $mode == 'relaxed' && strlen($filter)>=3)
				{
					for($i=0;$i<=strlen($filter)-3;$i++)
					{
						if ($tocheckcount < 16) continue;
						$f = substr($filter,$i,3);
						$gr = getTrigram($f);
						if ($gr)
						{
							$gr->redim($tocheck->length, true);
							$tocheck = $tocheck->andop($gr);
							$notgr = $gr->notop();
							$checkedbitmap = $checkedbitmap->orop($notgr);
						}
						$tocheckcount = $tocheck->countbits();
						echotime('- '.$f.' '.$tocheckcount);
					}
				
				}
				
				// search only in records which have the field
				// and use also the 3letter-trick on the field
				if ($tocheckcount > 16 && isset($field) && strlen($field)>=3 && $mode == 'query' && substr($field,0,1) != '_'  )
				{
						
					$field2 = swNameURL($field);
					for($i=0;$i<=strlen($field2)-3;$i++)
					{
						if ($tocheckcount < 16) continue;
						$f = substr($field2,$i,3);
						$gr = getTrigram($f);
						if ($gr)
						{
							$gr->redim($tocheck->length, true);
							$tocheck = $tocheck->andop($gr);
							$notgr = $gr->notop();
							$checkedbitmap = $checkedbitmap->orop($notgr);
						}
						$tocheckcount = $tocheck->countbits();
						echotime('- '.$f.' '.$tocheckcount);
					}
						
						
				}
				
				// use the 3letter trick on the term (trigram)
				if ($tocheckcount > 16 && isset($term) && !$comparefields && strlen($term)>=3 && ( $operator == '==' || $operator == '*=' || $operator == '=*' 
				|| $operator == '*=*' 
				|| $operator == '~~'|| $operator == '*~'|| $operator == '~*'|| $operator == '*~*'))
				{
					
					if (strlen($term)>=3)
					{
						$term2 = swNameURL($term);
						for($i=0;$i<=strlen($term2)-3;$i++)
						{
							if ($tocheckcount < 16) continue;
							$f = substr($term2,$i,3);
							$gr = getTrigram($f);
							if ($gr)
							{
								$gr->redim($tocheck->length, true);
								$tocheck = $tocheck->andop($gr);
								$notgr = $gr->notop();
								$checkedbitmap = $checkedbitmap->orop($notgr);
							}
							$tocheckcount = $tocheck->countbits();
							echotime('-term '.$f.' '.$tocheckcount);
						}
					}
				
				}
			
			}
			
			$starttime = microtime(true);
			if ($swMaxSearchTime<500) $swMaxSearchTime = 500;
			if ($swMaxOverallSearchTime<2500) $swMaxOverallSearchTime = 2500;
			global $swOvertime;
			$overtime = false;
			$toc = $tocheck->countbits();
			$checkedcount += $tocheckcount - $toc;
			echotime('loop '.$toc);
			

			$handle = tmpfile();

		
			for ($k=$maxlastrevision;$k>=1;$k--)
			{
				if ($toc == 0) continue; //empty loop
				if (!$tocheck->getbit($k)) continue; // we already have ecluded it from the list
				if ($checkedbitmap->getbit($k)) continue; // it has been checked, should not happen here any more
		 	
			 	if(!$indexedbitmap->getbit($k)) continue; // it has not been indexed, should not happen here any more
				if(!$currentbitmap->getbit($k)) { $bitmap->unsetbit($k); continue; } // should not happen here any more
				if($deletedbitmap->getbit($k)) { $bitmap->unsetbit($k); $checkedbitmap->setbit($k); $checkedcount++; continue; }
				// should not happen here any more
			
				$checkedcount++;
				
				$nowtime = microtime(true);	
				$dur = sprintf("%04d",($nowtime-$starttime)*1000);
				if ($dur>$swMaxSearchTime) 
				{
					echotime('overtime '.$checkedcount.' / '.$tocheckcount);
					$overtime = true;
					if (!stristr($flags,'internal'))
							$swOvertime=true;
					break;
				}
				$dur = sprintf("%04d",($nowtime-$swStartTime)*1000);
				if ($dur>$swMaxOverallSearchTime) 
				{
					echotime('overtime overall '.$checkedcount.' / '.$tocheckcount);
					$overtime = true;
					if (!stristr($flags,'internal'))
							$swOvertime=true;
					break;
				}
					
				$record = new swRecord;
				$record->revision = $k;
				$record->lookup();
				
				if ($record->error == '') $checkedbitmap->setbit($k); else continue;
				$urlname = swNameURL($record->name);
								
				// apply namefilter
				
				if ($namefilter != '' && substr($urlname,0,strlen($namefilter)) != $namefilter)
					{ $bitmap->unsetbit($k); continue; }
				
				
				// apply namespace
				
				if (stristr($urlname,':') && $namespace != '*') // page has namespace
				{
					$spaces = explode('|',$namespace);
					$newspaces = array();
					$ns = substr($urlname,0,strpos($urlname.':',':')); 
					$found = FALSE;
					foreach($spaces as $sp)
					{
						$sp = swNameURL($sp);
						if ($sp != '')
						{
								if (stristr($ns,$sp) || stristr($urlname,$sp)) $found = TRUE;
						}
					}
					if (!$found)
					{
						{ $bitmap->unsetbit($k); continue; }
					}
				}
				
				
				$content = $record->name.' '.$record->content;
				$row=array();
				
				$fieldlist = $record->internalfields;

				if ($filter == 'FIELDS')
				{
					$keys =array_keys($fieldlist);
					if (count($keys)>0)
					{
						$i = 0;
						foreach($keys as $key)
						{
							$row[$k.'-'.$i]['_fields'] = $key;
							$i++;
						}
					}
				}
				elseif (substr($filter,0,6) == 'SELECT')
				{
					
					
					$fieldlist['_revision'][] = $record->revision;
					$fieldlist['_status'][] = $record->status;
					$fieldlist['_name'][] = $record->name;
					$fieldlist['_content'][] = $record->content;
					$fieldlist['_*'][] = $record->name."\n".$record->content;
					
					if (!isset($fieldlist[$field])) { $bitmap->unsetbit($k); continue; }
					
					$row = swQueryFieldlistCompare($k,$fieldlist,$fields,$field,$operator,$term,$comparefields);
					if (isset($row['_error'])) return $row;
					
				}
				//print_r($row);
				if (count($row)>0)
				{
					foreach($row as $primary=>$line)
					$goodrevisions[$primary] = $line;
					$bitmap->setbit($k);
					
					
					if ($handle) swWriteRow($handle, $row );
					$touched = true;
				}
			}
			

			// save to cache
			$bitmap->hexit();
			$checkedbitmap->hexit();
						
			echotime('checked '.$checkedcount);
			
			if ($handle) {
			
				
				if (isset($touched))
				{
					fseek($handle, 0);
					
					if (!isset($chunks) || count($chunks)==0)
						$chunks = array('1');
					$chunk = array_pop($chunks); $chunks[] = $chunk; //array-last without removing it
					$chunkfile = $cachefilebase.'-'.$chunk.'.txt';
					if (file_exists($chunkfile) && filesize($chunkfile)>1000000) 
					{
						$chunk++;
						$chunks[] = $chunk;
						$chunkfile = $cachefilebase.'-'.$chunk.'.txt';
					}
	
					$handle2 = fopen($chunkfile, 'a');
					while(!feof($handle))
						fwrite($handle2,fread($handle,8192));
					fclose($handle2);
				}
				
				
				$handle2 = fopen($cachefile, 'w');
				$header = array();
				$header['filter'] = $filter;
				$header['mode'] = $mode;
				$header['namespace'] = $namespace;
				$header['overtime'] = $overtime ;
				$header['chunks'] = serialize($chunks);
				$header['bitmap'] = serialize($bitmap);
				$header['checkedbitmap'] = serialize($checkedbitmap);
				$row = array('_header'=>$header);
				swWriteRow($handle2, $row );
				
				fclose($handle2);
				fclose($handle);
			}			
			
			echotime('good '.count($goodrevisions));
			echomem("filter");	
		
	
	}
	
		
	
		//we sort to eliminate duplicates
		
		usort($goodrevisions, 'swMultifieldSort');
		
		
		$lastjoin='';
		foreach($goodrevisions as $k=>$v)
		{
			$key = join('::',$v);
			if ($key == $lastjoin)
				unset($goodrevisions[$k]);
		}
		return $goodrevisions;
	
}

function swMultifieldSort($a,$b) { return join('::',$a)>join('::',$b);}

?>