<?php

if (!defined("SOFAWIKI")) die("invalid acces"); 

function wgets($FromLocation,$ToLocation)
{

 $VerifyPeer=false; $VerifyHost=false; 
// Initialize CURL with providing full https URL of the file location
$Channel = curl_init($FromLocation);
 
// Open file handle at the location you want to copy the file: destination path at local drive
$File = fopen ($ToLocation, "w");
 
// Set CURL options
curl_setopt($Channel, CURLOPT_FILE, $File);
 
// We are not sending any headers
curl_setopt($Channel, CURLOPT_HEADER, 0);
 
// Disable PEER SSL Verification: If you are not running with SSL or if you don't have valid SSL
curl_setopt($Channel, CURLOPT_SSL_VERIFYPEER, $VerifyPeer);
 
// Disable HOST (the site you are sending request to) SSL Verification,
// if Host can have certificate which is invalid / expired / not signed by authorized CA.
curl_setopt($Channel, CURLOPT_SSL_VERIFYHOST, $VerifyHost);
 
// Execute CURL command
curl_exec($Channel);
 
// Close the CURL channel
curl_close($Channel);
 
// Close file handle
fclose($File);
 
	// return true if file download is successfull
	return file_exists($ToLocation);
}



function unzip($file,$destination)
{
	$zip = zip_open($file);
	if (is_resource($zip))
	{
	  while ($zip_entry = zip_read($zip)) 
	  {
		$name = zip_entry_name($zip_entry);
		if(strpos($name, '.'))
		{
			if (zip_entry_open($zip, $zip_entry, "r")) 
			{
			  $fp = fopen("$destination/".zip_entry_name($zip_entry), "w");
			  $buf = zip_entry_read($zip_entry, zip_entry_filesize($zip_entry));
			  fwrite($fp,"$buf");
			  zip_entry_close($zip_entry);
			  fclose($fp);
			}
		}
		else
			@mkdir("$destination/$name");
	  }
	  zip_close($zip);
	}
}	


$swParsedName = "Special:Update"; 

$swParsedContent = "<p>Update SofaWiki version from http://www.belle-nuit.com/sofawiki/";
$swParsedContent = "<br/>Use with care";



$swParsedContent .= "</p><p>Available versions";

$serverfile = "http://www.belle-nuit.com/sofawiki/site/files/snapshot.txt";
$localfile = "$swRoot/snapshot.txt";

wgets($serverfile,$localfile);


$filelist = split("\n",file_get_contents("$swRoot/snapshot.txt"));
arsort($filelist);

$swParsedContent .= "\n<form method='get' action='index.php'><p>";
$swParsedContent .= "\n<select name='file'>";
foreach ($filelist as $f)
{	
	$swParsedContent .= "<option value='$f'>$f</option>";
}
$swParsedContent .= "\n</select>";
$swParsedContent .= "\n<input type='hidden' name='name' value='Special:Update'>";
$swParsedContent .= "\n<input type='submit' name='submitdownload' value='Download' />";
$swParsedContent .= "\n</p><form>";

$file = $_REQUEST['file'];
$serverfile = "http://www.belle-nuit.com/sofawiki/site/files/$file";
$localfile = "$swRoot/$file";

if ($_REQUEST["submitdownload"] && $file !="")
{
	wgets($serverfile,$localfile);
}


$swParsedContent .= "</p><p>Downloaded versions</p>";

$files = glob("$swRoot/snapshot*.zip");

$swParsedContent .= "\n<form method='get' action='index.php'><p>";
$swParsedContent .= "\n<select name='file'>";
foreach ($files as $f)
{	
	$swParsedContent .= "<option value='$f'>$f</option>";
}
$swParsedContent .= "\n</select>";

$swParsedContent .= "\n<input type='hidden' name='name' value='Special:Update'>";
$swParsedContent .= "\n<input type='submit' name='submitdecompress' value='Decompress' />";
$swParsedContent .= "\n</p><form>";



if ($_REQUEST["submitdecompress"] && $file !="")
{
	@mkdir("$swRoot/install/");
	unzip($file,"$swRoot/install/");
}

$swParsedContent .= "<p>Decompressed files</p>";

function rglob($pattern)
{
	// used non recursive solution
	$patternlist = array($pattern);
	$donelist = array();
	
	while (count($patternlist)>0)
	{
		$p = array_shift($patternlist);
		$donelist[$p] = true;
		$files = glob($p);
		
		if (count($files)>0)
		{
			foreach ($files as $f)
			{	
				$list[$f] = $f;
				$nextpattern = $f."/*";
				if (!$donelist[$nextpattern])
				$patternlist[] = $nextpattern;
			}
		}
		
	}
	asort($list);
	return $list;
}

$files = rglob("$swRoot/install/*");

$swParsedContent .= "\n<form method='get' action='index.php'><p><pre>";
foreach ($files as $f)
{	
	$swParsedContent .= "$f\n";
}

if (count($files)>0)
{
	$swParsedContent .= "\n</pre><input type='hidden' name='name' value='Special:Update'>";
	$swParsedContent .= "\n<input type='submit' name='submitinstall' value='Install' style='color:red'/>";
	$swParsedContent .= "\n</p><form>";
}


if ($_REQUEST["submitinstall"] && $file !="")
{
	rename("$swRoot/install/sofawiki/inc","$swRoot/inc");
	rename("$swRoot/install/sofawiki/api.php","$swRoot/api.php");
	rename("$swRoot/install/sofawiki/index.php","$swRoot/index.php");
	
	$swParsedContent .= "<p>Installed</p>";

}




$swParseSpecial = false;



?>