<?php

if (!defined("SOFAWIKI")) die("invalid acces");

$swParsedName = "Backup";
$swParsedContent = "";
$swParsedContent .= "Backup of SofaWiki site. <br/><br/>";



$zipfile = new zipfile();  

$emptydirectories = array();
$includeddirectories = array();

$emptydirectories[] = "sofawiki/site/cache"; 
$emptydirectories[] = "sofawiki/site/files";
$emptydirectories[] = "sofawiki/site/indexes";
$emptydirectories[] = "sofawiki/site/queries";
$emptydirectories[] = "sofawiki/site/upload";

$includeddirectories[] = "sofawiki/site";
$includeddirectories[] = "sofawiki/site/current";
$includeddirectories[] = "sofawiki/site/logs";
$includeddirectories[] = "sofawiki/site/revisions";
$includeddirectories[] = "sofawiki/site/skins";

$files = array();


foreach($emptydirectories as $dir)
{
	$zipfile -> add_dir($dir."/",time());
	$swParsedContent .= "$dir<br/>";
}

foreach($files as $file)
{
	$zipfile -> add_file(file_get_contents($file), "sofawiki/$file", filemtime($file)); 
	$swParsedContent .= "&nbsp;$file<br/>";
}


foreach ($includeddirectories as $dir)
{
	$zipfile -> add_dir($dir."/",time());
	$swParsedContent .= "$dir<br/>";
	$dir = substr($dir,strlen("sofawiki/"));
	$absolutedir = "$swRoot/".$dir;
	
	$formats = array("php","css","txt");
	
	foreach ($formats as $f)
	{
		$files = glob($absolutedir."/*.$f");
		natsort($files);
		foreach($files as $file)
		{
			$zf = str_replace($swRoot,"sofawiki",$file);
			$zipfile -> add_file(file_get_contents($file), $zf,filemtime($file)); 
			$swParsedContent .= "&nbsp;$zf<br/>";
		}
	}
}

$today = date("Ymd",time());

$filename = "site".".zip";
$fd = fopen("$swRoot/bak/".$filename, "wb");
$out = fwrite ($fd, $zipfile -> file());
fclose ($fd);

$filename = "site$today".".zip";
$fd = fopen("$swRoot/bak/".$filename, "wb");
$out = fwrite ($fd, $zipfile -> file());
fclose ($fd);
	
$swParsedContent .=  "<br/><a href='backup.zip'>backup.zip</a>";





?>