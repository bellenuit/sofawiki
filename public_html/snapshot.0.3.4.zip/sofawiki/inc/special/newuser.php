<?php

if (!defined("SOFAWIKI")) die("invalid acces");

if (!$swNewUserEnable) return;


if (array_key_exists("signature", $_REQUEST)) 
	$signature = $_POST['signature'];
else
	$signature = "";
if (array_key_exists("email", $_REQUEST)) 
	$email = $_POST['email'];
else
	$email = "";
if (array_key_exists("forename", $_REQUEST)) 
	$forename = $_POST['forename'];
else
	$forename = "";
if (array_key_exists("familyname", $_REQUEST)) 
	$familyname = $_POST['familyname'];
else
	$familyname = "";
if (array_key_exists("street", $_REQUEST)) 
	$street = $_POST['street'];
else
	$street = "";
if (array_key_exists("city", $_REQUEST)) 
	$city = $_POST['city'];
else
	$city = "";
if (array_key_exists("phone", $_REQUEST)) 
	$phone = $_POST['phone'];
else
	$phone = "";
if (array_key_exists("country", $_REQUEST)) 
	$country = $_POST['country'];
else
	$country = swSystemMessage("CountrydDefault",$lang);
	
$submitted = false;

if ($action == "newusersubmit")
{
	// verify if new user can add themselves
	if (!$swNewUserEnable)
		$swError = swSystemMessage("NoAccessError",$lang);

	// verify that all arguments are there
	// if ( !$signature || !$email || !$forename || !$familyname || !$street || !$city || !$country)
	foreach ($swNewUserFormFields as $f)
	{
		if (!$GLOBALS[$f])
			$swError = swSystemMessage("NewUserMissingFieldsError",$lang);
	}
	
	// verify that no field has a tag
	$s = $signature.$email.$forename.$familyname.$street.$city.$country;
		if (!swValidate($s,"<'[]{}*\""))
		$swError = swSystemMessage("NewUserInvalidCharactersError",$lang);
	
	// verify the email looks possible
	if (!(stristr($email,"@")) || stristr($email," "))
		$swError = swSystemMessage("EmailLooksNotValidError",$lang);
	
	// verify that the signature is not already taken (signature will be user)	
	$r = swGetCurrentRevisionFromName("User:$signature");
	if ($r>0)
		$swError = swSystemMessage("UserExistsAlreadyError",$lang);
	if ($signature == $poweruser->nameshort())
		$swError = swSystemMessage("UserExistsAlreadyError",$lang);
	
	
	
	
	
	if (!$swError)
	{
		
		$w = new swUser;
		$w->name = "User:$signature";
		$w->pass = rand(111111,99999);
		$w->content = "[[email::$email]] 
[[forename::$forename]] 
[[familyname::$familyname]]
[[street::$street]]
[[city::$city]]
[[country::$country]]
[[phone::$phone]]
[[_pass::".$w->encryptpassword()."]]
$swNewUserRights";
		$w->insert();
		
		$label = $swMainName.":".swSystemMessage("YourPasswordTitle",$lang);
		$message = swSystemMessage("YourPasswordMessage",$lang)."\n
		User=$signature\n
		Password=$w->pass\n";
		
		//swNotify("newusersubmit",$label,$message,$email);
		swNotify("newusersubmit",$swError,$label,$message,$email);
		$submitted = true;
	
	}
	
}


$swParsedName = swSystemMessage("New User",$lang);

if ($submitted)
{
	$swParsedContent = swSystemMessage("Signature",$lang) . ": $signature<br/>";
	$swParsedContent .= swSystemMessage("Email",$lang) . ": $email<br/><br/>
	<div id='help'>".swSystemMessage("NewUserSubmitHelp",$lang)."</div>";
	
}
else
{
$swParsedContent = "<div id='editzone'>
		<form method='post' action='index.php'>
		<table><tr><td>
		".swSystemMessage("Signature",$lang)."</td><td>
		<input type='text' name='signature' value='$signature' />
		</td></tr><tr><td>".swSystemMessage("Email",$lang)."</td><td>
		<input type='text' name='email' value='$email' />";
			
	if (array_key_exists("forename",$swNewUserFormFields))
 	$swParsedContent .=
		"</td></tr><tr><td>".swSystemMessage("Forename",$lang)."</td><td>
		<input type='text' name='forename' value='$forename' />";
		
	if (array_key_exists("familyname",$swNewUserFormFields))
 	$swParsedContent .=		
		"</td></tr><tr><td>".swSystemMessage("Name",$lang)."</td><td>
		<input type='text' name='familyname' value='$familyname' />";
		
	if (array_key_exists("street",$swNewUserFormFields))
 	$swParsedContent .=		
		"</td></tr><tr><td>".swSystemMessage("Street",$lang)."</td><td>
		<input type='text' name='street' value='$street' />";
		
		
	if (array_key_exists("city",$swNewUserFormFields))
 	$swParsedContent .=
		"</td></tr><tr><td>".swSystemMessage("City",$lang)."</td><td>
		<input type='text' name='city' value='$city' />";
		
	if (array_key_exists("country",$swNewUserFormFields))
 	$swParsedContent .=
		"</td></tr><tr><td>".swSystemMessage("Country",$lang)."</td><td>
		<input type='text' name='country' value='$country' />";
		
		
	if (array_key_exists("phone",$swNewUserFormFields))
 	$swParsedContent .=
		"</td></tr><tr><td>".swSystemMessage("Phone",$lang)."</td><td>
		<input type='text' name='phone' value='$phone' />";
		
 	$swParsedContent .=
		
		"<input type='hidden' name='action' value='newusersubmit' /></td></tr><tr><td></td><td>
		<input type='submit' name='submitprotect' value='".swSystemMessage("New User",$lang)."' /></td></tr></table>
	</form>
	
	<div id='help'>".swSystemMessage("NewUserHelp",$lang)."</div>
	</div>
	";
}



?>