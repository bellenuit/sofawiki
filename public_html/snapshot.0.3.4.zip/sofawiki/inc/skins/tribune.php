<?php
// as the file is included, echo must be used so that the <? is not interpreted by PHP
echo '<?xml version="1.0" encoding="ISO-8859-1"?>';  ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
        "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><?php echo $swParsedName ?></title>
<link rel='stylesheet' href="inc/skins/tribune.css"/>
</head>
<body>
<div id='menu1'><p class='menu'>Tribune
<br/> <?php foreach($swLangMenus as $item) {echo $item." " ; } ?>
<br/><br/>
<?php 
echo $swHomeMenu. "<br/><br/>"; 
foreach($swEditMenus as $item) {echo $item."<br/>"; }
echo "<br/>";
foreach($swLoginMenus as $item) {echo $item."<br/>" ; }
echo "</p>
";
echo $swSearchMenu;
echo "</div>";
// echo join(" ",$wiki->internalLinks);

?>

<div id='contenu'>

<div id='menu'>
<?php if ($swError) echo "<div id='error'>$swError</div>"; ?>
</div>


<div id='content'>

<h1><?php echo "$swParsedName" ?></h1>

<div id='parsedContent'><?php echo "

$swParsedContent
" ?>

</div>


<div id="info"><?php echo "$swFooter" ?>
<p class='menu'>
 <?php echo swSystemMessage("Copyright",$lang); ?>
</p>
</div>
</div>
</div>  
</body>
</html>