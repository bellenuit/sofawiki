<?php

if (!defined("SOFAWIKI")) die("invalid acces");

// 1. Name your wiki

$swMainName = "SofaWiki";

// 2. Create a master user. This needed because there is no user page yet at installation

$poweruser = new swUser;
$poweruser->username = "default";
$poweruser->ppass = "123";
$poweruser->content = "[[_view::*]] 
[[_create::*]] 
[[_upload::*]]
[[_modify::*]]
[[_propose::*]]
[[_protect::*]] 
[[_rename::*]]
[[_delete::*]]
[[_special::special]]";

// 2. Define your encryption salt so that md5 footprints cannot be reused on another server.
// Note that a change here makes all your current User passwords invalid.

$swEncryptionSalt = "0000";

// 3. Enable skins. If you create your own skins, start with a copy of default.php and move it to the site/skins folder

$swSkins["default"] = "inc/skins/default.php";
$swSkins["iphone"] = "inc/skins/iphone.php";

// 4. Enable languages

// $swLanguages[] = "de";
// $swLanguages[] = "en";
// $swLanguages[] = "fr";
// $swLanguages[] = "it";


// 5. Namespaces that are allowed for transclusion. normally this is only main and templates.
// Pay attention: If you allow User namespace, everybody can see User Rights of other users.

// $swTranscludeNamespaces[] = "Namespace";



?>