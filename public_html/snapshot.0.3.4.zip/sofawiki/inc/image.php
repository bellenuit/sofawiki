<?php

if (!defined("SOFAWIKI")) die("invalid acces");


function swImageDownscale($name, $destw)
{
    //  ImageCreateTrueColor not supported on local php distribution mac
	global $swRoot;

	$destw = sprintf("%03d",$destw);
	$pfad0 = "$swRoot/site/files/$name";
	 
	$pfad1 = "$swRoot/site/cache/$destw"."-"."$name";
	
	switch (substr($name,-4))
	{
		case ".jpg" : ;
		case "jpeg" : $img = ImageCreateFromJpeg($pfad0); break;
		case ".png" : $img = ImageCreateFromPNG($pfad0); break;
		case ".gif" : $img = ImageCreateFromGIF($pfad0); break;
		
		case ".pdf" : return false;
		default: return false;
	}
	
	
	if ($img)
	{
		$sourcew = ImagesX($img);
		$sourceh = ImagesY($img);
		$desth = $destw *$sourceh / $sourcew; 
	
	
		$back = ImageCreateTrueColor($destw,$desth);
		ImageCopyResampled($back, $img, 0,0,0, 0, $destw, $desth, $sourcew, $sourceh);

		imagejpeg($back,$pfad1,90);
		
		imagedestroy($img);
		imagedestroy($back);
		return true;
	}

}




?>