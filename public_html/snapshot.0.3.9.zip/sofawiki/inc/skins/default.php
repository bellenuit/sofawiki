<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title><?php echo $swParsedName ?></title>
<link rel='stylesheet' href="inc/skins/default.css"/>
</head>
<body>

<div id='search'>
<?php echo $swSearchMenu; ?>
</div>


<div id='menu'>
<?php 
echo $swHomeMenu. " "; 
foreach($swEditMenus as $item) {echo $item." "; }
foreach($swLoginMenus as $item) {echo $item." " ; }
foreach($swLangMenus as $item) {echo $item." " ; }

echo " <span class='error'>$swError</span>"; ?>
</div>


<div id='content'>

<h1><?php echo "$swParsedName" ?></h1>

<div id='parsedContent'><?php echo "

$swParsedContent
" ?>

</div>
</div>

<div id="info"><?php echo "$swFooter" ?></div>

</body>
</html>