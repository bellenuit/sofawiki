<?php

if (!defined("SOFAWIKI")) die("invalid acces");

$swCreateSitemap = false;

function swSitemap()

{
		global $swMaxOverallSearchTime;
		global $swCreateSitemap ; 
		global $db;
		global $swBaseHrefFolder;
		
		if (!$swCreateSitemap) return;
		
		$firsts = array('-','0','1','2','3','4','5','6','7','8','9',
	'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z');
	
		$swMaxOverallSearchTime /= 40;
	
		$list = array();
		foreach($firsts as $f)
		{
		
			$filter = "SELECT name WHERE name ~* $f";
			$result = swFilter($filter,'','data');
		
		
			foreach($result as $row)
			{
				if (isset($row['name'][0]))
				{
					$n = swNameURL($row['name'][0]);
					$list[$n] = 1;
				}
			}
		}
		
		
		
		$filter = 'SELECT name WHERE content =* #REDIRECT';
		$result2 = swFilter($filter,'','data');
		$swMaxOverallSearchTime *= 40;
		foreach($result2 as $row)
		{
			if (isset($row['name'][0]))
			{
				$n = swNameURL($row['name'][0]);
				unset($list[$n]);
			}
		}
		
		
		ksort($list);
		
		$alluser = new swUser;

		$resultlist []= '<?xml version="1.0" encoding = "UTF-8"?>
    <urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
';
    
    	//print_r($list);
    
    
		
		foreach ($list as $url=>$r)
		{
			if (!$alluser->hasright('view',$url)) continue; // only main namespace
			
			
				$resultlist[] =
'                <url>
                <loc>'.$swBaseHrefFolder.$url.'</loc>
                <changefreq>weekly</changefreq>
                <priority>1.0</priority>
            </url>
';
			
		}
		
		$resultlist []= 
		'</urlset>';
	
	$result = join(' ',$resultlist);
	
	global $swRoot;
	$file = $swRoot.'/sitemap.xml';
	if ($handle = fopen($file, 'w')) { fwrite($handle, $result); fclose($handle); }
	else { echo swException('Write error sitemap'); $error = 'Write error sitemap';  return; }

}

?>
