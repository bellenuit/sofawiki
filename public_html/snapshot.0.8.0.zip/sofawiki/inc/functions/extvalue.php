<?php

if (!defined("SOFAWIKI")) die("invalid acces");

class swExtValueFunction extends swFunction
{

	function info()
	{
	 	return "(name, field, separator, template, header, footer) gets the values of a field in a page";
	}

	
	function dowork($args)
	{

		// uses ../utilities.php
		
		

		$name =  $args[1];	
		$field = $args[2];
		
		if (count($args)>3)	
			$separator = $args[3];
		else
			$separator = '';
		if (count($args)>4 && $args[4] != '')	
			$template = $args[4];
		else
			$template = '';
		if (count($args)>5)
			$header = $args[5];
		else
			$header = '';
		if (count($args)>6)	
			$footer = $args[6];
		else
			$footer = '';
		
	
		$wiki = new swWiki;
		$wiki->name = $name;
		$wiki->lookup();
		
		$list = array();
		if (isset($wiki->internalfields[$field]))
			$list = $wiki->internalfields[$field];
		
		if (!is_array($list) || count($list)==0) return "";
		
		
		foreach ($list as $elem)
		{
			if ($elem != "" )
			{
				if ($template != "")
					$results[] = '{{'.$template.'|'.$elem.'}}';
				else
					$results[] = $elem;
			}
		}
		
		
		
		$result = join($separator,$results);
		
		if (trim($result) != "")
			$result = $header.$result.$footer;
		
		return $result;	
	}

}

$swFunctions["extvalue"] = new swExtValueFunction;


?>