<?php

if (!defined("SOFAWIKI")) die("invalid acces");

// 1. Name your wiki

$swMainName = "SofaWiki";
$swBaseHref = "http://www.belle-nuit.com/sofawiki/index.php";

// 2. Create a master user. This needed because there is no user page yet at installation

$poweruser = new swUser;
$poweruser->username = "admin";
$poweruser->ppass = "1234";
$poweruser->content = "[[_view::*]] 
[[_create::*]] 
[[_upload::*]]
[[_modify::*]]
[[_propose::*]]
[[_protect::*]] 
[[_rename::*]]
[[_delete::*]]
[[_special::special]]";


// 3. Define default rights for users that create themselves

$swAllUserRights .= " [[_view::Main]] ";
$swNewUserRights .= " [[_create::Main]]  [[_modify::Main]] [[_talk::Main]] [[_upload::*]] [[_view::Special:Upload]]";
$swNewUserEnable = true;

// 4. Define the fields necessary for new user form. Signature and Email is alwaysed asked for

// $swNewUserFormFields["forename"] = true;
// $swNewUserFormFields["familyname"] = true;
// $swNewUserFormFields["street"] = true;
// $swNewUserFormFields["city"] = true;
// $swNewUserFormFields["country"] = true;
// $swNewUserFormFields["phone"] = true;

// 5. Define your encryption salt so that md5 footprints cannot be reused on another server.
// Note that a change here makes all your current User passwords invalid.

$swEncryptionSalt = "0000";


// 6. Configure skins and add your own. If you create your own skins, start with a copy of default.php and move it to the site/skins folder
// You can also force a skin here

// $swSkins["default"] = "inc/skins/default.php";
// $skin = "zeitung";

// 7. Enable languages

$swLanguages[] = "de"; 
$swLanguages[] = "en";
$swLanguages[] = "fr";
$swDefaultLang = "en";


// 8. Namespaces that are allowed for transclusion. normally this is only main and templates.
// Pay attention: If you allow User namespace, everybody can see User Rights of other users.

 $swTranscludeNamespaces[] = "Image";

// 9. Namespaces that are included for search

// $swSearchNamespaces[] = "Namespace";

// 10. Define your own SystemDefaults. You can also do this making a System: page

// $swSystemDefaults["NamespaceTribune/fr"] = "Tribune";
// $swSystemDefaults["NamespaceTribuneTalk/fr"] = "Commmentaires Tribune";

// 11. Define max length of comments in talk

// $swMaxNewTalkLength = 1500;

// 12. Define Email and actions to notify

   $swNotifyMail = "a@b.c";
// $swNotifyActions[] = "newusersubmit";  // password sent to user
// $swNotifyActions[] = "lostpasswordsubmit"; // new password sent to user
// $swNotifyActions[] = "newtalksubmit"; 
// $swNotifyActions[] = "propose";

// 13. Define Hooks

/*
function swInternalLinkHook($val,$label)
{
	
}
*/

// 14. Define custom functions

// include_once "$swRoot/site/functions/myfunction.php";

// 15. Define Simple URL scheme and enable simple URL scheme

/* add the following to your .htaccess file

RewriteEngine on
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^(.*)$ index.php?name=$1 [L,QSA]

*/

// $swSimpleURL = true; 

// 16. allow image scaler functions (works only on servers, not on localhost

$swImageScaler = true;

// 17. set Timezone

swSetTimeZone("Europe/Zurich");

// 18 set Twitter archive name

// $swTwitterUser = "myname";

// 18 filetypes for which browser should download and not open a new window

$swMediaFileTypeDownload = ".xls.docx.doc.";



?>