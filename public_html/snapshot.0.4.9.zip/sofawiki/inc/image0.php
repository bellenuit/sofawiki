<?php

if (!defined("SOFAWIKI")) die("invalid acces");


// STUB

function swImageDownscale($name, $destw)
{
    return false;
}




?>