<?php

if (!defined("SOFAWIKI")) die("invalid acces");

$swParsedName = "Special:Categories";

$names = $db->GetAllNames();
uasort($names, 'strnatcasecmp'); 
$swParsedContent = "";
$oldfirst = "";

foreach ($names as $n=>$v)
{
	if (substr($n,0,9)=="Category:")
	{
		$categoryname = substr($n,9);
		$first = strtolower(substr($categoryname,0,1));
		
		if ($oldfirst && $oldfirst != $first) $swParsedContent .= "\n\n";
		$swParsedContent .= "[[:$n|$categoryname]] ";
		$oldfirst = $first;
 	}
}

$swParseSpecial = true;



?>