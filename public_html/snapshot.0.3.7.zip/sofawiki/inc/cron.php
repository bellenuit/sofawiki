<?

if (!defined("SOFAWIKI")) die("invalid acces");


function swCron()
{
	
	// open cron page
	
	$cronwiki = new swWiki();
	$cronwiki->name = "Cron:Cron";
	try {
	$cronwiki->lookup();
	}
	catch(Exception $e)
	{
				
	}
	
	// get the first item to do
	$c = $cronwiki->content;
	$job =  swGetValue($c, "_todo");
	
	
	if (!$job) return;

	// open the mail page
	
	$jobwiki = new swWiki();
	$jobwiki->name = $job;
	try {
	$jobwiki->lookup();
	}
	catch(Exception $e)
	{
				
	}
	
	$s = $jobwiki->content;
	$outbox =  swGetValue($s, "_outbox");
	if (!$outbox) 
	{
		// eventually remove job in the cron page
		$c = str_replace("[[_todo::$job]]","",$c);
		$cronwiki->content = $c;
		$cronwiki->insert();
		return;		
	};
	
	// get the next 100 adresses to send
	$subject = $jobwiki->name;
	$subject = substr($subject,5); // remove Mail:
	$subject = substr($subject,0,-10); // remove Timestamp;
	$sent = swGetValue($s, "_sent");
	
	$message = str_replace("[[_outbox::$outbox]]","",$s);
	$message = str_replace("[[_sent::$sent]]","",$message);
	
	// send
	$list = explode(",",$outbox);
	$sents = explode(",",$sent);
	
	global $swNotifyMail;
	
	$headers = "From: $swNotifyMail" . "\r\n" .
   "Reply-To: $swNotifyMail" . "\r\n" .
   "Content-Type: text/plain; charset=\"iso-8859-1\"\r\n" .
    'X-Mailer: PHP/' . phpversion();
	
	$i=0;
	$outs = array();
	foreach($list as $v)
	{
		if ($i<100)
		{
			// echo "<!-- mail $v,$subject,$message,$headers -->";
			if (mail($v, $subject, $message, $headers))
			array_push($sents,$v);
		}
		else
		{
			array_push($outs,$v);
		}
		$i++;
	}
	
	
	// remove adresses in the mail page
	
	$outbox = join(",",$outs);
	$sent = join(",",$sents);
	$jobwiki->content = $message . "\n\n[[_outbox::$outbox]]\n\n[[_sent::$sent]]";
	$jobwiki->insert();
	
	
}


?>