<?php
// as the file is included, echo must be used so that the <? is not interpreted by PHP
echo '<?xml version="1.0" encoding="ISO-8859-1"?>';  ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
        "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><?php echo swSystemMessage("Sitename",$lang);  echo " ".$swParsedName ?></title>
<link rel='stylesheet' href="inc/skins/tele.css"/>
</head>
<body>

<div id='body'>

<!--
<div id='search'>
<?php echo $swSearchMenu; ?>
</div>
-->

<div id='logo'>
<a href="index.php">
<!-- <img src="site/files/tele.gif">-->
</a>
</div>

<div id='header'>
<div id='header-elem'>

<?php



$ishome = (($name=="Home" || $name="") && ($action=="view" || $action==""));

$s = swSystemMessage("Site Header",$lang,true); 

if ($ishome)
{
	echo "<h2>$s</h2>";
}
else
{
	echo "<p>$s</p>";

}
?>
</div>
</div>


<div id='menu'><small>
<?php 

foreach($swLangMenus as $item) {echo $item."<br/>" ; }
echo "<br/>";
	
if (!$ishome)
{
	echo $swHomeMenu. "<br/><br/>"; 
	
	
}
if (count($swEditMenus)>1)
	foreach($swEditMenus as $item) {echo $item."<br/>"; }



echo " <span class='error'>$swError</span>"; ?>
</small></div>


<div id='content'>

<?php if (!$ishome) echo "<h2>$swParsedName</h2>" ?>

<div id='parsedContent'><?php echo "

$swParsedContent
" ?>

</div>

<div id='footer2'>

</div>


</div>

<div id='footer'><small>
<?php if ($ishome ||�true) 
{ echo swSystemMessage("Impressum",$lang,true);
echo "<br/>"; 
foreach($swLoginMenus as $item) {echo $item." " ; } ; echo "</small>"; }  ?>

<?php if (!$ishome && false) {
echo swSystemMessage("Impressum small",$lang,true);
echo "<br/><small>"; 
foreach($swLoginMenus as $item) {echo $item." " ; } ; echo "</small>"; } ?>


</div>

</div> <!--body-->



</body>
</html>