<?php
// as the file is included, echo must be used so that the <? is not interpreted by PHP
echo '<?xml version="1.0" encoding="ISO-8859-1"?>';  ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
        "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><?php echo swSystemMessage("Sitename",$lang);  echo " ".$swParsedName ?></title>
<link rel='stylesheet' href="inc/skins/zeitung.css"/>
</head>
<body>
<div id='body'>

<!--
<div id='search'>
<?php echo $swSearchMenu; ?>
</div>
-->

<div id='menu'><small>
<?php
	echo $swHomeMenu. "<br/><br/>"; 
	if (count($swEditMenus)>1)
		foreach($swEditMenus as $item) {echo $item."<br/>"; }
	echo " <span class='error'>$swError</span>"; 
?>
</small></div>
<div id='content'>
<?php echo "<h1>$swParsedName</h1>" ?>

<div id='parsedContent'>
<?php echo "
$swParsedContent
" 
?>
</div>
</div>

<div id='footer'>
<?php
	echo swSystemMessage("Impressum",$lang,true);
	echo "<br/><small>"; 
	foreach($swLoginMenus as $item) {echo $item." " ; } ; echo "</small>";  
?>
</div>

</div> <!--body-->
</body>
</html>