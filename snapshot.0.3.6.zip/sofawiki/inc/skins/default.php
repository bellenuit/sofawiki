<?php
// as the file is included, echo must be used so that the <? is not interpreted by PHP
echo '<?xml version="1.0" encoding="ISO-8859-1"?>';  ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
        "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><?php echo $swParsedName ?></title>
<link rel='stylesheet' href="inc/skins/default.css"/>
</head>
<body>

<div id='search'>
<?php echo $swSearchMenu; ?>
</div>


<div id='menu'>
<?php 
echo $swHomeMenu. " "; 
foreach($swEditMenus as $item) {echo $item." "; }
foreach($swLoginMenus as $item) {echo $item." " ; }
foreach($swLangMenus as $item) {echo $item." " ; }

echo " <span class='error'>$swError</span>"; ?>
</div>


<div id='content'>

<h1><?php echo "$swParsedName" ?></h1>

<div id='parsedContent'><?php echo "

$swParsedContent
" ?>

</div>
</div>

<div id="info"><?php echo "$swFooter" ?></div>

</body>
</html>