<?php

if (!defined("SOFAWIKI")) die("invalid acces");

class swTidyParser extends swParser
{

	function info()
	{
	 	return "Removes HTML tags";
	}


	function dowork($wiki)
	{

		$s = $wiki->parsedContent;
		
		// echo "<p>s $s";

        $s = strip_tags($s,'<b><i><u><s><sup><sub><tt><code><span><br/><hr/><small><big><div>');
        $s = str_replace("&","&amp;",$s);
		
		$wiki->parsedContent = $s;
		
	}

}

$swParsers["tidy"] = new swTidyParser;


?>