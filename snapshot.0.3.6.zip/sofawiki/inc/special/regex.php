<?php

if (!defined("SOFAWIKI")) die("invalid acces");

$replace = $_REQUEST[replace];
$submitreplace = $_REQUEST[submitreplace];
$submitreplacepreview = $_REQUEST[submitreplacepreview];

if ($query)
{
	//preserve backspace
	$query = str_replace("\\\\","\\",$query);
	$replace = str_replace("\\\\","\\",$replace);
}

$swParsedName = "".swSystemMessage("Regex",$lang);
if ($query) $swParsedName .= ": $query";

$ns = join(" ",$swSearchNamespaces);

if ($query)
{
	$revisions = swFilter($query,$ns,true);
}
else
$revisions = array();

$searchtexts = array();

$record = new swWiki;

foreach ($revisions as $k=>$v)
{
	$record->revision = $k;
	$record->lookup();
	
	if ($record->status=="ok" or $record->status=="protected")
	{
		$t = "";
		if (($submitreplacepreview || $submitreplace) && $replace)
			$t = preg_replace($query,"<del>$0</del><ins>".$replace."</ins>",$record->content);
		else
			$t = preg_replace($query,"<ins>$0</ins>",$record->content);
			
		$ts = split("\n",$t);
		
		foreach($ts as $tline)
		{
			if (stristr($tline,"<ins>"))
			$tlines[] = $tline;
		}
		
		$t = join("\n",$tlines);
		
		
		if ($submitreplace && $_REQUEST["revision".$record->revision])
		{
			if ($record->status == "protected")
				$replaced = "protected";
			elseif ($record->status == "ok" && $user->hasright("modify", $record->name))
			{
				$record->content = preg_replace($query,$replace,$record->content);
				$record->comment = "regex find $query replace $replace";
				$record->insert();
				$replaced = "replaced";
			}
		}
		else
			$replaced = "";
			
		if ($submitreplacepreview && $record->status == "ok" && $user->hasright("modify", $record->name))
			$check = "<input type='checkbox' name='revision".$record->revision."' value='1' CHECKED>";
		else
			$check = "";
		
		$searchtexts[] = "<li>$check $record->revision <a href='".$record->link("")."'>$record->name</a> $replaced
		<br/><pre>$t</pre></li>";
	}
	
	
	
}

$swParsedContent = "<div id='editzone'><form method='get' action='index.php'>
		<p><input type='hidden' name='action' value='search' />
		<input type='hidden' name='name' value='Special:Regex' />
		<input type='text' name='query' value='$query' />
		<input type='submit' name='submit' value='".swSystemMessage("Search",$lang)."' />
		<input type='text' name='replace' value='$replace' />
		<input type='submit' name='submitreplacepreview' value='".swSystemMessage("Replace Preview",$lang)."' />";
		
if ($submitreplacepreview)

$swParsedContent .= "<input type='submit' name='submitreplace' value='".swSystemMessage("Replace",$lang)."' />";
	
$swParsedContent .= "</p><p><i>Note: You need to use Perl style delimiters at the start and at the end like /searchterm/.
	<br/>This is a very powerful tool that can change many wiki pages at once. Use it carefully.</i>";

$swParsedContent .= "<ul>".join("\n",$searchtexts)."</ul>";


$swParsedContent .= "</p></form>";
?>