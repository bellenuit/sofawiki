<?php

if (!defined("SOFAWIKI")) die("invalid acces");


if ($user->hasright("modify", $wiki->wikinamespace()) || $user->hasright("propose", $wiki->wikinamespace()) |
$user->hasright("protect", $wiki->wikinamespace()) || $user->hasright("delete", $wiki->wikinamespace()))	

{

	$wiki2 = new swWiki;
	$wiki2->name = $wiki->name;
		try {
			$wiki2->lookup(true);
		} catch(exception $e) {
			
		}
	
	if ($wiki->revision < $wiki2->revision)
	{
		$swParsedName = "Diff: $wiki->name (revision $wiki2->revision against $wiki->revision)";
		$swParsedContent = "<pre>".htmldiff($wiki->content,$wiki2->content)."</pre>";
		if ($user->hasright("modify", $wiki->wikinamespace()))
		$swParsedContent .= "<p><a href='index.php?revision=$wiki->revision&action=revert'>Revert to revision $wiki->revision</a></p>";
		$swParsedContent .= "<p><a href='index.php?revision=$wiki->revision&action=edit'>Edit revision $wiki->revision</a></p>";
	}
	else
	{
		$swParsedName = "Diff: $wiki->name (revision $wiki->revision against $wiki2->revision)";
		$swParsedContent = "<pre>".htmldiff($wiki2->content,$wiki->content)."</pre>";
		if ($user->hasright("modify", $wiki->wikinamespace()))
		$swParsedContent .= "<p><a href='index.php?revision=$wiki->revision&action=accept'>Accept proposal $wiki->revision</a></p>";
		$swParsedContent .= "<p><a href='index.php?revision=$wiki->revision&action=edit'>Edit proposal $wiki->revision</a></p>";
	}
	
		
		$swParsedContent .= "\n\n<div class='preview'>".$wiki->parse()."\n</div>";
		
	
	}
	else
	{
		$swError = "No access";
	}

?>