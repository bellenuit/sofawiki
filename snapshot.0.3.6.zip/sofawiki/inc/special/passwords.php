<?php

if (!defined("SOFAWIKI")) die("invalid acces");

$swParsedName = "Special:Passwords";


if (array_key_exists("mypass", $_POST)) 
	$mypass = $_POST['mypass'];
else
	$mypass="";
if (array_key_exists("myname", $_POST)) 
	$myname = $_POST['myname'];
else
	$myname="";


$swParsedContent = "<p>Password Encryptor

<div id='editzone'>
		<form method='post' action='index.php?name=Special:Passwords'>
		<p>Username <input type='text' name='myname' value='$myname' />
		Password <input type='text' name='mypass' value='$mypass' />
		<input type='Submit' name='submitprotect' value='Encrypt' /></p>
</form>";

if ($mypass != "")
{
	$myuser = new swUser;
	$myuser->pass=$mypass;
	$myuser->username=$myname;
	$swParsedContent .= "<p><a href='index.php?name=User:$myname'>User:$myname</a></p><p>$mypass </p><p>[[_pass::".$myuser->encryptpassword()."]]</p>";
	
}

$swParsedContent .= "</div>";

$swParseSpecial = false;



?>