<?php

if (!defined('SOFAWIKI')) die('invalid acces');

$swParsedName = 'Special:Fields';

/*
$fieldlist = $db->indexFields();
uksort($fieldlist, 'strnatcasecmp'); 
$swParsedContent = '';

foreach ($fieldlist as $k=>$v)
{
	$swParsedContent .= "\n\n'''".$k."'''";
	
	
	foreach($v as $r=>$fieldvalue)
	{
		$swParsedContent .= "\n[[".$r.']] :: '. join(' | ',$fieldvalue);
	}
	
}

//$swParsedConten .= print_r($GLOBALS,true);
$swParsedContent .= "\n\n";
*/

$field = swGetArrayValue($_REQUEST,'field');

if ($field)
{
	$rows = swFilter('select '.$field,'*','sql');
	
	$swParsedContent .= '<p><a href="index.php?name=special:fields">All fields</a>';
	
	$swParsedContent .= '<h4>SELECT name, '.$field.'</h4>';
	
	$swParsedContent .= '<table class="sql"><tr><th>name</th><th>'.$field.'</th></tr>';
	
	
	$allrev = $db->GetAllRevisions();
	foreach ($rows as $rev=>$row)
	{
		if (count($row)>0)
		{
			$swParsedContent .= '<tr><td><a href="index.php?revision='.$rev.'">'.$allrev[$rev].' </a></td>';
			$swParsedContent .=	'<td>'.str_replace('|','<br/>',$row).'</td>';
			$swParsedContent .= '</tr>';
		}
	}
	$swParsedContent .= '</table>';

}
else
{
	$rows = swFilter('show fields','*','sql');
	

	$list = array();
	foreach ($rows as $rev=>$row)
	{
		$fields = explode('||',$row);
		foreach($fields as $field)
		{
			if ($field != '') $list[$field] = 1;
		}
	}
	
	
	$list = array_keys($list);
	asort($list);
	
	$swParsedContent .= '<h4>SHOW fields</h4>';
	
	$swParsedContent .= '<table class="sql"><tr><th>fields</th></tr>';
	
	foreach ($list as $item)
	{
		$swParsedContent .= '<tr><td><a href="index.php?name=special:fields&field='.$item.'">'.$item.'</a></td></tr>';
	}
	
	$swParsedContent .= '</table>';
}

$swParseSpecial = false;





?>