<?php

if (!defined("SOFAWIKI")) die("invalid acces");

$swParsedName = "Special:Info";

$swParsedContent = "'''Version''' {{version}}
'''Encoding''' UTF-8
'''Date''' {{currentdate}}
'''User''' {{currentuser}}
'''Name''' {{currentname}}
'''Skin''' {{currentskin}}
'''Language''' {{currentlanguage}}
'''Pages''' {{countpages}}
'''Revisions''' {{countrevisions}}
====Installed Functions====
{{functions}}
====Installed Parsers====
{{parsers}}
====Installed Skins====
{{skins}}
====Templates====
{{templates}}
====Environment====
Remote Address " .$_ENV["REMOTE_ADDR"]."
User Agent " .$_ENV["HTTP_USER_AGENT"]."
Request URI " .$_ENV["REQUEST_URI"]."
Referer " .$_ENV["HTTP_REFERER"]."
Server Address " .$_ENV["SERVER_ADDR"]."
Host " .$_ENV["HTTP_HOST"]."
PHP Version ".phpversion()."
Memory Limit ".ini_get("memory_limit")."
Memory Usage ".sprintf("%0.1f",memory_get_usage()/1024/1024)."M
Server Signature " .$_ENV["SERVER_SIGNATURE"]."

";

$swParseSpecial = true;

// print_r($_ENV);

?>