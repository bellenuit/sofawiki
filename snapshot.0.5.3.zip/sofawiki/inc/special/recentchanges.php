<?php

if (!defined("SOFAWIKI")) die("invalid acces");

$swParsedName = "Special:Recent Changes";


$revisions = $db->GetAllRevisions();
uksort($revisions, 'strnatcasecmp'); 
$revisions = array_reverse($revisions, true);  // preserve keys

$swParsedContent = "";
$i = 0;

$item = new swWiki;
$now = date("Y-m-d H:i:s",time()-60*60*24*30);

foreach ($revisions as $r=>$v)
{

	
	
	$item->revision = $r;
	$item->lookup(true);
	
	$i++;
	if (($i>30 && $item->timestamp<$now) || $i>100) continue;  // should actually leave foreach

	
	
	if ($item->wikinamespace()=="Image" || $item->wikinamespace()=="Category")
	{
		$swParsedContent .= "$item->timestamp $r [[:$item->name]] $item->status $item->user <i>$item->comment</i>\n";
	}
	else
	{
		$swParsedContent .= "$item->timestamp $r [[$item->name]] $item->status $item->user <i>$item->comment</i>\n";
	}
	
	

}
unset($now);

$swParseSpecial = true;


?>