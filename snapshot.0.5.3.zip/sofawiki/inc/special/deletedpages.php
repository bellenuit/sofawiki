<?php

if (!defined("SOFAWIKI")) die("invalid acces");

$swParsedName = "Special:Deleted Pages";


$names = $db->GetAllDeletions();


uksort($names, 'strnatcasecmp'); 
$swParsedContent = "";
$oldfirst = "";

foreach ($names as $k=>$v)
{
	$first = strtolower(substr($k,0,1));
	if ($oldfirst && $oldfirst != $first) $swParsedContent .= "<p>";
	
	$swParsedContent .= '<a class="invalid" href="index.php?action=history&name='.swNameURL($v).'">'.$v.'</a> ' ;

	$oldfirst = $first;
}

$swParseSpecial = false;


?>