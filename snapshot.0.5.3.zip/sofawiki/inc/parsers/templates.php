<?php

if (!defined("SOFAWIKI")) die("invalid acces");


class swTemplateParser extends swParser
{

	var $functions;
	var $transcludenamespaces;
	
	function info()
	{
	 	return "Handles pages transclusion, functions and templates";
	}
	
	function dowork(&$wiki)
	{
	
		$s = $wiki->parsedContent;
		
		global $swFunctions;
		$this->functions = $swFunctions;
		global $swTranscludeNamespaces;
		$this->transcludenamespaces = array_flip($swTranscludeNamespaces);
		
		// internal links
		//  preg_match_all("/\{\{([^\/\{\}]+)\}\}/U", $s, $matches, PREG_SET_ORDER);
		
		 preg_match_all("/\{{([-\.\w\/\: \|,\'\p{Latin}]+)\}}/U", $s, $matches, PREG_SET_ORDER);
		
		foreach ($matches as $v)
		{
			
			
			
			$val0 = $v[1];
			$vals = explode('|',$v[1]);
			
			$val = $vals[0];
			
			
			
			
			if (array_key_exists($val,$this->functions))
			{
				$f = $this->functions[$val];
				$c = $f->dowork($vals);
				$s = str_replace("{{".$val0."}}",$c,$s);
				
			}
			
			
			if (strpos($val,":")===0)
			{
				$val = substr($val,1);
			}
			elseif (strpos($val,":")>0)
			{
				// explicite namespace
			}
			else
			{
				$val = "Template:$val";
			}
			
			
			
			
			$fields = split(":",$val);
			if (count($fields)>1 && !array_key_exists($fields[0],$this->transcludenamespaces))
			{
				 //echo "($fields[0]) not includable";
				 // print_r($this->transcludenamespaces);
				 continue;
			}
			
			
			
			$linkwiki = new swWiki();
			
				$revision = swGetCurrentRevisionFromName($val);
				if ($revision)
				{
					// now check if not deleted
					$linkwiki->revision = $revision;
					$linkwiki->lookup();
					
					if ($linkwiki->visible())
					{
						$c = $linkwiki->content;
						
						
						
						for ($i = 1; $i< count($vals); $i++)
						{
							$c = str_replace("{{{".$i."}}}",$vals[$i],$c);
						}
						
						
						$s = str_replace("{{".$val0."}}",$c,$s);
						
					}
				}
				else
				{
					if ($fields[0]=="System")
					{
						global $swSystemDefaults;
						if (array_key_exists($fields[1],$swSystemDefaults))
							$c = $swSystemDefaults[$fields[1]];
						else
						{
							$c = substr($fields[1],0,strpos($fields[1],"/"));
						}
						$s = str_replace("{{".$val0."}}",$c,$s);
					}
				}
		}
		
		
		
		$s0 = $wiki->parsedContent;
				
		$wiki->parsedContent = $s;
		
		// recurse
		if ($s != $s0 &&  stristr($s,"{{") && stristr($s,"}}"))
		{
			
			$this->dowork($wiki);
		}
		
		
		
		
	}

}

$swParsers["templates"] = new swTemplateParser;


?>