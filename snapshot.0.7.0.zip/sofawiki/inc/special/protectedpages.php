<?php

if (!defined("SOFAWIKI")) die("invalid acces");

$swParsedName = "Special:Protected Pages";


$names = $db->GetAllProtections();
uksort($names, 'strnatcasecmp'); 
$swParsedContent = "";
$oldfirst = "";


foreach ($names as $k=>$v)
{
	
	$first = strtolower(substr($k,0,1));
	if ($oldfirst && $oldfirst != $first) $swParsedContent .= "\n\n";
	$swParsedContent .= "[[$k]] ";
	$oldfirst = $first;
	
}

$swParseSpecial = true;


?>