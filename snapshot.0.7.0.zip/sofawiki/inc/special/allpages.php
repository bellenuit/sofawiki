<?php

if (!defined("SOFAWIKI")) die("invalid acces");

$swParsedName = "Special:All Pages";


$revisions = $db->GetAllRevisions();

//print_r($revisions);
$urls = $db->GetAllURLs();
		
$swParsedContent = "";
$oldfirst = "";

if (count($urls)>500)
{
	$firsts = array('-','0','1','2','3','4','5','6','7','8','9',
	'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z');
	
	foreach($firsts as $v)
	{
		$swParsedContent .= '<a href="index.php?name=special:all-pages&first='.$v.'">'.$v.'</a> ' ;
	}
	
	$swParsedContent .= '<br><br>';
	
	if (!isset($_REQUEST['first'])) $_REQUEST['first'] = 'a';
}

foreach ($urls as $k=>$v)
{
	if (stristr($k,":")) continue;
	if (stristr($k,"/")) continue;
	
	$name = $revisions[$v];
	
	$first = strtolower(substr($k,0,1));
	
	if ($_REQUEST['first'] != '' && $first != $_REQUEST['first']) continue;
	
	if ($oldfirst && $oldfirst != $first) $swParsedContent .= "\n\n";
	$swParsedContent .= '<a href="index.php?name='.$k.'">'.$name.'</a> ';
	$oldfirst = $first;
}

$swParseSpecial = false;


?>