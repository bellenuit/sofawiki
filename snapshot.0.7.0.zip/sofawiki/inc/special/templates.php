<?php

if (!defined("SOFAWIKI")) die("invalid acces");

$swParsedName = "Special:Templates";

$names = $db->GetAllURLs();
$swParsedContent = "";
$oldfirst = "";

ksort($names);

foreach ($names as $n=>$s)
{
	if (substr($n,0,9)=="template:")
	{
		$templatename = substr($n,9);
		$first = strtolower(substr($templatename,0,1));
		if ($oldfirst && $oldfirst != $first) $swParsedContent .= "\n\n";
		$swParsedContent .= "[[$n|$templatename]] ";
		$oldfirst = $first;
 	}
}


$swParseSpecial = true;



?>