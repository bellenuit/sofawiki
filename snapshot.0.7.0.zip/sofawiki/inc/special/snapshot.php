<?php

if (!defined("SOFAWIKI")) die("invalid acces");

$swParsedName = "Snapshot";
$swParsedContent = "";
$swParsedContent .= "Backup of SofaWiki code. Site-specific files will not be included<br/><br/>";



$zipfile = new zipfile();  

$emptydirectories = array();
$includeddirectories = array();

$emptydirectories[] = "sofawiki";
$emptydirectories[] = "sofawiki/bak";
$emptydirectories[] = "sofawiki/site";
$emptydirectories[] = "sofawiki/site/cache";
$emptydirectories[] = "sofawiki/site/current";
$emptydirectories[] = "sofawiki/site/files";
$emptydirectories[] = "sofawiki/site/functions";
$emptydirectories[] = "sofawiki/site/indexes";
$emptydirectories[] = "sofawiki/site/logs";
$emptydirectories[] = "sofawiki/site/queries";
$emptydirectories[] = "sofawiki/site/revisions";
$emptydirectories[] = "sofawiki/site/skins";
$emptydirectories[] = "sofawiki/site/trigram";
$emptydirectories[] = "sofawiki/site/upload";

$includeddirectories[] = "sofawiki/inc";
$includeddirectories[] = "sofawiki/inc/functions";
$includeddirectories[] = "sofawiki/inc/parsers";
$includeddirectories[] = "sofawiki/inc/skins";
$includeddirectories[] = "sofawiki/inc/special";

$files = array();
$files[] = "index.php";
$files[] = "api.php";


foreach($emptydirectories as $dir)
{
	$zipfile -> add_dir($dir."/",time());
	$swParsedContent .= "$dir<br/>";
}

foreach($files as $file)
{
	$zipfile -> add_file(file_get_contents($swRoot."/".$file), "sofawiki/$file", filemtime($swRoot."/".$file)); 
	$swParsedContent .= "&nbsp;$file<br/>";
}


foreach ($includeddirectories as $dir)
{
	$zipfile -> add_dir($dir."/",time());
	$swParsedContent .= "$dir<br/>";
	$dir = substr($dir,strlen("sofawiki/"));
	$absolutedir = "$swRoot/".$dir;
	$files = glob($absolutedir."/*.php");
	foreach($files as $file)
	{
		$zf = str_replace($swRoot,"sofawiki",$file);
		$zipfile -> add_file(file_get_contents($file), $zf,filemtime($file)); 
		$swParsedContent .= "&nbsp;$zf<br/>";
	}
	$files = glob($absolutedir."/*.css");
	foreach($files as $file)
	{
		$zf = str_replace($swRoot,"sofawiki",$file);
		$zipfile -> add_file(file_get_contents($file), $zf,filemtime($file)); 
		$swParsedContent .= "&nbsp;$zf<br/>";
	}

}

$today = date("Ymd",time());

$filename = "snapshot".".zip";
$fd = fopen("$swRoot/site/files/".$filename, "wb");
$out = fwrite ($fd, $zipfile -> file());
fclose ($fd);

$filename = "snapshot.$swVersion".".zip";
$fd = fopen("$swRoot/site/files/".$filename, "wb");
$out = fwrite ($fd, $zipfile -> file());
fclose ($fd);

$wiki->name ="Image:$filename";
$wiki->user = $user->name;
$wiki->content = str_replace("\\","","");
if ($filename != "")
	$wiki->insert();

$swParsedContent .=  "<br/><a href='".$wiki->link("")."'>Image:$filename</a>";


$filename = "snapshot$today".".zip";
$fd = fopen("$swRoot/site/files/".$filename, "wb");
$out = fwrite ($fd, $zipfile -> file());
fclose ($fd);

$filename = "snapshot$today".".zip";
$fd = fopen("$swRoot/bak/".$filename, "wb");
$out = fwrite ($fd, $zipfile -> file());
fclose ($fd);


$wiki->name ="Image:$filename";
$wiki->user = $user->name;
$wiki->content = str_replace("\\","","");
if ($filename != "")
	$wiki->insert();
	
$swParsedContent .=  "<br/><a href='".$wiki->link("")."'>Image:$filename</a>";

$files = glob("$swRoot/site/files/snapshot.*.zip");
$filename = "snapshot.txt";
$fd = fopen("$swRoot/site/files/$filename", "wb");
foreach($files as $file)
{
	$file = str_replace("$swRoot/site/files/","",$file);
	$out = fwrite ($fd, $file."\n");
}
fclose ($fd);
$wiki->name ="Image:$filename";
$wiki->user = $user->name;
$wiki->content = str_replace("\\","","");
if ($filename != "")
	$wiki->insert();

$swParsedContent .=  "<br/><a href='".$wiki->link("")."'>Image:$filename</a>";


?>