<?php

if (!defined("SOFAWIKI")) die("invalid acces");

$swParsedName = "Backup";
$swParsedContent = "";
$swParsedContent .= "Backup of SofaWiki site. <br/><br/>";



$zipfile = new zipfile();  

$emptydirectories = array();
$includeddirectories = array();

$emptydirectories[] = "sofawiki/site/cache"; 
$emptydirectories[] = "sofawiki/site/current";
$emptydirectories[] = "sofawiki/site/files";
$emptydirectories[] = "sofawiki/site/indexes";
$emptydirectories[] = "sofawiki/site/logs";
$emptydirectories[] = "sofawiki/site/queries";
$emptydirectories[] = "sofawiki/site/trigram";
$emptydirectories[] = "sofawiki/site/upload";

$includeddirectories[] = "sofawiki/site";
$includeddirectories[] = "sofawiki/site/functions";
// $includeddirectories[] = "sofawiki/site/logs";
// $includeddirectories[] = "sofawiki/site/current";
// $includeddirectories[] = "sofawiki/site/revisions";
$includeddirectories[] = "sofawiki/site/skins";

$files = array();


foreach($emptydirectories as $dir)
{
	$zipfile -> add_dir($dir."/",time());
	$swParsedContent .= "$dir<br/>";
}

foreach($files as $file)
{
	$zipfile -> add_file(file_get_contents($file), "sofawiki/$file", filemtime($file)); 
	$swParsedContent .= "&nbsp;$file<br/>";
}


foreach ($includeddirectories as $dir)
{
	$zipfile -> add_dir($dir."/",time());
	$swParsedContent .= "$dir<br/>";
	$dir = substr($dir,strlen("sofawiki/"));
	$absolutedir = $swRoot.'/'.$dir;
	
	$formats = array("php","css","txt");
	
	foreach ($formats as $f)
	{
		$files = glob($absolutedir."/*.$f");
		natsort($files);
		foreach($files as $file)
		{
			$zf = str_replace($swRoot,"sofawiki",$file);
			$zipfile -> add_file(file_get_contents($file), $zf,filemtime($file)); 
			$swParsedContent .= "&nbsp;$zf<br/>";
		}
	}
}

$today = date("Ymd",time());

$filename = "site".".zip";
$fd = fopen("$swRoot/bak/".$filename, "wb");
$out = fwrite ($fd, $zipfile -> file());
fclose ($fd);

$swParsedContent .=  "<br/>$filename";

$filename = "site$today".".zip";
$fd = fopen("$swRoot/bak/".$filename, "wb");
$out = fwrite ($fd, $zipfile -> file());
fclose ($fd);
	
$swParsedContent .=  "<br/>$filename";

// backup logs by month, do not if file already exists - one at a time

if (isset($_REQUEST['logs']))
{

	$swParsedContent .=  '<br/><br/>logs';
	
	$dir = $swRoot.'/site/logs';
	$files = glob($dir.'/*.txt');
	natsort($files);
	
	$zipfile = new zipfile();  
	
	foreach($files as $file)
	{
		$fn = str_replace($swRoot.'/site/logs/','',$file);
		$month = substr($fn,0,7);
		$currentmonth = date("Y-m",time());
		$ziptest = 'logs-'.$month.'.zip'; 
		if (file_exists($swRoot.'/bak/'.$ziptest) && $month != $currentmonth)
			continue;
		if (!isset($zip) || $zip == $ziptest)
		{
			$zip = $ziptest;
			$swParsedContent .=  '<br>'.$fn; 
			$zipfile -> add_file(file_get_contents($file), $fn,filemtime($file)); 
		}
		else
			continue;
	}
	if (isset($zip))
	{
		$fd = fopen($swRoot.'/bak/'.$zip, "wb");
		$out = fwrite ($fd, $zipfile -> file());
		fclose ($fd);
		$swParsedContent .=  "<br/><br/>$zip"; 
	}
}
else
{
	$swParsedContent .=  '<br/><br/>Add <a href="index.php?name=special:backup&logs=1">logs option</a>  option to URL to backup logs (best once per month)'; 
}

// revisions by thousands, do not if file already exists - one at a time


if (isset($_REQUEST['revisions']))
{


	$swParsedContent .=  '<br/><br/>revisions';
	
	$dir = $swRoot.'/site/revisions';
	$files = glob($dir.'/*.txt');
	natsort($files);
	
	$zipfile = new zipfile(); 
	unset($zip);
	
	foreach($files as $file)
	{
		$fn = str_replace($swRoot.'/site/revisions/','',$file);
		$thousand = (int)(str_replace('.txt','',$fn)/1000);
		$currentthousand = (int)($db->lastrevision/1000);
		$ziptest = 'revisions-'.$thousand.'000.zip'; 
		if (file_exists($swRoot.'/bak/'.$ziptest) && $thousand != $currentthousand)
			continue;
		if (!isset($zip) || $zip == $ziptest)
		{
			$zip = $ziptest;
			$swParsedContent .=  '<br>'.$fn; 
			$zipfile -> add_file(file_get_contents($file), $fn,filemtime($file)); 
		}
		else
			continue;
	}
	if (isset($zip))
	{
		$fd = fopen($swRoot.'/bak/'.$zip, "wb");
		$out = fwrite ($fd, $zipfile -> file());
		fclose ($fd);
		$swParsedContent .=  "<br/><br/>$zip"; 
	}
}
else
{
	$swParsedContent .=  '<br/><br/>Add <a href="index.php?name=special:backup&revisions=1">revisions option</a> to URL to backup revisions (best once per thousand)'; 
}

if (isset($_REQUEST['files']))
{


	$swParsedContent .=  '<br/><br/>files';
	
	$dir = $swRoot.'/site/revisions';
	$files = glob($dir.'/*.txt');
	natsort($files);
	
	$zipfile = new zipfile(); 
	unset($zip);
	
	foreach($files as $file)
	{
		$fn = str_replace($swRoot.'/site/revisions/','',$file);
		$thousand = (int)(str_replace('.txt','',$fn)/100);
		$currentthousand = (int)($db->lastrevision/100);
		$ziptest = 'files-'.$thousand.'00.zip'; 
		if (file_exists($swRoot.'/bak/'.$ziptest) && $thousand != $currentthousand)
			continue;
		if (!isset($zip) || $zip == $ziptest)
		{
			// lookup wiki, check if it is a file, add file to zip
			$r = new swRecord;
			$r->revision = str_replace('.txt','',$fn);
			$r->lookup();
			if ($r->wikinamespace() == 'Image')
			{
				$fn2 = substr($r->name,strlen('Image:'));
				$file2 = $swRoot.'/site/files/'.$fn2;
				$zip = $ziptest;
				$swParsedContent .=  '<br>'.$r->revision.' '.$fn2; 
				$zipfile -> add_file(file_get_contents($file2), $fn2,filemtime($file2)); 
			}
			else
			{
				//$swParsedContent .=  '<br>NOT '.$r->revision; 
			}
		}
		else
			continue;
	}
	if (isset($zip))
	{
		$fd = fopen($swRoot.'/bak/'.$zip, "wb");
		$out = fwrite ($fd, $zipfile -> file());
		fclose ($fd);
		$swParsedContent .=  "<br/><br/>$zip"; 
	}
}
else
{
	$swParsedContent .=  '<br/><br/>Add <a href="index.php?name=special:backup&files=1">files option</a> to URL to backup files (best once per hundred)'; 
}

?>