<?php

if (!defined("SOFAWIKI")) die("invalid acces");

$swParsedName = "Special:System Messages";

$names = $db->GetAllUrls();
uksort($names, 'strnatcasecmp'); 
//ksort($names);
$swParsedContent = "";
$oldfirst = "";
$oldshort = "";

$foundmessages=array();
$foundshorts=array();

$missing = "";
$pages = "";
$defaults = "";

foreach ($names as $n=>$s)
{
	if (substr(strtolower($n),0,7)=="system:")
	{
		
		$first = strtolower(substr($n,7,1));
		if ($oldfirst && $oldfirst != $first) $pages .= "\n\n";
		$shorts = split("/",$n);
		$short = $shorts[0];
		if ($short != $oldshort) $pages .= "\n"; else $pages .= " ";
		$shortname = substr($n,7);
		$pages .= "[[$n|$shortname]]";
		$foundmessages["$n"] = true;
		$foundshorts[$short] = true;
		$oldfirst = $first;
		$oldshort = $short;
 	}
}


uksort($swSystemDefaults ,'strnatcasecmp');

$oldfirst = "";
$oldshort = "";

foreach ($swSystemDefaults as $k=>$v)
{
		if (!array_key_exists("System:$k",$foundmessages))
		{
			$first = strtolower(substr($k,0,1));
			if ($oldfirst && $oldfirst != $first) $defaults .= "\n\n";
			$shorts = split("/",$k);
			$short = $shorts[0];
			if ($short != $oldshort) $defaults .= "\n\n"; else $defaults .= " ";
			$defaults .= "[[System:$k|$k]] $v ";
			$oldfirst = $first;
			$oldshort = $short;
		
		}
}
$oldfirst = "";
uksort($foundshorts,'strnatcasecmp');

foreach($foundshorts as $s=>$v)
{
	foreach ($swLanguages as $l)
	{
		if (!array_key_exists("$s/$l",$foundmessages))
		{
			
			$first = strtolower(substr($s,7,1));
			if ($oldfirst != "" && $oldfirst != $first) $missing .= "\n\n";
			$missing .="[[$s/$l]] ";
			$oldfirst = $first;
		}
	}
}


$swParsedContent .= "\n====Missing translations====\n$missing";


$swParsedContent .= "\n====Pages====\n$pages";

$swParsedContent .= "\n====Defaults====\n$defaults";


$swParseSpecial = true;



?>