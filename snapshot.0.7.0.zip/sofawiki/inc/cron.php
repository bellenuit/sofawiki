<?

if (!defined("SOFAWIKI")) die("invalid acces");


function swCron()
{
	
	if (function_exists('swInternalCronHook') && swInternalCronHook()) 
	{
		// everything is handled by configuration.php
	}
	else
	{
		// do some housework by default from time to time
	
		if (array_key_exists('trigram',$_REQUEST)) { swIndexTrigram($_REQUEST['trigram']); }
	
		switch(rand(0,100))
		{
			case 0: global $db; $db->init(true);  // rebuild indexes
			
			case 1: swIndexTrigram();
			
			case 2: swIndexRandomFields(3000);
			
			case 3 : swSitemap();
			
			default:
		
		}
	}
}



function swIndexRandomFields($maxtime)
{
	global $swMaxOverallSearchTime;
	$mrst = $swMaxOverallSearchTime;
	$swMaxOverallSearchTime=$maxtime;
	global $swSearchNamespaces;
	$ns = join(' ',$swSearchNamespaces);
	
	$q = swFilter('FIELDS',$ns,'data');
	$f = '';
	if (is_array($q))
	{
		$q = array_keys($q);
		shuffle($q);
		$f = array_pop($q);
	}
	if ($f != '')
	{
		$w = 'SELECT name WHERE '.$f.' *';
		$q2 = swFilter($w,$ns,'data');
	}

	$swMaxOverallSearchTime = $mrst;	
}


?>