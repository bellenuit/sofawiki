<?php

if (!defined("SOFAWIKI")) die("invalid acces");

class swFirstValueFunction extends swFunction
{

	function info()
	{
	 	return "(field,template) gets the first value of a field in a page";
	}

	
	function dowork($args)
	{

		// uses ../utilities.php
		
		

		global $name;	
		$field = $args[1];
		
		if (count($args)>2)	
			$template = $args[2];
		else
			$template = '';
		
	
		global $wiki;
		

		$list = $wiki->internalfields[$field];
		
		
		$elem = $list[0];
		
			if ($elem != "" )
			{
				if ($template != "")
					$result = '{{'.$template.'|'.$elem.'}}';
				else
					$result = $elem;
			}		
		
		return $result;	
	}

}

$swFunctions["firstvalue"] = new swFirstValueFunction;


?>