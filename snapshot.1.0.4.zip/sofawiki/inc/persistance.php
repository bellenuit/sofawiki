<?php 

// This file must be text encoding UTF8 no BOM not to get problems with cookies

if (!defined('SOFAWIKI')) die('invalid acces');


class swPersistance 
{ 
    var $persistance; 
        
    /**********************/ 
    function save() 
    { 
        $s = serialize(get_object_vars($this));
        //echotime($s);
        if($f = @fopen($this->persistance,"w")) 
        { 
            @flock($f, LOCK_EX);
            @fwrite($f,$s); 
            @flock($f, LOCK_UN);
            @fclose($f); 
            
        }  
        else echotime("Could not open file ".$this->persistance." for writing, at Persistant::save"); 
        
        
    } 
    /**********************/ 
    function open() 
    { 
        $vars = array();
        if (file_exists($this->persistance))
        {
       	 	$vars = unserialize(@file_get_contents($this->persistance)); 
       		if (!$vars) 
       		{
       			echotime("Could not open file ".$this->persistance." for reading, at Persistant::open"); 
       		}
       		
       		 	
        }
        //echotime(print_r($vars,true));
        if (!$vars)  return false;
        foreach($vars as $key=>$val) 
        {            
			$this->{$key} =$vars[$key];
        } 
        return true;
    } 
    /**********************/ 
} 

?>