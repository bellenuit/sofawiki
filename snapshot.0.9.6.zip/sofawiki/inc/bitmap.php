<?php


if (!defined("SOFAWIKI")) die("invalid acces");


class swBitmap extends swPersistance 
{
	var $length;
	var $map;
	var $touched;
	
	function init($l, $default = false)
	{
		//creates the bit string, filled with default value
		$this->length = $l;
		$bytes = ($l + 7) >> 3;
		if ($default)
			$this->map = str_repeat(chr(255),$bytes);
		else
			$this->map = str_repeat(chr(0),$bytes);
	}
	
	function redim($l, $default = false)
	{
		$this->length = max($l,$this->length);
		$bytes = ($this->length + 7) >> 3;
		$thisbytes = strlen($this->map);
		if ($bytes <= $thisbytes) return;  // can only grow.
		
		if ($default)
			$this->map = str_pad($this->map,$bytes,chr(255));
		else
			$this->map = str_pad($this->map,$bytes,chr(0));
	}
	
	function setbit($n)
	{
		if ($n<0) return; 
		$this->touched = true;
		
		if ($n>=$this->length)
			$this->redim($n+1);
		
		// sets nth bit to true
		$byte = $n >> 3;
		$bit = $n - ($byte << 3);
		$bitmask = 128 >> $bit;

		$ch = $this->map[$byte];
		$ch = ord($ch);
		$ch = $ch | $bitmask;
		$ch = chr($ch);
		$this->map[$byte] = $ch;
	}
	
	function unsetbit($n)
	{
		if ($n<0) return; 
		$this->touched = true;
		
		if ($n>=$this->length)
			$this->redim($n+1);

		// sets nth bit to false  
		$byte = $n >> 3;
		$bit = $n - ($byte << 3);
		$bitmask = 128 >> $bit;
		$bitmask = ~ $bitmask;
		
		$ch = $this->map[$byte];
		$ch = ord($ch);
		$ch = $ch & $bitmask;
		$ch = chr($ch);
		$this->map[$byte] = $ch;		
	}
	
	function getbit($n)
	{
		if ($n>=$this->length) return false;
		if ($n<0) return false;
		
		// gets the value of the nth bit
		$byte = $n >> 3;
		$bit = $n - ($byte << 3);
		$bitmask = 128 >> $bit;
		
		$ch = $this->map[$byte];
		$ch = ord($ch);
		$ch = $ch & $bitmask;
		if ($ch) 
			return true;
		else
			return false;
	}
	
	function getnext($n)
	{
		// returns the offset of the next bit set to true after n, or false.
	}
	
	function duplicate()
	{
		$result = new swBitmap;
		$result->length = $this->length;
		$result->map = $this->map; // copy? non mutable?
		$result->touched = true;
		return $result;
	}
	
	function andop($bitmap)
	{
		// returns a bitmap as result of AND between this and bitmap
		$s1 = $this->map;
		$s2 = $bitmap->map;
		
		$pl=strlen($s1);
		if (strlen($s1) != strlen($s2))
		{
			$pl = max(strlen($s1),strlen($s2));
			$s1 = str_pad($s1,$pl,chr(0));
			$s2 = str_pad($s1,$pl,chr(0));
		}
		
		$s3 = $s1 & $s2;
		
		$result = new swBitmap;
		$result->length = $pl*8;
		$result->map = $s3;
		$result->touched = true;
		return $result;
	}
	
	function orop($bitmap)
	{
		// returns a bitmap as result of OR between this and bitmap
		$s1 = $this->map;
		$s2 = $bitmap->map;

		$pl=strlen($s1);
		if (strlen($s1) != strlen($s2))
		{
			$pl = max(strlen($s1),strlen($s2));
			$s1 = str_pad($s1,$pl,chr(0));
			$s2 = str_pad($s1,$pl,chr(0));
		}

		$s3 = $s1 | $s2;
		
		$result = new swBitmap;
		$result->length = $pl*8;
		$result->map = $s3;
		$result->touched = true;
		return $result;
	}
	
	function notop()
	{
		$result = new swBitmap;
		$result->redim($this->length, true);
		$map = $result->map ^ $this->map;
		$result->map = $map;
		$result->touched = true;
		return $result;
	}
	
	function dump()
	{
		// returns bit string in groups of 8
		$result = '';
		$c = strlen($this->map);
		for($i=0;$i<$c;$i++)
		{
			$ch = $this->map[$i];
			$ch = ord($ch);
			$result .= sprintf('%08d',decbin($ch)).' ';
		}
		return $result;
	}
	
	function countbits()
	{
		// Counting bits set, Brian Kernighan's way
		// http://graphics.stanford.edu/~seander/bithacks.html#CountBitsSetKernighan
		
		$bytes = ($this->length + 7) >> 3;
		$c = 0;
		for($i=0; $i<$bytes;$i++)
		{
			$ch = substr($this->map,$i,1);
			$v = ord($ch);
			
			while ($v)
			{
				$v &= $v - 1;
				$c++;
			}
			
		}
		return $c;
	}
	
	function toarray()
	{
		$result = array();
		for($i=0;$i<$this->length;$i++)
		{
			if ($this->getbit($i))
				$result[$i] = $i;
		}
		return $result;
	}

	
}



?>