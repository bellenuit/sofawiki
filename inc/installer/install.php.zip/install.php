<?php
	
/*  
   Sofawiki install script
   3.0.3 27.5.2020
*/

if (file_exists('index.php')) die('invalid access: index.php exists already');

$swRoot = dirname(__FILE__); // must be first

function swGetArrayValue($array,$key,$default='')
{
	if (array_key_exists($key,$array))
		return $array[$key];
	else
		return $default;
}

function url(){
    if(isset($_SERVER['HTTPS'])){
        $protocol = ($_SERVER['HTTPS'] && $_SERVER['HTTPS'] != "off") ? "https" : "http";
    }
    else{
        $protocol = 'http';
    }
    return $protocol . "://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
}

function urlbase()
{
	$url = url();
	$list = explode('/',$url);
	array_pop($list);
	return join('/',$list).'/';
}


function wgets($FromLocation,$ToLocation)
{

 $VerifyPeer=false; $VerifyHost=false; 
// Initialize CURL with providing full https URL of the file location
$Channel = curl_init($FromLocation);
 
// Open file handle at the location you want to copy the file: destination path at local drive
$File = fopen ($ToLocation, 'w');
 
// Set CURL options
curl_setopt($Channel, CURLOPT_FILE, $File);
 
// We are not sending any headers
curl_setopt($Channel, CURLOPT_HEADER, 0);
 
// Disable PEER SSL Verification: If you are not running with SSL or if you don't have valid SSL
curl_setopt($Channel, CURLOPT_SSL_VERIFYPEER, $VerifyPeer);
 
// Disable HOST (the site you are sending request to) SSL Verification,
// if Host can have certificate which is invalid / expired / not signed by authorized CA.
curl_setopt($Channel, CURLOPT_SSL_VERIFYHOST, $VerifyHost);
 
// Execute CURL command
curl_exec($Channel);
 
// Close the CURL channel
curl_close($Channel);
 
// Close file handle
fclose($File);
 
// return true if file download is successfull
return file_exists($ToLocation);
}

function rglob($pattern)
{
	// used non recursive solution
	$patternlist = array($pattern);
	$donelist = array();
	$list = array();
	while (count($patternlist)>0)
	{
		$p = array_shift($patternlist);
		$donelist[$p] = true;
		$files = glob($p);
		if (!is_array($files)) $files = array();
		if (count($files)>0)
		{
			foreach ($files as $f)
			{	
				$list[$f] = $f;
				$nextpattern = $f."/*";
				if (!isset($donelist[$nextpattern]))
				$patternlist[] = $nextpattern;
			}
		}
		
	}
	asort($list);
	return $list;
}

function unzip($file,$destination)
{
	
	$zip = zip_open($file);
	if (is_resource($zip))
	{
	  while ($zip_entry = zip_read($zip)) 
	  {
		$name = zip_entry_name($zip_entry);
		if(strpos($name, '.'))
		{
			if (zip_entry_open($zip, $zip_entry, 'r')) 
			{
			  $fp = fopen($destination.'/'.zip_entry_name($zip_entry), 'w');
			  $buf = zip_entry_read($zip_entry, zip_entry_filesize($zip_entry));
			  fwrite($fp,$buf);
			  zip_entry_close($zip_entry);
			  fclose($fp);
			}
		}
		else
			@mkdir($destination.'/'.$name);
	  }
	  zip_close($zip);
	}
}	

$file = swGetArrayValue($_REQUEST,'file');
$n = "";
$dl = '';
if (swGetArrayValue($_REQUEST,'submitdownload',false) && $file !='')
{
	$serverfile = 'https://www.sofawiki.com/site/files/'.$file;
	$localfile = $swRoot.'/'.$file;
	if (wgets($serverfile,$localfile))
		$dl = '<p><i>Downloaded '.$file.' to '.$localfile.'</i>';
	else
		$dl = '<p><i>Download failed.</i>';
}
if (swGetArrayValue($_REQUEST,'submitdecompress',false) && $file !='')
{
	@mkdir($swRoot.'/install/');
	unzip($swRoot.'/'.$file,$swRoot.'/install/');
	$n = 'decompressed '.$file;
}
if (swGetArrayValue($_REQUEST,'submitinstall',false))
{
	
	@mkdir($swRoot.'/inc/');
	$files = rglob($swRoot.'/install/sofawiki/inc/*');
	echo "<h1>SofaWiki Installation</h1>";
	foreach ($files as $f)
	{
		$newfile = str_replace($swRoot.'/install/sofawiki/',$swRoot.'/',$f);
		
		if ( is_dir($f) )
		{
			@mkdir($newfile);
			@chmod($newfile,0755);
			echo '<p>mkdir '.$newfile;
		}
		elseif (rename($f,$newfile)   )
		{
			chmod($newfile,0755);
			echo '<p>rename '.$newfile;  
		}
		else
		{ 
			if( file_exists($f) )
				echo '<p><b>error</b> rename '.$newfile; 
			// else it was probably already used
		}
	}
	
	if (rename($swRoot.'/install/sofawiki/api.php',$swRoot.'/api.php'))
	{ chmod($swRoot.'/api.php',0755);
	echo '<p>rename api.php'; }
	else
	{ echo '<p><b>error</b> rename api.php'; }
	if (rename($swRoot.'/install/sofawiki/index.php',$swRoot.'/index.php') )
	{ 	chmod($swRoot.'/index.php',0755);
		echo '<p>rename index.php'; }
	else
	{ echo '<p><b>error</b> rename index.php'; } 
	if (rename($swRoot.'/install/sofawiki/cron.php',$swRoot.'/cron.php') )
	{ chmod($swRoot.'/cron.php',0755);
		echo '<p>rename cron.php'; }
	else
	{ echo '<p><b>error</b> rename cron.php'; }
	
	
	$files = rglob($swRoot.'/install/*'); 
	if (!is_array($files)) $files = array();
	arsort($files);
	$files[] = $swRoot.'/install';
	foreach ($files as $f)
	{	
		@unlink($f);
		@rmdir($f);
		echo '<p>remove '.$f;
	}
	
	die('<p>Installation complete. <a href="index.php">Configure website</a>');
}




if (isset($_REQUEST['submitfolderrights']))
{
	@chmod($swRoot.'/site/', 0755);
	@chmod($swRoot.'/site/cache/', 0755);
	@chmod($swRoot.'/site/current/', 0755);
	@chmod($swRoot.'/site/files/', 0755);
	@chmod($swRoot.'/site/functions/', 0755);
	@chmod($swRoot.'/site/indexes/', 0755);
	@chmod($swRoot.'/site/logs/', 0755);
	@chmod($swRoot.'/site/queries/', 0755);
	@chmod($swRoot.'/site/revisions/', 0755);
	@chmod($swRoot.'/site/skins/', 0755);
	@chmod($swRoot.'/site/trigram/', 0755);
	@chmod($swRoot.'/site/upload/', 0755);
}

if (isset($_REQUEST['submitconfiguration']))
{
	$s = file_get_contents($swRoot.'/inc/configuration.php');
	$s = str_replace('{{{swmainname}}}',$_REQUEST['swmainname'],$s);
	$s = str_replace('{{{swbasehrefolder}}}',$_REQUEST['swbasehrefolder'],$s);
	$s = str_replace('{{{encryptionsalt}}}',$_REQUEST['encryptionsalt'],$s);

	
	$u = new swUser;
	$u->name = 'User:'.$_REQUEST['powerusername'];
	$u->pass = $_REQUEST['poweruserpass'];
	$db->salt = $_REQUEST['encryptionsalt'];
	$pp = $u->encryptpassword();
	//$pp = $_REQUEST['poweruserpass'];
	
	
	$s = str_replace('{{{powerusername}}}',$_REQUEST['powerusername'],$s);
	$s = str_replace('{{{poweruserpass}}}',$pp,$s);
	
	
	
	
	$s = str_replace('{{{swlang}}}',$_REQUEST['swlang'],$s);
	$s = str_replace('{{{swskin}}}',$_REQUEST['swskin'],$s);
	file_put_contents($swRoot.'/site/configuration.php', $s);
	chmod($swRoot.'/site/configuration.php', 0755);
	
	// reload
	header("Location: index.php?action=login");
	exit;
	
}



$swParsedName = 'SofaWiki Installation';
$swParsedContent = 'Welcome to SofaWiki.
Please complete your installation now.';

$langlist = array('en','de','fr','it','es','dk');
$langoptions = '';
foreach ($langlist as $f)
{	
	if ($f !=  "")
	$langoptions .= "<option value='$f'>$f</option>";
}

$skinlist = array('default','tribune','iphone','zeitung','wiki','diary','law','utf8','debug','ps');

$skinoptions = '';
foreach ($skinlist as $f)
{	
	if ($f !=  "")
	$skinoptions .= "<option value='$f'>$f</option>";
}


$sitefolderrights =substr(sprintf('%o',fileperms('.')),-3);
if ($sitefolderrights < 0755)


$swParsedContent .= '
<p>Set the folder rights for the site folder and its subfolders (now '.$sitefolderrights.'; should be 0755)
<br><form method="post" action="index.php"><input type="submit" name="submitfolderrights" value="Try to fix" />
<br>If Try to fix does not work, do it manually with the FTP tools';

else
$swParsedContent .= '
<p>Folder rights seem ok ('.$sitefolderrights.').
<h4>Download the code into this folder</h4>';

$swParsedContent .= '<p>Available versions</p>';

$serverfile = "https://www.sofawiki.com/site/files/snapshot.txt";
$localfile = 'snapshot.txt';

wgets($serverfile,$swRoot.'/'.$localfile);

$filelist = explode("\n",file_get_contents('snapshot.txt'));

$swParsedContent .= "\n<form method='get' action='install.php'><p>";
$swParsedContent .= "\n<select name='file'>";
arsort($filelist);
foreach ($filelist as $f)
{	
	if ($f !=  "")
	$swParsedContent .= "<option value='$f'>$f</option>";
}
$swParsedContent .= "\n</select>";
$swParsedContent .= "\n<input type='hidden' name='name' value='special:update'>";
$swParsedContent .= "\n<input type='submit' name='submitdownload' value='Download' />";
$swParsedContent .= "\n</p></form>";

$swParsedContent .= $dl;

$swParsedContent .= '<h4>Decompress the Zip File</h4>';


$files = glob("$swRoot/snapshot*.zip");

if (count($files)>0)
{
	$swParsedContent .= "<p>Downloaded versions</p>";

	$swParsedContent .= "\n<form method='get' action='install.php'><p>";
	$swParsedContent .= "\n<select name='file'>";
	arsort($files);
	foreach ($files as $f)
	{	
		$f = str_replace("$swRoot/","",$f);
		$swParsedContent .= "<option value='$f'>$f</option>";
	}
	$swParsedContent .= "\n</select>";
	
	$swParsedContent .= "\n<input type='hidden' name='name' value='special:update'>";
	$swParsedContent .= "\n<input type='submit' name='submitdecompress' value='Decompress' />";
	$swParsedContent .= "\n</p></form>";
}



$files = rglob("$swRoot/install/*");


if (count($files)>0)
{
	$swParsedContent .= "<p>Decompressed files</p>";
	
	foreach ($files as $f)
	{	
		$swParsedContent .= "$f\n";
	}

	$swParsedContent .= '<h4>Install Sofawiki</h4>';
	
	$swParsedContent .= "\n<form method='get' action='install.php'><p><pre>";
	$swParsedContent .= "\n</pre><input type='hidden' name='name' value='special:update'>";
	$swParsedContent .= "\n<input type='submit' name='submitinstall' value='Install' style='color:red'/>";
	$swParsedContent .= "\n</p></form>";
}


/*
$swParsedContent .='
<h4>Install Sofawiki with basic configuration</h4>
<p>Here are the basic settings to get you running. You can change these and other settings later manually the site/configuration.php file.
<form method="post" action="index.php">
<table>
<tr>
<td>swMainName</td>
<td><input type="text" name="swmainname" size=40 value="SofaWiki"></td> 
</tr><tr>
<td>swBaseHrefFolder</td>
<td><input type="text" name="swbasehrefolder" size=40 value="'.urlbase().'"></td>
</tr><tr>
<td>poweruser name</td>
<td><input type="text" name="powerusername" size=40 value="admin"></td>
</tr><tr>
<td>poweruser pass</td>
<td><input type="text" name="poweruserpass" size=40 value="'.rand(100000,999999).'"></td>
<input type="hidden" name="encryptionsalt" size=40 value="'.rand(1000,9999).'">
</tr><tr>
<td>default lang</td>
<td><select name="swlang">'.$langoptions.'</select></td>
</tr><tr>
<td>default skin</td>
<td><select name="swskin">'.$skinoptions.'</select></td>
</tr><tr>
<td colspan=2><input type="submit" name="submitconfiguration" value="Install" /><br></td> 
</tr>
</table>
</form>
<h4>Login</h4>
<h4>Write main page</h4>

<p>SofaWiki documentation <a href="https://www.sofawiki.com/" target="_blank"">https://www.sofawiki.com/</a>';
*/


//$swParsedContent = $wiki->parse();

echo '<h1>'.$swParsedName.'</h1>';
echo '<p>'.$swParsedContent;

?>