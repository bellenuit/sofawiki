<?php

if (!defined("SOFAWIKI")) die("invalid acces");



class swFunction
{
	
		
	function info()
	{
		// stub
		return "generic";
	}
	
	function dowork($args)
	{
		// stub
		return " generic";
	}
}

?>