<?php

if (!defined("SOFAWIKI")) die("invalid acces");

class swLangParser extends swParser
{

	function info()
	{
	 	return "Redirects to language subpages, if available";
	}



	function dowork(&$wiki)
	{
		
	
		$s = $wiki->parsedContent;
		global $lang;
		
		
		
		if ($lang)
		{
			$myname = $wiki->name;
			if (substr($myname,-3,1) == "/")
				$myname2 = substr($myname,0,3); // ??
			else
				$myname2 = $myname."/".$lang;
				
			$redirectedfrom = $wiki->redirectedfrom;
			
			
			if ($revision = swGetCurrentRevisionFromName($myname2))
			{
				
				
				$wiki->revision = $revision;
				$wiki->lookup();
				
			}
		}
		
			
		$wiki->parsedContent = "$wiki->content"; 
		
		
	}

}

$swParsers["lang"] = new swLangParser;


?>