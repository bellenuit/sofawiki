<?php

if (!defined("SOFAWIKI")) die("invalid acces");

class swRedirectionParser extends swParser
{
	function info()
	{
	 	return "Handles redirection keyword #REDIRECT";
	}

	
	
	function dowork(&$wiki)
	{
		
	
		$s = $wiki->parsedContent;
		$key = "#REDIRECT"; 
		
		if (substr($s,0,strlen($key))==$key)
		{
			
			$myname = $wiki->name;
			$pos = strpos($s,"[[") + strlen("[[");
			$pos2 = strpos($s,"]]",$pos);
			
			$wiki->name = substr($s,$pos,$pos2-$pos);
			$wiki->revision = NULL;
			$wiki->lookup();
					
			global $swRedirectedFrom;
			$swRedirectedFrom = $myname;
			$wiki->parsedContent = 	"$wiki->content"; 	
			
			// edit menu 
			
			
		}
		
		
		
	}

}

$swParsers["redirection"] = new swRedirectionParser;


?>