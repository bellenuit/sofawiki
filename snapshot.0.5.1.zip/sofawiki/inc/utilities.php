﻿<?php


if (!defined("SOFAWIKI")) die("invalid acces");


function swQuerySplit($s)
{
	// split on space, but preserve [[field::value space]]
	
	return split(" ",$s);
}

function swStrReplace($pattern, $replace, $s)
{
	// use lowercase, uppercase and titlecase
	$patterns = array();
	$patterns[] = $pattern;
	$patterns[] = strtoupper($pattern);
	$patterns[] = strtolower($pattern);
	$patterns[] = strtoupper(substr($pattern,0,1)).substr($pattern,1);

	foreach ($patterns as $p)
	{
		$r = str_replace($pattern,$p,$replace);
		$s = str_replace($p,$r,$s);
	}
	return $s;	
}

function swGetValue($s, $key, $getArray = false)
{
	$pattern = "[[$key::";
	$results = array();
	$result = "";
	$pos = true;
	while ($pos !== FALSE)
	{
		$pos = strpos($s, $pattern);
		if ($pos !== FALSE)
		{
			$pos0 = $pos + strlen($pattern);
			$pos2 = strpos($s,"]]",$pos0);
			if ($pos2 !== FALSE)
			{
				$result = substr($s,$pos0, $pos2-$pos0);
				
				// remove pipe character
				$pos3 = strpos($result,"|");
				if ($pos3 !== FALSE )
					$result = substr($result,0,$pos3);
				
				
				if (!$getArray)
					return $result;
				$results[] = $result;
			}
		}
		$s = substr($s,$pos+1); 
		
	}
	if (!$getArray)
		return $result;
	return $results;
	
}

function swValidate($v,$invalidcharacters)
{
	$l = strlen($invalidcharacters);
	$i=0;
	for ($i==0;$i<$l;$i++)
	{
		if (strstr($v,substr($invalidcharacters,$i,1))) return false;
	}
	return true;
}



function swNameURL($name)
{
	$s = $name;
	
	// replace spaces by underscores 
	$s = str_replace(" ","_",$s);
	// replace special characters
	$s = str_replace("´","_",$s);
	$s = str_replace("'","_",$s);
	// replace german umlauts
	$s = str_replace("ä","ae",$s);
	$s = str_replace("æ","ae",$s);
	$s = str_replace("ö","oe",$s);
	$s = str_replace("ø","oe",$s);
	$s = str_replace("œ","oe",$s);
	$s = str_replace("ü","ue",$s);
	$s = str_replace("Ä","Ae",$s);
	$s = str_replace("Ö","Oe",$s);
	$s = str_replace("Ü","Ue",$s);
	
	// slow
	
	/*
	$strfrom = array('à','á','â','ã','ä','ç',
	'è','é','ê','ë','ì','í','î','ï','ñ','ò','ó','ô',
	'õ','ö','ù','ú','û','ü','ý','ÿ',
	'À','Á','Â','Ã','Ä','Ç','È','É','Ê','Ë','Ì','Í','Î','Ï','Ñ',
	'Ò','Ó','Ô','Õ','Ö','Ù','Ú','Û','Ü','Ý');
	
	$strto = array('a','a','a','a','a','c',
	'e','e','e','e','i','i','i','i','n',
	'o','o','o','o','o','u','u','u','u','y','y',
	'A','A','A','A','A','C','E','E','E','E','I','I','I','I','N',
	'O','O','O','O','O','U','U','U','U','Y');
	
	$s = str_replace($strfrom,$strto,$s);
	
	*/
	$swNameURLstrtable = array("à"=>"a","á"=>"a","â"=>"a","ã"=>"a","ä"=>"a",
	"ç"=>"c",
	"è"=>"e","é"=>"e","ê"=>"e","ë"=>"e",
	"ì"=>"i","í"=>"i","î"=>"i","ï"=>"i",
	"ñ"=>"n",
	"ò"=>"o","ó"=>"o","ô"=>"o","õ"=>"o","ö"=>"o",
	"ù"=>"u","ú"=>"u","û"=>"u","ü"=>"u","ý"=>"y","ÿ"=>"y",
	"À"=>"A","Á"=>"A","Â"=>"A","Ã"=>"A","Ä"=>"A",
	"Ç"=>"C",
	"È"=>"E","É"=>"E","Ê"=>"E","Ë"=>"E",
	"Ì"=>"I","Í"=>"I","Î"=>"I","Ï"=>"I",
	"Ñ"=>"N",
	"Ò"=>"O","Ó"=>"O","Ô"=>"O","Õ"=>"O","Ö"=>"O",
	"Ù"=>"U","Ú"=>"U","Û"=>"U","Ü"=>"U","Ý"=>"Y");

	
	$s = strtr($s,$swNameURLstrtable);
	
	// now replace anything else left with underscore
	
	$s = preg_replace("@[^-a-zA-Z0-9/:.-_]@","_",$s);
	
    // Capitalize First letter
	$s = strtoupper(substr($s,0,1)).substr($s,1);
	// Capitalize First letter if there is a Name Space
	if (stristr($s,":"))
	{
		$p = strpos($s,":");
		$s = substr($s,0,$p+1).strtoupper(substr($s,$p+1,1)).substr($s,$p+2);
	}
	
	// Remove double __
	$s = str_replace("__","_",$s);
	$s = str_replace("__","_",$s);
	
	// echo "<p>$name : $s";
		
	return $s;
	
}



?>