<?php

if (!defined("SOFAWIKI")) die("invalid acces");


function handleCookie($id, $wiki)
{
	$result = "";
	$key= $wiki."/".$id;
	if (array_key_exists($key, $_COOKIE)) 
	{
		
		$result =  $_COOKIE[$key];
	}
	if (array_key_exists($id, $_GET)) 
	{
		$result =  $_GET[$id];
		$cs = setcookie($key, $result, time() + 9000000 , "/"); 
	}
	if (array_key_exists($id, $_POST)) 
	{
		$result =  $_POST[$id];
		$cs = setcookie($key, $result, time() + 9000000 , "/"); 
	}
	return $result;
}


$lang = handleCookie("lang",$swMainName);
$skin = handleCookie("skin",$swMainName);

function addHistory($name)
{
	
	
	
	$key= $wiki."/history";
	$history = $_COOKIE[$key];
	
	$histories = explode("|",$history);
	foreach($histories as $v)
	{
		$i++;
		if (count($histories)-$i > 8) continue;
		if ($v != $name) $histories2[] = $v;
		
	}

	$histories2[] = $name;
	$history = join("|",$histories2);

	$cs = setcookie($key, $history, time() + 9000000 , "/"); 
	
	return $histories2;
}






?>