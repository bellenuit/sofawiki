<?php

/*
SOFA DB
- document oriented database inspired from couchdb but using semantic metawiki syntax
- the database has no tables and no predefined fields.
- fields are declared inline using the semantic mediawiki syntax [[fieldname::value]]
  fieldnames cannot start with an underscore
- multiple occurences of the same field are allowed
- the records are self-contained
- the records are stored as revisioned files adding a header with the reserved fields 
  _id automatically generated integer
  _revision automatically generated integer
  _name the wiki name, can change over time
  _timestamp sever time
  _status ok, request, protected, deleted
- the filename is the revision. the written files are never changed afterwards.
- on insertion of a new revision, the database writes some indexes. 
  these indexes are for performance only, they can be rebuild whenever needed from scratch
  - index to find the most recent ok revision of an id (or discard it if there is a more recent delete)
  - index for each field
  - fulltext index wordbased on each field
- queries can be done
  - individually return a sdRecord by id, by revision or by name
  - return a list of all revisions of an id
  - return a list of all revisions (or only current ids) that are conform to a filter
    filter use regex and are applied on all revisions.
    the filter results are saved, so that the next time only new revisions have to be applied for the same filter
    - filename as md5 of request
    - fields _query, _maxrevision, _timestamp
    
REQUIREMENTS
- php needs write access to the folders parsers, queries and revisions
 
*/


if (!defined('SOFAWIKI')) die('invalid acces');

function swGetAllRevisionsFromName($name)
{	
	global $db;
	$url = swNameURL($name);
	$first = substr($url,0,1);

	$revisions = swFilter("SELECT name, revision WHERE name ~* $first",'*','data','all deleted');

	$list = array();
	foreach ($revisions as $row)
	{
		$name = $row['name'][0];
		if (swNameURL($name) ==  $url) 
			$list[] = $row['revision'][0];
	}
	return $list;
}

function swFindURL($filter)
{
	global $swRoot;
	$path = $swRoot.'/site/indexes/urls.txt';
	$result = array();
	if (file_exists($path))
	{
		echotime('findurl '.$filter);
		$lines = file($path,FILE_IGNORE_NEW_LINES || FILE_SKIP_EMPTY_LINES);
		if (count($lines)==0)
			$lines = file($path.'.bak',FILE_IGNORE_NEW_LINES || FILE_SKIP_EMPTY_LINES);
		
		foreach($lines as $line)
		{
			$fields = explode("\t",$line);
			$r = $fields[0];
			$n = $fields[1];
			if (stristr($n,$filter)) 
				$result[$r] = rtrim($n);
		}
	}
	
	return $result;
}

function swFindNames($revisions)
{
	global $swRoot;
	$path = $swRoot.'/site/indexes/urls.txt';
	$result = array();
	if (file_exists($path))
	{
		echotime('findnames');
		$lines = file($path,FILE_IGNORE_NEW_LINES || FILE_SKIP_EMPTY_LINES);
		foreach($lines as $line)
		{
			$fields = explode("\t",$line);
			$r = $fields[0];
			$n = $fields[1];
			if (isset($revisions[$r])) 
				$result[$r] = rtrim($n);
		}
	}
	return $result;
}

function swGetPath($revision)
{
	if (is_array($revision))
		{
			debug_print_backtrace();
			exit;
		}
	
	global $swRoot;
	return $swRoot.'/site/revisions/'.$revision.'.txt';
}


class swDB extends swPersistance //extend may be obsolete
{
	
	
	var $currentbitmap;
	var $deletedbitmap; 
	var $protectedbitmap;
	
	var $salt;
	var $hasindex = false;
	var $lastrevision = 0;
	var $persistance2 = '';
	var $trigrams = array();
	var $inited = false;
	var $updatedrevisions = array();
	
	function init($force = false)
	{
		global $swRoot; 
		global $swMaxRelaxedSearchTime;
 
		if ($force)
		{
			$swMaxRelaxedSearchTime = 10000;
			$this->inited = false;
		}

		if ($this->hasindex)
			return;
		echotime("init"); 
		
		if ($this->inited)
			return;
		$this->inited = true;
		
		$this->lastrevision = 0; 
		
		global $swRoot;
		$file = $swRoot.'/site/indexes/lastrevision.txt';
		if (file_exists($file))
			$this->lastrevision = file_get_contents($file);
		else
			$this->lastrevision = 0;
			
		$this->currentbitmap = new swBitmap;
		$this->currentbitmap->hasbak = true;
		$this->currentbitmap->persistance = $swRoot.'/site/indexes/currentbitmap.txt';
		if (file_exists($this->currentbitmap->persistance))
			$this->currentbitmap->open();
		else
			$this->currentbitmap->init(0);
			
		$this->deletedbitmap = new swBitmap;
		$this->deletedbitmap->hasbak = true;
		$this->deletedbitmap->persistance = $swRoot.'/site/indexes/deletedbitmap.txt';
		if (file_exists($this->deletedbitmap->persistance))
			$this->deletedbitmap->open();
		else
			$this->deletedbitmap->init(0);
			
		$this->protectedbitmap = new swBitmap;
		$this->protectedbitmap->hasbak = true;
		$this->protectedbitmap->persistance = $swRoot.'/site/indexes/protectedbitmap.txt';
		if (file_exists($this->protectedbitmap->persistance))
			$this->protectedbitmap->open();
		else
			$this->protectedbitmap->init(0);
			
		echotime("lastrev ".$this->lastrevision);
		
		if ($this->lastrevision == 0 || $force)
		{
			echotime ('last 0');
			$lastwrite = $this->GetLastRevisionFolderItem();
			echotime('glob '.$lastwrite);
			
			if ($this->lastrevision < $lastwrite)
			{
				$this->RebuildIndexes($lastwrite);
				$this->inited = true;
			}
			else
			{
				$this->hasindex = true;
			}
			return;
		}
		return;
				
		
	}
	
	function close()
	{
		echotime("close");
		
		if ($this->currentbitmap->touched)
		{
			$this->currentbitmap->touched = false;
			$this->currentbitmap->save();
		}
		if ($this->deletedbitmap->touched)
		{
			$this->deletedbitmap->touched = false;
			$this->deletedbitmap->save();
		}
		if ($this->protectedbitmap->touched)
		{
			$this->protectedbitmap->touched = false;
			$this->protectedbitmap->save();
		}
	
		global $swRoot; 
		$path = $swRoot. '/site/indexes/lastrevision.txt';
		if ($handle = fopen($path, 'w')) { fwrite($handle, $this->lastrevision); fclose($handle); }
		else { swException('Write error lastrevision.txt'); return;}
	}
	
	function UpdateIndexes($rev)
	{
		$r = new swRecord;
		$r->revision = $rev;
		$r->lookup(true);

		$this->lastrevision = max($rev,$this->lastrevision);

		if ($r->status == 'deleted')
			$this->deletedbitmap->setbit($rev);
		if ($r->status == 'protected')
			$this->protectedbitmap->setbit($rev);
			
		if (isset($this->updatedrevisions[$rev])) return; // do not twice in a request
		$this->updatedrevisions[$rev]=1;
		
		$url = swNameURL($r->name);
		$line = $rev."\t".$url.PHP_EOL;
		
		global $swRoot;
		$path = $swRoot.'/site/indexes/urls.txt';
		
		// do not update if it is already in the index
		$s = (@file_get_contents($path));
		if (stristr($s,$line)) return;
		
				
		if ($f = @fopen($path,"a+"))
		{
			@fwrite($f, $line);
			@fclose($f); 
		}
		else
		{
		  { swException('Write error urls.txt'); return;}
		}
		
		// create backup
		copy($path,$path.'.bak');

	}
	
	function GetLastRevisionFolderItem()
	{
		global $swRoot;
		$path = $swRoot.'/site/revisions';
		$maxf = 0; 
		
		$dir = opendir($path);
		while($file = readdir($dir))
    	{
			if($file != '..' && $file != '.')
			{
				if (substr($file,-4)=='.txt')
				{
					$f = (int)(substr($file,0,-4));
					$maxf = max($f,$maxf);
				}
			}
		}
		return $maxf;
	}
	
	
	function RebuildIndexes($lastindex=0)
	{
		if ($lastindex==0)
			$lastindex = $this->lastrevision;
		
		echotime("rebuild");  
		
		global $swMaxRelaxedSearchTime;
		if ($swMaxRelaxedSearchTime==0) $swMaxRelaxedSearchTime=10000;
		$starttime = microtime(true);	
		$overtime = false;
			
		for($r = $this->lastrevision+1; $r<=$lastindex; $r++)
		{
			
			$nowtime = microtime(true);	
			$dur = sprintf("%04d",($nowtime-$starttime)*1000);
			if ($dur>$swMaxRelaxedSearchTime)
			{
				echotime('overtime INDEX');
				global $swError;
				$swError = "Index incomplete. Please reload";
				$overtime = true;
				
				break;
			}
			
			$rec = new swRecord;
			$rec->revision = $r;
			$rec->lookup();
			
			$this->UpdateIndexes($r);
		}
		
		echotime('built '.$this->lastrevision." ".$this->hasindex);		
	    
	}	
	
}






?>