<?php

if (!defined('SOFAWIKI')) die('invalid acces');

$swParsedName = swSystemMessage('Search',$lang).': '.$query;

$ns = join(' ',$swSearchNamespaces);

echotime('query');

$foundname = false;
$found = false;

if  (isset($swQuickSearchinTitle) && $swQuickSearchinTitle && !isset($_REQUEST['allresults']))
{
	
	//echo " S4 ";
	$urlquery = swNameURL($query);
	$urlquerylist = explode('-',$urlquery);
	
	$record = new swWiki;
	$record->name = $urlquery;
	$c = $record->CurrentPath();
	
	if (isset($swQuickSearchRedirect) && $swQuickSearchRedirect && file_exists($c) )
	{
		$nsw = $record->wikinamespace();
		if ($nsw == '' ||�stristr($ns.' ',$nsw.' ') || $ns=='*')
		{
			
			$swParsedContent = '#REDIRECT [['.$urlquery.']]';
			$name = $urlquery;
			$swParseSpecial = true;
			$found = true;
			$foundname = true;
		}
	}
	else
	{
		echotime ('qsit all');
		foreach($urlquerylist as $word)
		{
			$foundlist[$word] = swFindURL($word);
		}
		
		//print_r($foundlist);
		
		$commonlist = array_shift($foundlist);
		foreach($foundlist as $list)
		{
			$commonlist = array_intersect($commonlist, $list);
		}
		
		//print_r($commonlist);
		// filter commonlist for current and not deleted
		
		foreach($commonlist as $r=>$n)
		{
			if (! $db->currentbitmap->getbit($r) )
				unset($commonlist[$r]);
			if ($db->deletedbitmap->getbit($r) )
				unset($commonlist[$r]);
		}
		
		$names = array_flip($commonlist);
		if (count($names)>0)
			$found = true;
		
		
		
		//print_r($names);
	}
}


if (!$found)
{
	$revisions = swQuery(trim($query),$ns);
	
	$commonlist = swFindNames($revisions);
	
	//print_r($commonlist);
	
	foreach($commonlist as $r=>$n)
	{
		if (! $db->currentbitmap->getbit($r) )
				unset($commonlist[$r]);
		if ($db->deletedbitmap->getbit($r) )
				unset($commonlist[$r]);
	}
	$names = array_flip($commonlist);
	if (count($names)>0)
		$found = true;
		
	//print_r($commonlist);
}





if (!$foundname)
{

	$swParseSpecial = false; 
	$separator = "\n";
	$gprefix = '<ul>';
	$gpostfix = '</ul>';
	$limit = '';
	
	
	// function can reorder list and apply custom templates for each name
	if (function_exists('swInternalSearchHook')) 
	{
		$hookresult = swInternalSearchHook($names,$query);
		if ($hookresult)
		{
			$gprefix = ''; if (isset($hookresult['gprefix'])) $gprefix =  $hookresult['gprefix'];
			$gpostfix = ''; if (isset($hookresult['gpostfix'])) $gpostfix =  $hookresult['gpostfix'];
			$names = ''; if (isset($hookresult['names'])) $names =  $hookresult['names'];
			$separator = ''; if (isset($hookresult['separator'])) $separator =  $hookresult['separator'];
			if (isset($hookresult['limit'])) $limit =  $hookresult['limit'];
			
			$swParseSpecial = true; 
		}
	}
	
	
	if ($limit==0) $limit = 50;
	
	$start = 0; if (isset($_REQUEST['start'])) $start = $_REQUEST['start'];
	$count = count($names);
	global $lang;
	global $name;
	
	$navigation = '<nowiki><div class="categorynavigation">';
	if ($start>0)
		$navigation .= '<a href="index.php?action=search&query='.$query.'&start='.sprintf("%0d",$start-$limit).'"> '.swSystemMessage('back',$lang).'</a> ';
		
	$navigation .= " ".sprintf("%0d",min($start+1,$count))." - ".sprintf("%0d",min($start+$limit,$count))." / ".$count;
	if ($start<$count-$limit)
		$navigation .= ' <a href="index.php?action=search&query='.$query.'&start='.sprintf("%0d",$start+$limit).'">'.swSystemMessage('forward',$lang).'</a>';
	$navigation .= '</div></nowiki>';
	
	
	$searchtexts = array();
	
	
	
	
	$i=0;
	if (is_array($names) && count($names)>0)
	{
	foreach ($names as $k=>$v)
	{
	
		
		$i++;
		if ($i<=$start) continue; 
		if ($i>$start+$limit) continue; 
		
			$record = new swWiki;
			$record->name = $k;
			$record->lookup();
			
			
			
			if (substr($record->content,0,9) == '#REDIRECT') continue;
			
			$link = $record->link("");
			
			$dplen = strlen('#DISPLAYNAME');
			if (substr($record->content,0,$dplen)=='#DISPLAYNAME')
				{
					$pos = strpos($record->content,"\n");
					$record->name = substr($record->content,$dplen+1,$pos+1-$dplen-2);
				}
			
			
			
			if (($record->status=='ok' or $record->status=='protected') && $user->hasright('view', $record->name))
			{
				
					if (isset($hookresult) && $hookresult )
					{
						$searchtexts[] = $v;	
						
					}
					else
					{
	
						$t = "";
						$qs = swQuerySplit($query);
						if (stristr($record->content,$qs[0]))
						{
							
							$pos = stripos2($record->content, $qs[0]);
							$pos = max(0,$pos-80);
							if ($pos>0)
								$pos = stripos2($record->content, ' ', $pos);
							
							$pos2 = stripos2($record->content, ' ', min(strlen($record->content),$pos+160));
							
							if ($pos2===NULL || $pos2=='')
							{
								$record->content = substr($record->content,$pos); 
							}
							else
							{
								$record->content = substr($record->content,$pos,$pos2-$pos);  
							}
							$record->parsers = array();
							$record->parsers['nowiki'] = new swNoWikiParser;
							$t = $record->parse();
							
							
							foreach ($qs as $q)
								$t = swStrReplace($q,'<span class="found">'.$q.'</span>',$t);
							
						}
						
						$searchtexts[] = '<li><a href="'.$link.'">'.$record->name.'</a>
						<br/>'.$t.'</li>';
				
					}
			}
	}
	} // count >0
	
	//print_r($searchtexts);
	
	$swParsedContent = $navigation.$gprefix.join($separator,$searchtexts).$gpostfix.$navigation;
	
	//echo $swParsedContent;

}



if ($swParseSpecial)
{
	
	$wiki->content = $swParsedContent;
	
	$wiki->parsers = $swParsers;
	$swParsedContent = $wiki->parse();
	
	//echo $swParsedContent;
}

if ($foundname)  $swParsedContent.="\n".'<a href="index.php?action=search&query='.$query.'&allresults=1">'.swSystemMessage('all results',$lang).'</a>';
elseif (isset($swOvertime) && $swOvertime)  $swParsedContent.="\n".'<a href="index.php?action=search&query='.$query.'&allresults=1&moreresults=1">'.swSystemMessage('more results',$lang).'</a>';


?>