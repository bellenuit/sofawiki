<?php

if (!defined("SOFAWIKI")) die("invalid acces");

$swParsedName = "Special:Users";

$swParsedContent = "Add new user: [[Special:Passwords]]\n\n";

$filter = "SELECT revision, name WHERE name =* User:";
$result = swFilter($filter,'*','data');

$lines	= array();
foreach($result as $r=>$row)
{
	
	if (isset($row['name']))
	{
		$name = $row['name']; 
		if (is_array($name))
			$name = array_pop($name);
			
		$url = swNameURL($name);
		$name = substr($name,strlen('User:'));
		$lines[] = "[[$url|$name]]";
	}
}
sort($lines);
$swParsedContent .= join(' ',$lines);

$swParseSpecial = true;




?>