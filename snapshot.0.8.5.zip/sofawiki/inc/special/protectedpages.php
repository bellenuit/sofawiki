<?php

if (!defined("SOFAWIKI")) die("invalid acces");

if (!defined("SOFAWIKI")) die("invalid acces");

$swParsedName = "Special:Proteced Pages";

$swParsedContent = "";

$filter = "SELECT revision, name WHERE status == protected";
$result = swFilter($filter,'','data');
		
foreach($result as $row)
{
	if (isset($row['name']))
	{
		$name = $row['name'];
		if (is_array($name))
			$name = array_pop($name);
		$url = swNameURL($name);
		$swParsedContent .= '<a href="index.php?action=view&name='.$url.'">'.$name.'</a> ' ;
	}
}


$swParseSpecial = false;


?>