 <?php

if (!defined('SOFAWIKI')) die('invalid acces');

$replace = swGetArrayValue($_REQUEST,'replace');
$submitreplace = swGetArrayValue($_REQUEST,'submitreplace');
$submitreplacepreview = swGetArrayValue($_REQUEST,'submitreplacepreview');

$swMaxRelaxedSearchTime *=5;   
$swMaxOverallSearchTime *=5;  


if ($query)
{
	//preserve backspace
	$query = str_replace("\\\\","\\",$query);
	$replace = str_replace("\\\\","\\",$replace);
}

$swParsedName = swSystemMessage('Regex',$lang);
if ($query) $swParsedName .= ': '.$query;

$ns = join(' ',$swSearchNamespaces);
$ns = '*';
$regexerror = false;

if ($query)
{
	$ch0 = substr($query,0,1);
	$ch1 = substr($query,-1,1);
	if ($ch0 == $ch1)
		$revisions = swFilter($query,$ns,'regex');
	else
	{
		$regexerror = '<br><b>Error: Starting and ending delimiter do not match</b>';
		$revisions = array();
	}
}
else
	$revisions = array();

ksort($revisions,SORT_NUMERIC);
/*
if ($submitreplace)
{
	// build revisions from parameters
	$revisions = array();
	foreach($_POST as $k=>$v)
	{
		if (substr($k,0,strlen('revision'))=='revision')
		{
			$r = substr($k,strlen('revision'));
			$revisions[$r] = true;
		}
	}
}
*/


$c=count($revisions);
if ($c>50)
{
	while(count($revisions)>50) array_pop($revisions);
	$arraylimited = "<br>Search had $c results. Limited to 50";
}
else
	$arraylimited = '';



$searchtexts = array();

$record = new swWiki;

foreach ($revisions as $k=>$v)
{
	$record = new swWiki;
	$record->revision = $k;
	$record->lookup();
	
	if ($record->status=='ok' or $record->status=='protected')
	{
		$t = '';
		if (($submitreplacepreview || $submitreplace) && $replace)
			$t = preg_replace($query,'<del>$0</del><ins>'.$replace.'</ins>',$record->content);
		else
			$t = preg_replace($query,'<ins>$0</ins>',$record->content);
			
		$ts = explode("\n",$t);
		
		$tlines = array();
		foreach($ts as $tline)
		{
			if (stristr($tline,'<ins>'))
			$tlines[] = $tline;
		}
		
		$t = join("\n",$tlines);
		
		
		if ($submitreplace && $_REQUEST['revision'.$record->revision])
		{
			if ($record->status == 'protected')
				$replaced = 'protected';
			elseif ($record->status == 'ok' && $user->hasright('modify', $record->name))
			{
				$record->content = preg_replace($query,$replace,$record->content);
				$record->comment = 'regex find '.$query.' replace '.$replace;
				$record->insert();
				$replaced = 'replaced';
			}
		}
		else
			$replaced = '';
			
		if ($submitreplacepreview && $record->status == 'ok' && $user->hasright('modify', $record->name))
			$check = '<input type="checkbox" name="revision'.$record->revision.'" value="1" CHECKED>';
		else
			$check = '';
		
		$searchtexts[] = '<li>'.$check.' '.$record->revision.' <a href="'.$record->link('').'">'.$record->name.'</a> '.$replaced.'
		<br/><pre>'.$t.'</pre></li>';
	}
	
	
	
}
/* obsolete?
if (isset($replaced) && $replaced == "replaced")
	$db->RebuildIndexes();
*/

if(!$query) $query="//";

$swParsedContent = '<div id="editzone"><form method="post" action="index.php">
		<p>
		<input type="hidden" name="name" value="special:regex" />
		<input type="text" name="query" value="'.$query.'" />
		<input type="submit" name="submit" value="'.swSystemMessage('Search',$lang).'" />
		<input type="text" name="replace" value="'.$replace.'" />
		<input type="submit" name="submitreplacepreview" value="'.swSystemMessage('Replace Preview',$lang).'" />';
		
if ($submitreplacepreview &&!$swOvertime && !$regexerror && count($revisions)>0)

$swParsedContent .= '<input type="submit" name="submitreplace" value="'.swSystemMessage("Replace",$lang).'" />';
	
$swParsedContent .= '</p><p><i>Note: You need to use Perl style delimiters at the start and at the end like /searchterm/.
	<br/>This is a very powerful tool that can change many wiki pages at once. Use it carefully.
	<br>Matches: . any \\w azAZ09_ \\W not w \\s whitespace \\S not s \\d 09 \\D non d
	<br>\\t tab \\n newline \\r return
\\021  octal char \\xf0  hex char [ab] a ot b [^ab] neither a nor b
<br>* 0+ + 1 ? 0-1 {n} n times {n,m} n to m times *? mutliple not greedy
<br>/exp/i case insensitive /^exp/ beginning of string /exp$/ end of string
	</i>'.$regexerror.$arraylimited;

$swParsedContent .= '<ul>'.join("\n",$searchtexts).'</ul>';


$swParsedContent .= '</p></form>';
?>