<?php

if (!defined("SOFAWIKI")) die("invalid acces");


$swParsedName = "Special:Templates";

$swParsedContent = "";

$filter = "SELECT revision, name WHERE name =* Template:";
$result = swFilter($filter,'*','data');

$lines	= array();
foreach($result as $r=>$row)
{
	
	if (isset($row['name']))
	{
		$name = $row['name']; 
		if (is_array($name))
			$name = array_pop($name);
			
		$url = swNameURL($name);
		$name = substr($name,strlen('Template:'));
		$lines[] = '<a href="index.php?name='.$url.'">'.$name.'</a> ';
	}
}
sort($lines);
$swParsedContent = join(' ',$lines);

$swParseSpecial = false;




?>