<?php


if (!defined('SOFAWIKI')) die('invalid acces');




function swQuery($filter,$namespace,$mode="relaxed")
{
	
	// split set in words and filter for each one, then combine them
	
	$filterlist = swQuerySplit($filter);  // will have to be more sophisticated to allow for spaces within [[field::value]]
	global $swSearchWordLimit;
	
	// we remove all terms with less than 3 characters and limit the list length
	$newfilterlist = array();
	for ($i=0;$i<count($filterlist);$i++)
	{
		$term = $filterlist[$i];
		if (strlen($term)>=3)
			$newfilterlist[] = $term;
		if (count($filterlist)==$swSearchWordLimit)
			break;
	}
	$filterlist = $newfilterlist;	

	// limit time for searches
	global $swMaxRelaxedSearchTime;
	$swMaxRelaxedSearchTime = $swMaxRelaxedSearchTime*2/(count($filterlist)+1);
	if (isset($_REQUEST['moreresults'])) $swMaxRelaxedSearchTime *=2;
	
	$revisionlists = array();
	
	foreach ($filterlist as $f)
	{
		$rev = swFilter($f,$namespace,$mode);
		$revisionlists[] = $rev;
	}
	$rev0 = array();
	$c = count($revisionlists);
	if ($c>0)
		$rev0 = $revisionlists[0];
	if ($c>1) 
	{
		for ($i=1;$i<$c;$i++)
		{
			$rev1 = $revisionlists[$i];
			//echo "<pre>";print_r($rev1);echo "</pre>";
			foreach($rev0 as $k=>$v)
			{
				//echo "<br>k $k v $v rev1 $rev1[$k]";
				if (isset($rev1[$k]))
					$rev0[$k] *= $rev1[$k];
				else
					unset($rev0[$k]);
			}
		}
	}
	
    arsort($rev0,SORT_NUMERIC);
//	print_r($rev0);
	return $rev0;
}


function swFilterCompare($operator,$valuelist,$term)
{	
	if (!is_array($valuelist))
		$valuelist = array($valuelist);
	
	switch ($operator)
	{
		case '=': foreach($valuelist as $v)
				   {	if (floatval($v)==floatval($term)) return true; } break;
		case '<>': foreach($valuelist as $v)
				   {	if (floatval($v)!=floatval($term)) return true; } break;
		case '<': foreach($valuelist as $v)
				   {	if (floatval($v)<floatval($term)) return true; } break;
		case '>': foreach($valuelist as $v)
				   {	if (floatval($v)>floatval($term)) return true; } break;
		case '<=': foreach($valuelist as $v)
				   {	if (floatval($v)<=floatval($term)) return true; } break;
		case '>=': foreach($valuelist as $v)
				   {	if (floatval($v)>=floatval($term)) return true; } break;
		case '==': foreach($valuelist as $v)
				   {	if ($v==$term) return true; } break;
		case '!=': return true; foreach($valuelist as $v)
				   {	if ($v==$term) $found = false; } break;
		case '=*': foreach($valuelist as $v)
				   {	if (substr($v,0,strlen($term))==$term) return true; } break;
		case '!=*': return true; foreach($valuelist as $v)
				   {	if (substr($v,0,strlen($term))==$term) $found = false; } break;
		case '*=': foreach($valuelist as $v)
				   {	if (substr($v,-strlen($term))==$term) return true; } break;
		case '!*=': return true;foreach($valuelist as $v)
				   {	if (substr($v,-strlen($term))==$term) $found = false; } break;
		case '*=*': foreach($valuelist as $v)
				   {	 if (stripos($v,$term) !== FALSE) return true; } break;
		case '!*=*': return true;foreach($valuelist as $v)
				   {	if (stripos($v,$term) !== FALSE) $found = false; } break;
		case '<<': foreach($valuelist as $v)
				   {	if ($v<$term) return true; } break;
		case '>>': foreach($valuelist as $v)
				   {	if ($v>$term) return true; } break;
		case '<<=': foreach($valuelist as $v)
				   {	if ($v<=$term) return true; } break;
		case '>>=': foreach($valuelist as $v)
				   {	if ($v>=$term) return true; } break;
		case '!~': return true; foreach($valuelist as $v)
				   {    $v = swNameURL($v);
						if (stripos($v,$term) !== FALSE) $found = false; } break;
		case '~~': foreach($valuelist as $v)
				   {	$v = swNameURL($v);
						if ($v==$term) return true; } break;
		case '~*': foreach($valuelist as $v)
				   {	$v = swNameURL($v);
						if (substr($v,0,strlen($term))==$term) return true; } break;
		case '*~': foreach($valuelist as $v)
				   {	$v = swNameURL($v);
						if (substr($v,-strlen($term))==$term) return true; } break;
		case '*~*': foreach($valuelist as $v)
				   {    $v = swNameURL($v);
						if (stripos($v,$term) !== FALSE) return true; } break;						
		case '*':  return true;  break;
		case '!0': foreach($valuelist as $v)
				   {	if ($v != 0 || $v != '') return true; } break;
		case 'r=': foreach($valuelist as $v)
					{ if (preg_match($term, $v, $matches)) return true; }
					break;
		default:   return false;
	}
	return false;
}

function swFilter($filter,$namespace,$mode='query',$flags="current")
{
	global $swRoot;
	global $db;
	$goodrevisions = array();
	$operator = '';
	$over = false; 
	
	$rowsort =false;
	
	//echomem("start",true); 
	echotime('query '.$mode.'-'.$namespace.' '.$filter);
	//echo $filter;

	// parse select string SELECT fields WHERE field operator term
	
	if ($mode=='data' && substr($filter,0,6) == 'SELECT')
	{
		$filter2 = substr($filter,7);
		
		if ($p = strpos($filter2,' WHERE '))
		{
			$fields = substr($filter2,0,$p);
			$fs = explode(',',$fields);
			$fields = array();
			foreach($fs as $f)	{ $fields[]=trim($f); }
			
			$query = substr($filter2,$p+strlen(' WHERE '));
			$words = explode(' ',$query);
			$wordlist = array();
			foreach($words as $w) { if ($w != '') $wordlist[] = $w; }
			$field = $wordlist[0]; 
			if (count($wordlist)>1)
			{
				$operator = $wordlist[1];
				unset($wordlist[1]);
			}
			else
				$operator = '*';
			unset($wordlist[0]);
			if (count($wordlist)>0)
				$term = trim(join(' ',$wordlist));
			else
				$term = '';
		}
	}
	
	
	
	
	if ($mode=='data' && substr($filter,0,6) == 'FIELDS')
		$fields = array('fields');
	
	if ($mode == 'relaxed') 
		$filter = swNameURL($filter);

	if ($mode == 'relaxed' || $mode == 'regex')
		$rowsort = true;

	if ($operator == '~~'|| $operator == '*~'|| $operator == '~*'|| $operator == '*~*') 
		$term = swNameURL($term);


	// find already searched revisions
	$lastfoundrevision = 0;
	$mdfilter = $filter;
	$mdfilter .= $namespace;
	$mdfilter .= $mode;
	$mdfilter = urlencode($mdfilter);
	$cachefile2 = $cachefile = $swRoot.'/site/queries/'.md5($mdfilter).'.txt';
	
	
	
	global $swDebugRefresh;
	if ($swDebugRefresh)
		{ $refresh=1; echotime('refresh');}
	else	
		$refresh=0;
	
	if (file_exists($cachefile) && !$refresh) 
	{
		$s = file_get_contents($cachefile);
		$results = unserialize($s);
		//echomem("open",true); 
		$lastfoundrevision = $results['lastfoundrevision'];
		
		//$lastfoundrevision = ($lastfoundrevision >> 3) << 3; // round down previous byte, because at the end there can be errors
		
		
		$goodrevisions  = $results['goodrevisions'];
		if (isset($results['bitmap']))
			$bitmap = $results['bitmap'];
		else
			$bitmap = new swBitmap;
		echotime('cached '.count($goodrevisions).' / '.$lastfoundrevision.' '.md5($mdfilter).'.txt');
		unset($results);
		unset($s);
	}
	else
	{
		if (file_exists($cachefile))
			unlink($cachefile);
		$lastfoundrevision = 0;
		$goodrevisions = array();
		$bitmap = new swBitmap;
	}
	//echomem("cached",true); 	
	$maxlastrevision = $db->lastrevision;
	
	if ($lastfoundrevision < $maxlastrevision)
	{
	
		$bitmap->redim($maxlastrevision,true);
		
				
		// if there is an existing search on a substring, we can exclude all urls with no result
		// a cron tab will create searches on all possible strings with 3 characters
		// we therefore test again all substrings with 3 characters
		$lastrevision =$lastfoundrevision; 
	
			if ($maxlastrevision - $lastfoundrevision > 50 ) // small searches reduction is not interesting
			{
			
				// if it is data search, we can restrict to all revisions that have the field
				if (isset($field) && $mode == 'data' && $field != '' && $field != 'name' && $field != 'content' && $operator != '*')
				{
					$filter2 = 'SELECT '.$field.' WHERE '.$field.' * ';
					$filter2revisions = swFilter($filter2,$namespace,'data');
					$ak = array_keys($filter2revisions);
					if (count($ak)>0)
						$maxfilter2revision = max($ak);
					else
						$maxfilter2revision = 0;
					$term2 = swNameURL($term);
					for($k=0;$k<$maxfilter2revision;$k++)
					{
						if (!isset($filter2revisions[$k]))
							$bitmap->unsetbit($k);

						//experimental
						if (!swFilterCompare($operator,$filter2revisions[$k][$field],$term))
							$bitmap->unsetbit($k);
					}
					echotime('- * '.$bitmap->countbits());
				}	
				
				if ($mode == 'relaxed' && strlen($filter)>=3)
				{
					for($i=0;$i<=strlen($filter)-3;$i++)
					{
						if ($bitmap->countbits()<50) continue;
						$f = substr($filter,$i,3);
						$gr = getTrigram($f);
						if ($gr)
						{
							$gr->redim($bitmap->length, true);
							$bitmap = $bitmap->andop($gr);
						}
						
						echotime('- '.$f.' '.$bitmap->countbits());
					}
				
				}
				
				// search only in records which have the field
				// and use also the 3letter-trick on the field
				if (isset($field) && $mode == 'data' && strlen($field)>=3 && $field != 'content'  && $field != 'name' && $filter != 'FIELDS' )
				{
						
					$field2 = swNameURL($field);
					for($i=0;$i<=strlen($field2)-3;$i++)
					{
						if ($bitmap->countbits()<50) continue;
						$f = substr($field2,$i,3);
						$gr = getTrigram($f);
						if ($gr)
						{
							$gr->redim($bitmap->length, true);
							$bitmap = $bitmap->andop($gr);
						}
						
						echotime('- '.$f.' '.$bitmap->countbits());
					}
						
						
				}
				
				// use the 3letter trick on the term (trigram)
				if (isset($term) && $mode == 'data'  && strlen($term)>=3 && ( $operator == '==' || $operator == '*=' || $operator == '=*' 
				|| $operator == '*=*' 
				|| $operator == '~~'|| $operator == '*~'|| $operator == '~*'|| $operator == '*~*'))
				{
					
					if (strlen($term)>3)
					{
						$term2 = swNameURL($term);
						for($i=0;$i<=strlen($term2)-3;$i++)
						{
							if ($bitmap->countbits()<50) continue;
							$f = substr($term2,$i,3);
							$gr = getTrigram($f);
							if ($gr)
							{
								$gr->redim($bitmap->length, true);
								$bitmap = $bitmap->andop($gr);
							}
						
							echotime('- '.$f.' '.$bitmap->countbits());
						}
					}
				}
			
			}
			
			$starttime = microtime(true);	
			global $swMaxRelaxedSearchTime;
			global $swMaxOverallSearchTime;
			if ($swMaxOverallSearchTime==0) $swMaxOverallSearchTime = 1000;
			global $swOvertime;
			
			echotime('loop');
			//echomem("loop",true); 
			
			for ($k=$lastfoundrevision+1;$k<=$maxlastrevision;$k++)
			{
				if (!$bitmap->getBit($k) && $k<$maxlastrevision-16 ) continue; // last bits always check
				
				if ($mode == 'relaxed' && $swMaxRelaxedSearchTime>0)
				{
					$nowtime = microtime(true);	
					$dur = sprintf("%04d",($nowtime-$starttime)*1000);
					if ($dur>$swMaxRelaxedSearchTime)
					{
						echotime('overtime '.$lastrevision.' / '.$maxlastrevision);
						$swOvertime=true;
						$over = true;
						break;
					}
					
				}
				
				if ($swMaxOverallSearchTime>0)
				{
					
					$nowtime = microtime(true);	
					$dur = sprintf("%04d",($nowtime-$starttime)*1000);
					if ($dur>$swMaxOverallSearchTime) 
					{
						echotime('overtime');
						$swOvertime=true;
						$over = true;
						break;
					}
				}	
				$lastrevision = $k;
				
				
				$record = new swRecord;
				$record->revision = $k;
				$record->lookup();
				
				
				$ns = $record->wikinamespace();
				if ($ns != '' && !stristr($namespace.' ',$ns.' ') && $namespace!='*')
				{
					continue;
				}
				
				$content = $record->name.' '.$record->content;
				$row=array();
				
				switch($mode)
				{
				case 'data':
					$fieldlist = $record->internalfields;
	
					if ($filter == 'FIELDS')
					{
						$keys =array_keys($fieldlist);
						if (count($keys)>0)
							$row['fields'] = $keys;
					}
					elseif (substr($filter,0,6) == 'SELECT')
					{
						$fieldlist['revision'][] = $record->revision;
						$fieldlist['status'][] = $record->status;
						$fieldlist['name'][] = $record->name;
						$fieldlist['content'][] = $record->content;
						$fieldlist['*'][] = $content;
						
						$row = array();
						
						if (!isset($fieldlist[$field])) continue;
						
						//echo $k.' ';
						$found = swFilterCompare($operator,$fieldlist[$field],$term);
						
						if ($found)
						{
							//echo ' ok';
							
							
							foreach ($fields as $f)
							{
								
								//echo ".";
								if (isset($fieldlist[$f]))
									$row[$f]= $fieldlist[$f];
								else
									$row[$f] = "";
		
							}
						}
						
					}
					
					if (count($row)>0)
					{
						$goodrevisions[$k] = $row;
					}
					else
						$bitmap->unsetbit($k);
					break;
				case 'regex':
					$matches = array();
					$offset = 0;
					$row = 0;
					
					while (preg_match($filter, $content, $matches, PREG_OFFSET_CAPTURE, $offset))
					{
						if (is_array($matches[0]))
							$m = $matches[0][1];
						else
							$m = $matches[1];
						$row += 1 - ($m / (strlen($content)- $offset) );
						$offset += $m+1;
					}
					if ($row>0)
					{
						$goodrevisions[$k]['_row'] = sprintf('%09.3f',$row);
					}
					else
						$bitmap->unsetbit($k);
					
					break;
				case 'relaxed': // query
					$content = swNameURL($content);
				default:	
					if (stristr($content,$filter))
					{
						//row value will be simple rating algorithm: 
						//counts the number of occurences and the position
						
						$row = 0;
						$len0 = strlen($content);
						if (stristr($record->name,$filter))
						{
							$row += 100;
						}
						while ($content = stristr($content,$filter))
						{
							$row += strlen($content) / $len0;
							$content = substr($content,1);
						}
						$goodrevisions[$k]['_row'] = sprintf('%09.3f',$row);
					}
					else
						$bitmap->unsetbit($k);
					
				}
			}
			
			
			
			
			
			echotime('good '.count($goodrevisions).' / '.$lastrevision);
			echomem("filter");	
			
			
			// now we have a list of goodrevisions.
			// some revisions may not be valid depending on flag, we will remove them 
			
			$db->init();
			$currentbitmap = $db->currentbitmap->duplicate();
			$deletedbitmap = $db->deletedbitmap->duplicate();
			
			foreach($goodrevisions as $k=>$v)
			{
				if (!stristr($flags,'all') && !$currentbitmap->getbit($k))
				{
					$bitmap->unsetbit($k);
					unset($goodrevisions[$k]);
					continue;
				}
				
				if (!stristr($flags,'deleted') && $deletedbitmap->getbit($k))
				{
					$bitmap->unsetbit($k);
					unset($goodrevisions[$k]);
					continue;
				}
				
			}
			echotime('valid '.count($goodrevisions).' / '.$lastrevision);
			
			// save to cache
			
			$results=array();
			$results['filter'] = $filter;
			$results['mode'] = $mode;
			$results['namespace'] = $namespace;
			$results['flags'] = $flags;
			$results['bitmap'] = $bitmap;
			$results['lastfoundrevision'] = $lastrevision;
			$results['goodrevisions'] = $goodrevisions;
			
			$t = serialize($results);
			
			
			if ($handle = fopen($cachefile2, 'w')) { fwrite($handle, $t);  fclose($handle); }
			else { swException('Write error Query cache'); return;}
		
			echotime('saved');

		// we do not need allurls any more
		$allrevisions = NULL;
	
	}
	
	
	
	if ($rowsort)
	{
		
		foreach($goodrevisions as $k=>$v)
		{
			$goodrevisions[$k] = $v['_row'];
		}
		arsort($goodrevisions);
	}
	
	
	if ($filter=="FIELDS")
	{
		$ts = array();
		foreach($goodrevisions as $k=>$v)
		{
			foreach($v['fields'] as $v)
			{
				$ts[$v]['field'] = $v;
			}	
		}
		if (is_array($ts))
			ksort($ts);
		$goodrevisions = $ts;
		
	}
	
	
	
	
	return $goodrevisions;
			
	
}



?>