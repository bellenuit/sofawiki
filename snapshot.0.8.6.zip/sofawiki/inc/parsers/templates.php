<?php 

if (!defined("SOFAWIKI")) die("invalid acces");


class swTemplateParser extends swParser
{

	var $functions;
	var $transcludenamespaces;
	
	function info()
	{
	 	return "Handles pages transclusion, functions and templates";
	}
	
	function dowork(&$wiki)
	{
	
		$s = $wiki->parsedContent;
		
		global $swFunctions;
		$this->functions = $swFunctions;
		global $swTranscludeNamespaces;
		$this->transcludenamespaces = array_flip($swTranscludeNamespaces);
		
		// internal links
		//  preg_match_all("/\{\{([^\/\{\}]+)\}\}/U", $s, $matches, PREG_SET_ORDER);
		
		
		// if language version, replace {{}} with non-language version of same page
		
			
		if (stristr($wiki->name,'/') && stristr($s, '{{}}'))
		{
			//echotime("{{}}");
			$myname2 = substr($wiki->name,0,-3);
			{
				$wiki2 = new swWiki;
				$wiki2->name = $myname2;
				$wiki2->lookup();
				//echotime($wiki2->name.' '.$wiki2->status);
				//echo $wiki2->content;
				
				if (trim($wiki2->content) == '')
					$s = str_replace('{{}}'."\n",'',$s);
				else
				{
					$s = str_replace('{{}}',$wiki2->content,$s);
					//echotime($wiki2->content);
					foreach ($wiki2->internalfields as $k=>$v)
					{
						foreach ($v as $item)
						{
								
								//echotime($k);
								$wiki->internalfields[$k][] = $item;
						}
					}
				}
				
				//print_r($wiki->internalfields);
			}
		}
		
		
		// replace multiline templates with single line
		
		preg_match_all("/\{{([^\}]*)}}/mu", $s, $matches, PREG_SET_ORDER);
		foreach ($matches as $v)
		{
			$val0 = $v[1]; 
			if (!strpos($val0,"\n|")) continue;
			$val1 = str_replace("\n|","|",$val0);
			$val1 = str_replace("\n| ","|",$val0);
			$val1 = str_replace("\n","",$val1);
			$val1 = str_replace("\r","",$val1);
			$s = str_replace($val0,$val1,$s);
			
		}
		
		//preg_match_all("/\{{([-\.\w\/\: \|,\!\.\?\'«»\p{L}]+)\}}/u", $s, $matches, PREG_SET_ORDER);
		preg_match_all("/\{{([^\}]+)\}}/u", $s, $matches, PREG_SET_ORDER);
		
		foreach ($matches as $v)
		{
			
			
			
			$val0 = $v[1]; 
			$vals = explode('|',$v[1]);
			
			$val = $vals[0];
			$vtest = $val;
			
			if (array_key_exists($val,$this->functions))
			{
				$f = $this->functions[$val];
				$c = $f->dowork($vals);
				
				
				// fix replacing with parameters: 
				
				$s = str_replace("{{".$val0."}}",$c,$s);
				continue;
			}
			
			
			if (strpos($val,":")===0)
			{
				$val = substr($val,1);
			}
			elseif (strpos($val,":")>0)
			{
				// explicite namespace
			}
			else
			{
				$val = "Template:$val";
			}
			
			
			
			$fields = explode(":",$val);
			if (count($fields)>1 && !array_key_exists($fields[0],$this->transcludenamespaces))
			{
				 //echo "($fields[0]) not includable";
				 // print_r($this->transcludenamespaces);
				 continue;
			}
			
			global $swSystemSiteValues;
			global $swSystemDefaults;
			
			$linkwiki = new swWiki();
			$linkwiki->name = $val;
			$linkwiki->lookupLocalname();
		
			if ($fields[0]=="System" && array_key_exists($fields[1],$swSystemSiteValues))
			{
				
				$c = $swSystemSiteValues[$fields[1]];
			}
			else
			{
				$linkwiki->lookup();   
				$c = '';
				if ($linkwiki->visible())
				{
					$c = $linkwiki->content;
					if ($fields[0]=="System")
					{
						$swSystemSiteValues[$fields[1]] = $c;
					}
				}
				elseif ($fields[0]=="System")
				{
					if (array_key_exists($fields[1],$swSystemDefaults))
					{
						$c = $swSystemDefaults[$fields[1]];
						$swSystemSiteValues[$fields[1]] = $c;
					}
					else
						$c = substr($fields[1],0,strpos($fields[1],"/"));
				}
			}
			
			
			for ($i = 1; $i< count($vals); $i++)
			{
				$c = str_replace("{{{".$i."}}}",$vals[$i],$c);
			}
				
				
			$s = str_replace("{{".$val0."}}",$c,$s);
						
				
		}
		
		
		
		$s0 = $wiki->parsedContent;
				
		$wiki->parsedContent = $s;
		
		// reparse fields, content may have changed
		
		$fp = new swFieldsParser;
		$fp->dowork($wiki);
		
		// recurse
		if ($s != $s0 &&  stristr($s,"{{") && stristr($s,"}}"))
		{
			
			$this->dowork($wiki);
		}
		
		
		
		
	}

}

$swParsers["templates"] = new swTemplateParser;


?>