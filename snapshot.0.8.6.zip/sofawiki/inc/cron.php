<?

if (!defined("SOFAWIKI")) die("invalid acces");


function swCron()
{
	
	if (function_exists('swInternalCronHook') && swInternalCronHook()) 
	{
		// everything is handled by configuration.php
	}
	else
	{
		// do some housework by default from time to time
	
		switch(rand(0,100))
		{
			case 0: echotime('cron index'); global $db; $db->init(true); break; // rebuild indexes 
			
			case 1: echotime('cron trigram'); swIndexTrigram();  break; 
			
			case 2: echotime('cron fields'); swIndexRandomFields(1000);  break; 
			
			case 3 : echotime('cron sitemap'); swSitemap();  break; 
			
			case 4: echotime('cron hunt'); swHuntDuplicates(); break;
			
			default:
		
		}
	}
}



function swIndexRandomFields($maxtime)
{
	global $swMaxOverallSearchTime;
	$mrst = $swMaxOverallSearchTime;
	$swMaxOverallSearchTime=$maxtime;
	global $swSearchNamespaces;
	$ns = join(' ',$swSearchNamespaces);
	
	$q = swFilter('FIELDS',$ns,'data');
	$f = '';
	if (is_array($q))
	{
		$q = array_keys($q);
		shuffle($q);
		$f = array_pop($q);
	}
	if ($f != '')
	{
		$w = 'SELECT name WHERE '.$f.' *';
		$q2 = swFilter($w,$ns,'data');
	}

	$swMaxOverallSearchTime = $mrst;	
}

function swHuntDuplicates($first='')
{

	// normally, $record->writecurrent is responsible for unsetting the current bitmap when 
	// a new record is written.
	// however, when you rebuild the index, this is not done.
	// this cronjob checks for duplicates and removes earlier versions

	if ($first=='')
	{
		$firsts = array('-','0','1','2','3','4','5','6','7','8','9',
		'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z');

		shuffle($firsts);
		$first = array_pop($firsts);
	}
	
	echotime("hunt $first");
	global $swMaxOverallSearchTime;
	$swMaxOverallSearchTime /=5;
	
	$revisions = swFilter("SELECT name, revision WHERE name ~* $first",'*','data','');
	
	$swMaxOverallSearchTime *=5;

	global $db;
	$list = array();
	foreach ($revisions as $row)
	{
		$name = $row['name'][0];
		$revision = $row['revision'][0];
		
		if (isset($list[$name]))
		{
			
			$r = $list[$name];
			$db->currentbitmap->unsetbit($r);
			echotime("hunted $r");
		}
				
		$list[$name] = $revision;
	}
	return $list;



}



?>