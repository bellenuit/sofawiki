<?php

if (!defined("SOFAWIKI")) die("invalid acces");


function curl_get_file_contents($URL)
{
       $c = curl_init();
        curl_setopt($c, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($c, CURLOPT_URL, $URL);
        $contents = curl_exec($c);
        curl_close($c);

        if ($contents) return $contents;
            else return FALSE;
}

function ArchiveTwitter($twitteruser)
{
	
	// if (!$twitteruser) return "";
	
	// hack to get files with older tweets from http://tweetake.com/  check all tweets, UTF8 and no errors. download several times
	// put file into $swRoot/site/files and use full path
	$file = "";
	if ($file)
	{
		global $swRoot;
		$path = "$swRoot/site/files/$file";
		
		$length = 1000;
		$handle =fopen($path,"r");
		$headers = fgetcsv($handle,2000,"\t",'"');
		
		
		$itemlist =  array();
		
		while ($item=fgetcsv($handle,2000,"\t",'"'))
		{
			
			$item2 =  array();
			$item2[id] = $item[1];
			$item2[from_user] = $item[3];
			$item2[created_at] = $item[9];
			$item2[text] = $item[10];
			$itemlist[] = $item2;
		}
	}
	global $db;

	if (!$itemlist)
	{
		
	
		$rpp = 100;
		$url = "http://search.twitter.com/search.json?q=from:$twitteruser&rpp=$rpp";
		
		$s = curl_get_file_contents($url);
		$st = json_decode($s,true);
		$itemlist = $st[results];
	}
	
	$currentlist = $db->getAllNames();
	
	$result ="\n\n";
	
	foreach($itemlist as $item)
	{	
		
		
		$name = "Twitter:$item[id]";
		
		if ($currentlist[$name]) continue;
		
		
		$from_user = $item[from_user];
		
		$text = $item[text];
		$text = utf8_decode($text);	
		$text = str_replace("&amp;",'&',$text);
		$text = str_replace("&lt;",'<',$text);
		$text = str_replace("&gt;",'>',$text);
		$text = str_replace("&quot;",'"',$text);

		$time = strtotime($item[created_at]);
		$timetext = date("Y-m-d H:i:s",$time);

		$body = "'''@$from_user''': $text\n''[[twittertime::$timetext|]]''";
		
		// convert @ to wikitext
		$body = preg_replace('/@([-A-Za-z0-9._]+)/', '[http://www.twitter.com/$1 $0]', $body);
		
		
		$wiki = new swWiki();
		$wiki->name = $name;
		$wiki->user = $user->name;
		$wiki->content = $body;
		$wiki->insert();	
		
		$result .= "[[$name]]\n$body\n\n";
		
		
		
	}
	
	return $result;

}


$swParsedName = "Special:Twitter";

$names = $db->GetAllNames();
uasort($names, 'strnatcasecmp'); 
$swParsedContent = "@$swTwitterUser\n";

$swParsedContent .= ArchiveTwitter($swTwitterUser);

$names = array_reverse($names,true);

$i=0;

foreach ($names as $n=>$s)
{

	
	if (substr($n,0,8)=="Twitter:")
	{
		$i++;
		if ($i>100) continue;

		$swParsedContent .= "*[[$n]]\n";
 	}
}


$swParseSpecial = true;





?>