<?php

if (!defined("SOFAWIKI")) die("invalid acces");



$swParsedName = swSystemMessage("NewTalk",$lang)." ".$wiki->simplename(); ;;


if ($wiki->status=="protected"){
	$swParsedContent = "No access";
	return;}



if (!$submitted)

{

	
	$swParsedContent = "<div id='editzone'>";
	
	
	if ($user->hasright("talk", $wiki->simplename()) || $user->hasright("modify", $wiki->name))
		{
				
				if ($swMaxNewTalkLength>0)
				{
					$script = "<script language='javascript' type='text/javascript'>
<!--
function imposeMaxLength(Object, MaxLen)
{
  return (Object.value.length <= MaxLen);
}
-->
</script> ";
					$scriptparameter = "onkeypress='return imposeMaxLength(this, $swMaxNewTalkLength-1);'" ;
				}
				else
				{
					$script = "";
					$scriptparameter = "";
				}
				
				$swParsedContent .= "
	<div id=editzone>$script
	<form method='post' action='".$wiki->link("newtalksubmit")."'>
	<p><input type='hidden' name='name' value='$name' />
	<input type='submit' name='preview' value='".swSystemMessage("NewTalkPreview",$lang)."' />
	<input type='submit' name='submittalksend' value='".swSystemMessage("NewTalkSend",$lang)."' />
	</p><p><textarea name='content' $scriptparameter rows='10' cols='80'>$content</textarea></p>
	</form></div>
	
	<div id='help'>".swSystemMessage("NewTalkHelp",$lang)."</div>
		";
		}
		else
		{
			$swParsedContent .= "no access"; 
		}
	
	$swParsedContent .= "\n</div><hr/>";
	
	
}
else
{
	$swParsedContent .= "<div id='help'>".swSystemMessage("NewTalkThankYou",$lang)."</div><br/>";
}
	
	$w->parsers = $swParsers;
	$swParsedContent .= $w->parse();

	$swParsedContent .= "\n</div>";


$swFooter = "";



?>