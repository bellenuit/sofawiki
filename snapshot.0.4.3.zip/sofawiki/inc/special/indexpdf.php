<?php


// NOT YET WORKING //

if (!defined("SOFAWIKI")) die("invalid acces");

$swParsedName = "Index PDF Files";
$swParsedContent = "Adds fulltext of all PDF files to file pages";

$files = glob("$swRoot/site/files/*.pdf");
natsort($files);
$i = 0; 
foreach($files as $file)
{
	if (substr($file,0,1) != "." && $i<10) 
	{
		
		 
		$shortname = str_replace("$swRoot/site/files/","",$file);
		$wiki->name ="Image:$shortname";
		$wiki->revision = 0; // force lookup
		$wiki->lookup();
		if (!stristr($wiki->content, "<-- PDF-Fulltext"))
		{
			$s = pdf2string($file);
			$s = substr($s,0,100000);
		    $s = str_replace("-->","- ->",$s); // preserve comment
			$wiki->user = $user->name;
			$wiki->content .= "\n\n<-- PDF-Fulltext \n$s\n-->";
			$wiki->insert();

			$swParsedContent .=  "<br/><a href='".$wiki->link("")."'>Image:$shortname</a> $s";
		
			$found = true;
			
			
		}
		$i++;
	}		
}

$wiki->name = "Index PDF";

if (!$found) $swParsedContent .= "<br/><br/>No file found"; 

$swParseSpecial = false;



?>