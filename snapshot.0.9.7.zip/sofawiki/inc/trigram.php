<?php

/*

creates trigram indexes of the content for faster searches
the trigram indexes are simple line-separated array in the site/indexes folder

lasttrigram.txt : last revision indexed
aaa.txt 
...
zzz.txt : line arrays of revisions containing the trigram of the filename

the index uses all revisions, even the revisions that are not used any more

*/


if (!defined('SOFAWIKI')) die('invalid acces');

function getLastTrigram()
{
	global $swRoot;
	$file = $swRoot.'/site/indexes/lasttrigram.txt';
	if (file_exists($file))
		$lasttrigram = file_get_contents($file);
	else
		$lasttrigram = 0;
	return $lasttrigram;
}

function getTrigram($t)
{
	global $swRoot;
	global $db;
	if (strlen($t)<3) return false;
	if (!stristr('abcdefghijklmnopqrstuvwxyz0123456789.-',substr($t,0,1))) return;
	if (!stristr('abcdefghijklmnopqrstuvwxyz0123456789.-',substr($t,1,1))) return;
	if (!stristr('abcdefghijklmnopqrstuvwxyz0123456789.-',substr($t,2,1))) return;
	if (array_key_exists($t,$db->trigrams)) return $db->trigrams[$t];
	
	$file = $swRoot.'/site/trigram/'.$t.'.txt';
	if (file_exists($file))
		$list = file($file,FILE_IGNORE_NEW_LINES);
	else
		$list = array();
	
	$bm = new swBitMap;
	$bm->init(getLastTrigram(),false);
	foreach($list as $v)
	{
		$bm->setbit($v);
	}
	
	return $bm;
}



function swIndexTrigram($numberofrevisions = 100, $refresh = false)
{
	echotime('trigram start ');
	global $db;
	global $swRoot;
	$lasttrigram = getLastTrigram();
	
	if ($refresh)
		$lasttrigram = 0;
	if ($lasttrigram == 0)
		$refresh = true;
	
	if ($refresh)
		clearTrigrams();
	
	$db->init(); // provoke init
	$lastrevision = $db->lastrevision;
	$n=1;
	$trigramindex = array();
	
	while($lasttrigram < $lastrevision)
	{
		$lasttrigram++;
		//index;
		$w = new swRecord;
		$w->revision=$lasttrigram;
		$w->lookup();
		
		$s = $w->name.' '.$w->content;
		$s = swNameURL($s);
		
		$trigrams = array();
		for($i=0;$i<strlen($s)-3;$i++)
		{
			$t = substr($s,$i,3);
			if (strlen($t)<3) continue;
			if (!stristr('abcdefghijklmnopqrstuvwxyz0123456789.-',substr($t,0,1))) continue;
			if (!stristr('abcdefghijklmnopqrstuvwxyz0123456789.-',substr($t,1,1))) continue;
			if (!stristr('abcdefghijklmnopqrstuvwxyz0123456789.-',substr($t,2,1))) continue;
			$trigrams[$t] = $t;
		}
		array_unique($trigrams);
		
		foreach($trigrams as $t)
			$trigramindex[$t][] = $lasttrigram;
		
		
		$n++;
		if ($n>$numberofrevisions) break;
	}

	$path = $swRoot.'/site/trigram/';
		if (!is_dir($path)) mkdir($path);

	foreach($trigramindex as $gram=>$revisions)
	{
		$path = $swRoot.'/site/trigram/'.$gram.'.txt';
		if ($f = @fopen($path,"a+"))
		{
			
			foreach($revisions as $r)
				@fwrite($f, $r.PHP_EOL);
			@fclose($f); 
		}
	
	}
	
	$path = $swRoot.'/site/indexes/lasttrigram.txt';
	if ($f = @fopen($path,"w"))
	{
		@fwrite($f, $lasttrigram);
		@fclose($f); 
	}
	echotime('trigram end '.$lasttrigram);
	
}

function clearTrigrams()
{
	 global $swRoot;
	 $files = glob($swRoot.'/site/trigram/*.txt');
	   
	 foreach($files as $file)
	 {
	   	unlink($file);
	 }

}

function trigramlist()
{
	 global $swRoot;
	 $files = glob($swRoot.'/site/trigram/*.txt');
	  
	 $list = array();
	 foreach($files as $file)
	 {
	   $key = sprintf('%05d',filesize($file));
	   	$fn = str_replace($swRoot.'/site/trigram/','',$file);
	   	$fn = substr($fn,0,-4);
	   	$list[$key.' '.$fn] = $fn;
	 }
	 krsort($list);
	 return $list;
}



?>