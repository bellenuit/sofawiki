<?php

function foldersize($path)
{
	return sprintf('%0d MB',foldersizer($path)/1024/1024);
}

function foldersizer($path)
{
	if(!file_exists($path)) return 0;
	if(is_file($path)) return filesize($path);
	$result = 0;
	$list = glob($path."/*");
	$c = count($list);
	for($i = 0; $i < $c; $i+=10)
    	$result += foldersizer($list[$i]);
  	return $result*10;
}


if (!defined("SOFAWIKI")) die("invalid acces");



if (isset($_REQUEST['phpinfo']))
{
	phpinfo();
	return;
}

$swParseSpecial = true;

$swParsedName = "Special:Info";

// suppress notices
if (!isset($_ENV["REMOTE_ADDR"])) $_ENV["REMOTE_ADDR"] = '?';
if (!isset($_ENV["HTTP_USER_AGENT"])) $_ENV["HTTP_USER_AGENT"] = '?';
if (!isset($_ENV["REQUEST_URI"])) $_ENV["REQUEST_URI"] = '?';
if (!isset($_ENV["HTTP_REFERER"])) $_ENV["HTTP_REFERER"] = '?';
if (!isset($_ENV["SERVER_ADDR"])) $_ENV["SERVER_ADDR"] = '?';
if (!isset($_ENV["HTTP_HOST"])) $_ENV["HTTP_HOST"] = '?';
if (!isset($_ENV["SERVER_SIGNATURE"])) $_ENV["SERVER_SIGNATURE"] = '?';


$swParsedContent = "'''Version''' {{version}}
'''Encoding''' UTF-8
'''Date''' {{currentdate}}
'''User''' {{currentuser}}
'''Name''' {{currentname}}
'''Skin''' {{currentskin}}
'''Language''' {{currentlanguage}}
'''Pages''' {{countpages}}
'''Revisions''' {{countrevisions}}
site/current +- ".foldersize($swRoot.'/site/current')."
site/files +- ".foldersize($swRoot.'/site/files')."
site/indexes +- ".foldersize($swRoot.'/site/indexes')."
site/revisions +- ".foldersize($swRoot.'/site/revisions')."
site/queries +- ".foldersize($swRoot.'/site/queries')."
Base path ".$swRoot."
====Installed Functions====
{{functions}}
====Installed Parsers====
{{parsers}}
====Installed Skins====
{{skins}}
====Templates====
{{templates}}
====Environment====
Remote Address " .$_ENV["REMOTE_ADDR"]."
User Agent " .$_ENV["HTTP_USER_AGENT"]."
Request URI " .$_ENV["REQUEST_URI"]."
Referer " .$_ENV["HTTP_REFERER"]."
Server Address " .$_ENV["SERVER_ADDR"]."
Host " .$_ENV["HTTP_HOST"]."
PHP Version ".phpversion()." <nowiki><a href='index.php?name=special:info&phpinfo=1'>PHP Info</a></nowiki>
Memory Limit ".ini_get("memory_limit")."
Memory Usage ".sprintf("%0.1f",memory_get_usage()/1024/1024)."M
Server Signature " .$_ENV["SERVER_SIGNATURE"]."


";




// print_r($_ENV);

?>